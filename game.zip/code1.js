gdjs.MainSceneCode = {};
gdjs.MainSceneCode.GDcursorObjects1= [];
gdjs.MainSceneCode.GDcursorObjects2= [];
gdjs.MainSceneCode.GDcursorObjects3= [];
gdjs.MainSceneCode.GDcursorObjects4= [];
gdjs.MainSceneCode.GDcursorObjects5= [];
gdjs.MainSceneCode.GDmapObjects1= [];
gdjs.MainSceneCode.GDmapObjects2= [];
gdjs.MainSceneCode.GDmapObjects3= [];
gdjs.MainSceneCode.GDmapObjects4= [];
gdjs.MainSceneCode.GDmapObjects5= [];
gdjs.MainSceneCode.GDobj_95btn_95startObjects1= [];
gdjs.MainSceneCode.GDobj_95btn_95startObjects2= [];
gdjs.MainSceneCode.GDobj_95btn_95startObjects3= [];
gdjs.MainSceneCode.GDobj_95btn_95startObjects4= [];
gdjs.MainSceneCode.GDobj_95btn_95startObjects5= [];
gdjs.MainSceneCode.GDtowerObjects1= [];
gdjs.MainSceneCode.GDtowerObjects2= [];
gdjs.MainSceneCode.GDtowerObjects3= [];
gdjs.MainSceneCode.GDtowerObjects4= [];
gdjs.MainSceneCode.GDtowerObjects5= [];
gdjs.MainSceneCode.GDtower_951_95arrowObjects1= [];
gdjs.MainSceneCode.GDtower_951_95arrowObjects2= [];
gdjs.MainSceneCode.GDtower_951_95arrowObjects3= [];
gdjs.MainSceneCode.GDtower_951_95arrowObjects4= [];
gdjs.MainSceneCode.GDtower_951_95arrowObjects5= [];
gdjs.MainSceneCode.GDenemy_950Objects1= [];
gdjs.MainSceneCode.GDenemy_950Objects2= [];
gdjs.MainSceneCode.GDenemy_950Objects3= [];
gdjs.MainSceneCode.GDenemy_950Objects4= [];
gdjs.MainSceneCode.GDenemy_950Objects5= [];
gdjs.MainSceneCode.GDtitleObjects1= [];
gdjs.MainSceneCode.GDtitleObjects2= [];
gdjs.MainSceneCode.GDtitleObjects3= [];
gdjs.MainSceneCode.GDtitleObjects4= [];
gdjs.MainSceneCode.GDtitleObjects5= [];
gdjs.MainSceneCode.GDobj_95btn_95deleteObjects1= [];
gdjs.MainSceneCode.GDobj_95btn_95deleteObjects2= [];
gdjs.MainSceneCode.GDobj_95btn_95deleteObjects3= [];
gdjs.MainSceneCode.GDobj_95btn_95deleteObjects4= [];
gdjs.MainSceneCode.GDobj_95btn_95deleteObjects5= [];
gdjs.MainSceneCode.GDtxt_95controlsObjects1= [];
gdjs.MainSceneCode.GDtxt_95controlsObjects2= [];
gdjs.MainSceneCode.GDtxt_95controlsObjects3= [];
gdjs.MainSceneCode.GDtxt_95controlsObjects4= [];
gdjs.MainSceneCode.GDtxt_95controlsObjects5= [];
gdjs.MainSceneCode.GDmoregamesObjects1= [];
gdjs.MainSceneCode.GDmoregamesObjects2= [];
gdjs.MainSceneCode.GDmoregamesObjects3= [];
gdjs.MainSceneCode.GDmoregamesObjects4= [];
gdjs.MainSceneCode.GDmoregamesObjects5= [];
gdjs.MainSceneCode.GDcontrols_95bgObjects1= [];
gdjs.MainSceneCode.GDcontrols_95bgObjects2= [];
gdjs.MainSceneCode.GDcontrols_95bgObjects3= [];
gdjs.MainSceneCode.GDcontrols_95bgObjects4= [];
gdjs.MainSceneCode.GDcontrols_95bgObjects5= [];

gdjs.MainSceneCode.conditionTrue_0 = {val:false};
gdjs.MainSceneCode.condition0IsTrue_0 = {val:false};
gdjs.MainSceneCode.condition1IsTrue_0 = {val:false};
gdjs.MainSceneCode.condition2IsTrue_0 = {val:false};
gdjs.MainSceneCode.condition3IsTrue_0 = {val:false};
gdjs.MainSceneCode.conditionTrue_1 = {val:false};
gdjs.MainSceneCode.condition0IsTrue_1 = {val:false};
gdjs.MainSceneCode.condition1IsTrue_1 = {val:false};
gdjs.MainSceneCode.condition2IsTrue_1 = {val:false};
gdjs.MainSceneCode.condition3IsTrue_1 = {val:false};


gdjs.MainSceneCode.eventsList0 = function(runtimeScene) {

{


gdjs.MainSceneCode.condition0IsTrue_0.val = false;
gdjs.MainSceneCode.condition1IsTrue_0.val = false;
{
gdjs.MainSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "first_play"));
}if ( gdjs.MainSceneCode.condition0IsTrue_0.val ) {
{
gdjs.MainSceneCode.condition1IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 0;
}}
if (gdjs.MainSceneCode.condition1IsTrue_0.val) {
{gdjs.evtTools.storage.writeNumberInJSONFile("game_data", "first_play", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(1);
}}

}


{


gdjs.MainSceneCode.condition0IsTrue_0.val = false;
{
gdjs.MainSceneCode.condition0IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "first_play");
}if (gdjs.MainSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.readNumberFromJSONFile("game_data", "first_play", runtimeScene, runtimeScene.getVariables().get("mm_first_play"));
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("mm_first_play")));
}}

}


};gdjs.MainSceneCode.eventsList1 = function(runtimeScene) {

{


gdjs.MainSceneCode.condition0IsTrue_0.val = false;
{
gdjs.MainSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "max_level_reached"));
}if (gdjs.MainSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.writeNumberInJSONFile("game_data", "max_level_reached", 1);
}{runtimeScene.getVariables().get("max_level_reached").setNumber(1);
}}

}


{


gdjs.MainSceneCode.condition0IsTrue_0.val = false;
{
gdjs.MainSceneCode.condition0IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "max_level_reached");
}if (gdjs.MainSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.readNumberFromJSONFile("game_data", "max_level_reached", runtimeScene, runtimeScene.getVariables().get("max_level_reached"));
}}

}


};gdjs.MainSceneCode.eventsList2 = function(runtimeScene) {

{


gdjs.MainSceneCode.condition0IsTrue_0.val = false;
{
gdjs.MainSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "game_level"));
}if (gdjs.MainSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.writeNumberInJSONFile("game_data", "game_level", 1);
}{runtimeScene.getVariables().get("game_level").setNumber(1);
}}

}


{


gdjs.MainSceneCode.condition0IsTrue_0.val = false;
{
gdjs.MainSceneCode.condition0IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "game_level");
}if (gdjs.MainSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.readNumberFromJSONFile("game_data", "game_level", runtimeScene, runtimeScene.getVariables().get("game_level"));
}}

}


};gdjs.MainSceneCode.eventsList3 = function(runtimeScene) {

{


gdjs.MainSceneCode.condition0IsTrue_0.val = false;
{
gdjs.MainSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "tutorial_number"));
}if (gdjs.MainSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.writeNumberInJSONFile("game_data", "tutorial_number", 1);
}{runtimeScene.getVariables().get("tutorial_number").setNumber(1);
}}

}


{


gdjs.MainSceneCode.condition0IsTrue_0.val = false;
{
gdjs.MainSceneCode.condition0IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "tutorial_number");
}if (gdjs.MainSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.readNumberFromJSONFile("game_data", "tutorial_number", runtimeScene, runtimeScene.getVariables().get("tutorial_number"));
}}

}


};gdjs.MainSceneCode.eventsList4 = function(runtimeScene) {

{


gdjs.MainSceneCode.condition0IsTrue_0.val = false;
{
gdjs.MainSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "coins"));
}if (gdjs.MainSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.writeNumberInJSONFile("game_data", "coins", 1200);
}{runtimeScene.getVariables().get("coins").setNumber(1200);
}}

}


{


gdjs.MainSceneCode.condition0IsTrue_0.val = false;
{
gdjs.MainSceneCode.condition0IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "coins");
}if (gdjs.MainSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.readNumberFromJSONFile("game_data", "coins", runtimeScene, runtimeScene.getVariables().get("coins"));
}}

}


};gdjs.MainSceneCode.eventsList5 = function(runtimeScene) {

{


gdjs.MainSceneCode.eventsList0(runtimeScene);
}


{


gdjs.MainSceneCode.eventsList1(runtimeScene);
}


{


gdjs.MainSceneCode.eventsList2(runtimeScene);
}


{


gdjs.MainSceneCode.eventsList3(runtimeScene);
}


{


gdjs.MainSceneCode.eventsList4(runtimeScene);
}


};gdjs.MainSceneCode.mapOfGDgdjs_46MainSceneCode_46GDcursorObjects1Objects = Hashtable.newFrom({"cursor": gdjs.MainSceneCode.GDcursorObjects1});gdjs.MainSceneCode.eventsList6 = function(runtimeScene) {

{


gdjs.MainSceneCode.condition0IsTrue_0.val = false;
{
gdjs.MainSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 1));
}if (gdjs.MainSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\music\\00-main-music.mp3", 1, true, 30, 1);
}}

}


};gdjs.MainSceneCode.eventsList7 = function(runtimeScene) {

{


gdjs.MainSceneCode.eventsList6(runtimeScene);
}


{


gdjs.MainSceneCode.condition0IsTrue_0.val = false;
{
gdjs.MainSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) > 1;
}if (gdjs.MainSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainSceneCode.GDobj_95btn_95startObjects1 */
{for(var i = 0, len = gdjs.MainSceneCode.GDobj_95btn_95startObjects1.length ;i < len;++i) {
    gdjs.MainSceneCode.GDobj_95btn_95startObjects1[i].setAnimationName("load");
}
}}

}


};gdjs.MainSceneCode.eventsList8 = function(runtimeScene) {

{



}


{


gdjs.MainSceneCode.condition0IsTrue_0.val = false;
{
gdjs.MainSceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.MainSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainSceneCode.eventsList5(runtimeScene);} //End of subevents
}

}


{


gdjs.MainSceneCode.condition0IsTrue_0.val = false;
{
gdjs.MainSceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.MainSceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("controls_bg"), gdjs.MainSceneCode.GDcontrols_95bgObjects1);
gdjs.copyArray(runtimeScene.getObjects("moregames"), gdjs.MainSceneCode.GDmoregamesObjects1);
gdjs.copyArray(runtimeScene.getObjects("obj_btn_delete"), gdjs.MainSceneCode.GDobj_95btn_95deleteObjects1);
gdjs.copyArray(runtimeScene.getObjects("obj_btn_start"), gdjs.MainSceneCode.GDobj_95btn_95startObjects1);
gdjs.copyArray(runtimeScene.getObjects("title"), gdjs.MainSceneCode.GDtitleObjects1);
gdjs.copyArray(runtimeScene.getObjects("txt_controls"), gdjs.MainSceneCode.GDtxt_95controlsObjects1);
gdjs.MainSceneCode.GDcursorObjects1.length = 0;

{for(var i = 0, len = gdjs.MainSceneCode.GDobj_95btn_95startObjects1.length ;i < len;++i) {
    gdjs.MainSceneCode.GDobj_95btn_95startObjects1[i].setPosition(gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2 - (gdjs.MainSceneCode.GDobj_95btn_95startObjects1[i].getWidth()) / 2,(gdjs.MainSceneCode.GDobj_95btn_95startObjects1[i].getPointY("")));
}
}{for(var i = 0, len = gdjs.MainSceneCode.GDobj_95btn_95deleteObjects1.length ;i < len;++i) {
    gdjs.MainSceneCode.GDobj_95btn_95deleteObjects1[i].setPosition(gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2 - (gdjs.MainSceneCode.GDobj_95btn_95deleteObjects1[i].getWidth()) / 2,(gdjs.MainSceneCode.GDobj_95btn_95deleteObjects1[i].getPointY("")));
}
}{for(var i = 0, len = gdjs.MainSceneCode.GDtitleObjects1.length ;i < len;++i) {
    gdjs.MainSceneCode.GDtitleObjects1[i].setPosition(gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2 - (gdjs.MainSceneCode.GDtitleObjects1[i].getWidth()) / 2,(gdjs.MainSceneCode.GDtitleObjects1[i].getPointY("")));
}
}{gdjs.evtTools.input.hideCursor(runtimeScene);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainSceneCode.mapOfGDgdjs_46MainSceneCode_46GDcursorObjects1Objects, 0, 0, "HUD");
}{for(var i = 0, len = gdjs.MainSceneCode.GDcursorObjects1.length ;i < len;++i) {
    gdjs.MainSceneCode.GDcursorObjects1[i].setZOrder(1000);
}
}{for(var i = 0, len = gdjs.MainSceneCode.GDmoregamesObjects1.length ;i < len;++i) {
    gdjs.MainSceneCode.GDmoregamesObjects1[i].setOutline("255;255;255", 6);
}
}{for(var i = 0, len = gdjs.MainSceneCode.GDmoregamesObjects1.length ;i < len;++i) {
    gdjs.MainSceneCode.GDmoregamesObjects1[i].setCharacterSize(80);
}
}{for(var i = 0, len = gdjs.MainSceneCode.GDmoregamesObjects1.length ;i < len;++i) {
    gdjs.MainSceneCode.GDmoregamesObjects1[i].setScale(0.2);
}
}{for(var i = 0, len = gdjs.MainSceneCode.GDtxt_95controlsObjects1.length ;i < len;++i) {
    gdjs.MainSceneCode.GDtxt_95controlsObjects1[i].setTextAlignment("center");
}
}{for(var i = 0, len = gdjs.MainSceneCode.GDtxt_95controlsObjects1.length ;i < len;++i) {
    gdjs.MainSceneCode.GDtxt_95controlsObjects1[i].setCharacterSize(40);
}
}{for(var i = 0, len = gdjs.MainSceneCode.GDtxt_95controlsObjects1.length ;i < len;++i) {
    gdjs.MainSceneCode.GDtxt_95controlsObjects1[i].setScale(0.2);
}
}{for(var i = 0, len = gdjs.MainSceneCode.GDtxt_95controlsObjects1.length ;i < len;++i) {
    gdjs.MainSceneCode.GDtxt_95controlsObjects1[i].setOutline("0;0;0", 8);
}
}{for(var i = 0, len = gdjs.MainSceneCode.GDtxt_95controlsObjects1.length ;i < len;++i) {
    gdjs.MainSceneCode.GDtxt_95controlsObjects1[i].setWrapping(true);
}
}{for(var i = 0, len = gdjs.MainSceneCode.GDtxt_95controlsObjects1.length ;i < len;++i) {
    gdjs.MainSceneCode.GDtxt_95controlsObjects1[i].setWrappingWidth(1920);
}
}{for(var i = 0, len = gdjs.MainSceneCode.GDcontrols_95bgObjects1.length ;i < len;++i) {
    gdjs.MainSceneCode.GDcontrols_95bgObjects1[i].setOpacity(150);
}
}{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 1);
}{for(var i = 0, len = gdjs.MainSceneCode.GDobj_95btn_95startObjects1.length ;i < len;++i) {
    gdjs.MainSceneCode.GDobj_95btn_95startObjects1[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.MainSceneCode.GDobj_95btn_95deleteObjects1.length ;i < len;++i) {
    gdjs.MainSceneCode.GDobj_95btn_95deleteObjects1[i].setOpacity(0);
}
}
{ //Subevents
gdjs.MainSceneCode.eventsList7(runtimeScene);} //End of subevents
}

}


};gdjs.MainSceneCode.eventsList9 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("obj_btn_start"), gdjs.MainSceneCode.GDobj_95btn_95startObjects2);

gdjs.MainSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainSceneCode.GDobj_95btn_95startObjects2.length;i<l;++i) {
    if ( gdjs.MainSceneCode.GDobj_95btn_95startObjects2[i].getOpacity() < 255 ) {
        gdjs.MainSceneCode.condition0IsTrue_0.val = true;
        gdjs.MainSceneCode.GDobj_95btn_95startObjects2[k] = gdjs.MainSceneCode.GDobj_95btn_95startObjects2[i];
        ++k;
    }
}
gdjs.MainSceneCode.GDobj_95btn_95startObjects2.length = k;}if (gdjs.MainSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainSceneCode.GDobj_95btn_95startObjects2 */
{for(var i = 0, len = gdjs.MainSceneCode.GDobj_95btn_95startObjects2.length ;i < len;++i) {
    gdjs.MainSceneCode.GDobj_95btn_95startObjects2[i].setOpacity(gdjs.MainSceneCode.GDobj_95btn_95startObjects2[i].getOpacity() + (255 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("obj_btn_delete"), gdjs.MainSceneCode.GDobj_95btn_95deleteObjects2);

gdjs.MainSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainSceneCode.GDobj_95btn_95deleteObjects2.length;i<l;++i) {
    if ( gdjs.MainSceneCode.GDobj_95btn_95deleteObjects2[i].getOpacity() < 255 ) {
        gdjs.MainSceneCode.condition0IsTrue_0.val = true;
        gdjs.MainSceneCode.GDobj_95btn_95deleteObjects2[k] = gdjs.MainSceneCode.GDobj_95btn_95deleteObjects2[i];
        ++k;
    }
}
gdjs.MainSceneCode.GDobj_95btn_95deleteObjects2.length = k;}if (gdjs.MainSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainSceneCode.GDobj_95btn_95deleteObjects2 */
{for(var i = 0, len = gdjs.MainSceneCode.GDobj_95btn_95deleteObjects2.length ;i < len;++i) {
    gdjs.MainSceneCode.GDobj_95btn_95deleteObjects2[i].setOpacity(gdjs.MainSceneCode.GDobj_95btn_95deleteObjects2[i].getOpacity() + (255 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("controls_bg"), gdjs.MainSceneCode.GDcontrols_95bgObjects2);
gdjs.copyArray(runtimeScene.getObjects("cursor"), gdjs.MainSceneCode.GDcursorObjects2);
gdjs.copyArray(runtimeScene.getObjects("moregames"), gdjs.MainSceneCode.GDmoregamesObjects2);
gdjs.copyArray(runtimeScene.getObjects("txt_controls"), gdjs.MainSceneCode.GDtxt_95controlsObjects2);
{for(var i = 0, len = gdjs.MainSceneCode.GDcursorObjects2.length ;i < len;++i) {
    gdjs.MainSceneCode.GDcursorObjects2[i].setPosition(gdjs.evtTools.input.getMouseX(runtimeScene, "", 0),gdjs.evtTools.input.getMouseY(runtimeScene, "", 0));
}
}{for(var i = 0, len = gdjs.MainSceneCode.GDmoregamesObjects2.length ;i < len;++i) {
    gdjs.MainSceneCode.GDmoregamesObjects2[i].setPosition((gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2) - ((gdjs.MainSceneCode.GDmoregamesObjects2[i].getWidth()) / 2),(gdjs.MainSceneCode.GDmoregamesObjects2[i].getY()));
}
}{for(var i = 0, len = gdjs.MainSceneCode.GDtxt_95controlsObjects2.length ;i < len;++i) {
    gdjs.MainSceneCode.GDtxt_95controlsObjects2[i].setPosition((gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2) - ((gdjs.MainSceneCode.GDtxt_95controlsObjects2[i].getWidth()) / 2),(gdjs.MainSceneCode.GDtxt_95controlsObjects2[i].getY()));
}
}{for(var i = 0, len = gdjs.MainSceneCode.GDcontrols_95bgObjects2.length ;i < len;++i) {
    gdjs.MainSceneCode.GDcontrols_95bgObjects2[i].setPosition(gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2 - (gdjs.MainSceneCode.GDcontrols_95bgObjects2[i].getWidth()) / 2,(gdjs.MainSceneCode.GDcontrols_95bgObjects2[i].getY()));
}
}}

}


{


{
{gdjs.evtsExt__Fullscreen__Fullscreen.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.MainSceneCode.mapOfGDgdjs_46MainSceneCode_46GDobj_9595btn_9595startObjects1Objects = Hashtable.newFrom({"obj_btn_start": gdjs.MainSceneCode.GDobj_95btn_95startObjects1});gdjs.MainSceneCode.eventsList10 = function(runtimeScene) {

{


gdjs.MainSceneCode.condition0IsTrue_0.val = false;
{
{gdjs.MainSceneCode.conditionTrue_1 = gdjs.MainSceneCode.condition0IsTrue_0;
gdjs.MainSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11615356);
}
}if (gdjs.MainSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\191756__leszek-szary__button-9.wav", 4, false, 100, 1);
}}

}


{


gdjs.MainSceneCode.condition0IsTrue_0.val = false;
{
{gdjs.MainSceneCode.conditionTrue_1 = gdjs.MainSceneCode.condition0IsTrue_0;
gdjs.MainSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11616068);
}
}if (gdjs.MainSceneCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("game_level").setNumber(1);
}{gdjs.evtTools.storage.writeNumberInJSONFile("game_data", "game_level", 1);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Levelselect", true);
}}

}


};gdjs.MainSceneCode.eventsList11 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("obj_btn_start"), gdjs.MainSceneCode.GDobj_95btn_95startObjects1);

gdjs.MainSceneCode.condition0IsTrue_0.val = false;
gdjs.MainSceneCode.condition1IsTrue_0.val = false;
gdjs.MainSceneCode.condition2IsTrue_0.val = false;
{
gdjs.MainSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainSceneCode.mapOfGDgdjs_46MainSceneCode_46GDobj_9595btn_9595startObjects1Objects, runtimeScene, true, false);
}if ( gdjs.MainSceneCode.condition0IsTrue_0.val ) {
{
gdjs.MainSceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.MainSceneCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.MainSceneCode.GDobj_95btn_95startObjects1.length;i<l;++i) {
    if ( gdjs.MainSceneCode.GDobj_95btn_95startObjects1[i].getOpacity() == 255 ) {
        gdjs.MainSceneCode.condition2IsTrue_0.val = true;
        gdjs.MainSceneCode.GDobj_95btn_95startObjects1[k] = gdjs.MainSceneCode.GDobj_95btn_95startObjects1[i];
        ++k;
    }
}
gdjs.MainSceneCode.GDobj_95btn_95startObjects1.length = k;}}
}
if (gdjs.MainSceneCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.MainSceneCode.eventsList10(runtimeScene);} //End of subevents
}

}


};gdjs.MainSceneCode.mapOfGDgdjs_46MainSceneCode_46GDobj_9595btn_9595deleteObjects1Objects = Hashtable.newFrom({"obj_btn_delete": gdjs.MainSceneCode.GDobj_95btn_95deleteObjects1});gdjs.MainSceneCode.eventsList12 = function(runtimeScene) {

{


gdjs.MainSceneCode.condition0IsTrue_0.val = false;
{
{gdjs.MainSceneCode.conditionTrue_1 = gdjs.MainSceneCode.condition0IsTrue_0;
gdjs.MainSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11618364);
}
}if (gdjs.MainSceneCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(0);
}{gdjs.evtTools.storage.clearJSONFile("game_data");
}}

}


{


gdjs.MainSceneCode.condition0IsTrue_0.val = false;
{
{gdjs.MainSceneCode.conditionTrue_1 = gdjs.MainSceneCode.condition0IsTrue_0;
gdjs.MainSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11619172);
}
}if (gdjs.MainSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\191756__leszek-szary__button-9.wav", 4, false, 100, 1);
}}

}


{


gdjs.MainSceneCode.condition0IsTrue_0.val = false;
{
{gdjs.MainSceneCode.conditionTrue_1 = gdjs.MainSceneCode.condition0IsTrue_0;
gdjs.MainSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11620028);
}
}if (gdjs.MainSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "MainScene", true);
}}

}


};gdjs.MainSceneCode.eventsList13 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("obj_btn_delete"), gdjs.MainSceneCode.GDobj_95btn_95deleteObjects1);

gdjs.MainSceneCode.condition0IsTrue_0.val = false;
gdjs.MainSceneCode.condition1IsTrue_0.val = false;
gdjs.MainSceneCode.condition2IsTrue_0.val = false;
{
gdjs.MainSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainSceneCode.mapOfGDgdjs_46MainSceneCode_46GDobj_9595btn_9595deleteObjects1Objects, runtimeScene, true, false);
}if ( gdjs.MainSceneCode.condition0IsTrue_0.val ) {
{
gdjs.MainSceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.MainSceneCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.MainSceneCode.GDobj_95btn_95deleteObjects1.length;i<l;++i) {
    if ( gdjs.MainSceneCode.GDobj_95btn_95deleteObjects1[i].getOpacity() == 255 ) {
        gdjs.MainSceneCode.condition2IsTrue_0.val = true;
        gdjs.MainSceneCode.GDobj_95btn_95deleteObjects1[k] = gdjs.MainSceneCode.GDobj_95btn_95deleteObjects1[i];
        ++k;
    }
}
gdjs.MainSceneCode.GDobj_95btn_95deleteObjects1.length = k;}}
}
if (gdjs.MainSceneCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.MainSceneCode.eventsList12(runtimeScene);} //End of subevents
}

}


};gdjs.MainSceneCode.mapOfGDgdjs_46MainSceneCode_46GDmoregamesObjects1Objects = Hashtable.newFrom({"moregames": gdjs.MainSceneCode.GDmoregamesObjects1});gdjs.MainSceneCode.eventsList14 = function(runtimeScene) {

{


gdjs.MainSceneCode.condition0IsTrue_0.val = false;
{
{gdjs.MainSceneCode.conditionTrue_1 = gdjs.MainSceneCode.condition0IsTrue_0;
gdjs.MainSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11621516);
}
}if (gdjs.MainSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.window.openURL("https://www.crimsongames.io", runtimeScene);
}}

}


};gdjs.MainSceneCode.eventsList15 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("moregames"), gdjs.MainSceneCode.GDmoregamesObjects1);

gdjs.MainSceneCode.condition0IsTrue_0.val = false;
gdjs.MainSceneCode.condition1IsTrue_0.val = false;
{
gdjs.MainSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainSceneCode.mapOfGDgdjs_46MainSceneCode_46GDmoregamesObjects1Objects, runtimeScene, true, false);
}if ( gdjs.MainSceneCode.condition0IsTrue_0.val ) {
{
gdjs.MainSceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.MainSceneCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.MainSceneCode.eventsList14(runtimeScene);} //End of subevents
}

}


};gdjs.MainSceneCode.eventsList16 = function(runtimeScene) {

{


gdjs.MainSceneCode.eventsList8(runtimeScene);
}


{


gdjs.MainSceneCode.eventsList9(runtimeScene);
}


{


gdjs.MainSceneCode.eventsList11(runtimeScene);
}


{


gdjs.MainSceneCode.eventsList13(runtimeScene);
}


{


gdjs.MainSceneCode.eventsList15(runtimeScene);
}


};

gdjs.MainSceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.MainSceneCode.GDcursorObjects1.length = 0;
gdjs.MainSceneCode.GDcursorObjects2.length = 0;
gdjs.MainSceneCode.GDcursorObjects3.length = 0;
gdjs.MainSceneCode.GDcursorObjects4.length = 0;
gdjs.MainSceneCode.GDcursorObjects5.length = 0;
gdjs.MainSceneCode.GDmapObjects1.length = 0;
gdjs.MainSceneCode.GDmapObjects2.length = 0;
gdjs.MainSceneCode.GDmapObjects3.length = 0;
gdjs.MainSceneCode.GDmapObjects4.length = 0;
gdjs.MainSceneCode.GDmapObjects5.length = 0;
gdjs.MainSceneCode.GDobj_95btn_95startObjects1.length = 0;
gdjs.MainSceneCode.GDobj_95btn_95startObjects2.length = 0;
gdjs.MainSceneCode.GDobj_95btn_95startObjects3.length = 0;
gdjs.MainSceneCode.GDobj_95btn_95startObjects4.length = 0;
gdjs.MainSceneCode.GDobj_95btn_95startObjects5.length = 0;
gdjs.MainSceneCode.GDtowerObjects1.length = 0;
gdjs.MainSceneCode.GDtowerObjects2.length = 0;
gdjs.MainSceneCode.GDtowerObjects3.length = 0;
gdjs.MainSceneCode.GDtowerObjects4.length = 0;
gdjs.MainSceneCode.GDtowerObjects5.length = 0;
gdjs.MainSceneCode.GDtower_951_95arrowObjects1.length = 0;
gdjs.MainSceneCode.GDtower_951_95arrowObjects2.length = 0;
gdjs.MainSceneCode.GDtower_951_95arrowObjects3.length = 0;
gdjs.MainSceneCode.GDtower_951_95arrowObjects4.length = 0;
gdjs.MainSceneCode.GDtower_951_95arrowObjects5.length = 0;
gdjs.MainSceneCode.GDenemy_950Objects1.length = 0;
gdjs.MainSceneCode.GDenemy_950Objects2.length = 0;
gdjs.MainSceneCode.GDenemy_950Objects3.length = 0;
gdjs.MainSceneCode.GDenemy_950Objects4.length = 0;
gdjs.MainSceneCode.GDenemy_950Objects5.length = 0;
gdjs.MainSceneCode.GDtitleObjects1.length = 0;
gdjs.MainSceneCode.GDtitleObjects2.length = 0;
gdjs.MainSceneCode.GDtitleObjects3.length = 0;
gdjs.MainSceneCode.GDtitleObjects4.length = 0;
gdjs.MainSceneCode.GDtitleObjects5.length = 0;
gdjs.MainSceneCode.GDobj_95btn_95deleteObjects1.length = 0;
gdjs.MainSceneCode.GDobj_95btn_95deleteObjects2.length = 0;
gdjs.MainSceneCode.GDobj_95btn_95deleteObjects3.length = 0;
gdjs.MainSceneCode.GDobj_95btn_95deleteObjects4.length = 0;
gdjs.MainSceneCode.GDobj_95btn_95deleteObjects5.length = 0;
gdjs.MainSceneCode.GDtxt_95controlsObjects1.length = 0;
gdjs.MainSceneCode.GDtxt_95controlsObjects2.length = 0;
gdjs.MainSceneCode.GDtxt_95controlsObjects3.length = 0;
gdjs.MainSceneCode.GDtxt_95controlsObjects4.length = 0;
gdjs.MainSceneCode.GDtxt_95controlsObjects5.length = 0;
gdjs.MainSceneCode.GDmoregamesObjects1.length = 0;
gdjs.MainSceneCode.GDmoregamesObjects2.length = 0;
gdjs.MainSceneCode.GDmoregamesObjects3.length = 0;
gdjs.MainSceneCode.GDmoregamesObjects4.length = 0;
gdjs.MainSceneCode.GDmoregamesObjects5.length = 0;
gdjs.MainSceneCode.GDcontrols_95bgObjects1.length = 0;
gdjs.MainSceneCode.GDcontrols_95bgObjects2.length = 0;
gdjs.MainSceneCode.GDcontrols_95bgObjects3.length = 0;
gdjs.MainSceneCode.GDcontrols_95bgObjects4.length = 0;
gdjs.MainSceneCode.GDcontrols_95bgObjects5.length = 0;

gdjs.MainSceneCode.eventsList16(runtimeScene);
return;

}

gdjs['MainSceneCode'] = gdjs.MainSceneCode;
