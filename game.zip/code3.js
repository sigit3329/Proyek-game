gdjs.LevelselectCode = {};
gdjs.LevelselectCode.forEachIndex2 = 0;

gdjs.LevelselectCode.forEachObjects2 = [];

gdjs.LevelselectCode.forEachTemporary2 = null;

gdjs.LevelselectCode.forEachTotalCount2 = 0;

gdjs.LevelselectCode.GDcursorObjects1= [];
gdjs.LevelselectCode.GDcursorObjects2= [];
gdjs.LevelselectCode.GDcursorObjects3= [];
gdjs.LevelselectCode.GDcursorObjects4= [];
gdjs.LevelselectCode.GDcursorObjects5= [];
gdjs.LevelselectCode.GDlevel_951Objects1= [];
gdjs.LevelselectCode.GDlevel_951Objects2= [];
gdjs.LevelselectCode.GDlevel_951Objects3= [];
gdjs.LevelselectCode.GDlevel_951Objects4= [];
gdjs.LevelselectCode.GDlevel_951Objects5= [];
gdjs.LevelselectCode.GDobj_95btn_95levelObjects1= [];
gdjs.LevelselectCode.GDobj_95btn_95levelObjects2= [];
gdjs.LevelselectCode.GDobj_95btn_95levelObjects3= [];
gdjs.LevelselectCode.GDobj_95btn_95levelObjects4= [];
gdjs.LevelselectCode.GDobj_95btn_95levelObjects5= [];
gdjs.LevelselectCode.GDlevel_95selectObjects1= [];
gdjs.LevelselectCode.GDlevel_95selectObjects2= [];
gdjs.LevelselectCode.GDlevel_95selectObjects3= [];
gdjs.LevelselectCode.GDlevel_95selectObjects4= [];
gdjs.LevelselectCode.GDlevel_95selectObjects5= [];
gdjs.LevelselectCode.GDobj_95btn_95backObjects1= [];
gdjs.LevelselectCode.GDobj_95btn_95backObjects2= [];
gdjs.LevelselectCode.GDobj_95btn_95backObjects3= [];
gdjs.LevelselectCode.GDobj_95btn_95backObjects4= [];
gdjs.LevelselectCode.GDobj_95btn_95backObjects5= [];
gdjs.LevelselectCode.GDobj_95btn_95startObjects1= [];
gdjs.LevelselectCode.GDobj_95btn_95startObjects2= [];
gdjs.LevelselectCode.GDobj_95btn_95startObjects3= [];
gdjs.LevelselectCode.GDobj_95btn_95startObjects4= [];
gdjs.LevelselectCode.GDobj_95btn_95startObjects5= [];
gdjs.LevelselectCode.GDselectorObjects1= [];
gdjs.LevelselectCode.GDselectorObjects2= [];
gdjs.LevelselectCode.GDselectorObjects3= [];
gdjs.LevelselectCode.GDselectorObjects4= [];
gdjs.LevelselectCode.GDselectorObjects5= [];
gdjs.LevelselectCode.GDhud_95boxObjects1= [];
gdjs.LevelselectCode.GDhud_95boxObjects2= [];
gdjs.LevelselectCode.GDhud_95boxObjects3= [];
gdjs.LevelselectCode.GDhud_95boxObjects4= [];
gdjs.LevelselectCode.GDhud_95boxObjects5= [];

gdjs.LevelselectCode.conditionTrue_0 = {val:false};
gdjs.LevelselectCode.condition0IsTrue_0 = {val:false};
gdjs.LevelselectCode.condition1IsTrue_0 = {val:false};
gdjs.LevelselectCode.condition2IsTrue_0 = {val:false};
gdjs.LevelselectCode.condition3IsTrue_0 = {val:false};
gdjs.LevelselectCode.conditionTrue_1 = {val:false};
gdjs.LevelselectCode.condition0IsTrue_1 = {val:false};
gdjs.LevelselectCode.condition1IsTrue_1 = {val:false};
gdjs.LevelselectCode.condition2IsTrue_1 = {val:false};
gdjs.LevelselectCode.condition3IsTrue_1 = {val:false};


gdjs.LevelselectCode.eventsList0 = function(runtimeScene) {

{


gdjs.LevelselectCode.condition0IsTrue_0.val = false;
gdjs.LevelselectCode.condition1IsTrue_0.val = false;
{
gdjs.LevelselectCode.condition0IsTrue_0.val = !(gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "first_play"));
}if ( gdjs.LevelselectCode.condition0IsTrue_0.val ) {
{
gdjs.LevelselectCode.condition1IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 0;
}}
if (gdjs.LevelselectCode.condition1IsTrue_0.val) {
{gdjs.evtTools.storage.writeNumberInJSONFile("game_data", "first_play", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(1);
}}

}


{


gdjs.LevelselectCode.condition0IsTrue_0.val = false;
{
gdjs.LevelselectCode.condition0IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "first_play");
}if (gdjs.LevelselectCode.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.readNumberFromJSONFile("game_data", "first_play", runtimeScene, runtimeScene.getVariables().get("mm_first_play"));
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("mm_first_play")));
}}

}


};gdjs.LevelselectCode.eventsList1 = function(runtimeScene) {

{


gdjs.LevelselectCode.condition0IsTrue_0.val = false;
{
gdjs.LevelselectCode.condition0IsTrue_0.val = !(gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "max_level_reached"));
}if (gdjs.LevelselectCode.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.writeNumberInJSONFile("game_data", "max_level_reached", 1);
}{runtimeScene.getVariables().get("max_level_reached").setNumber(1);
}}

}


{


gdjs.LevelselectCode.condition0IsTrue_0.val = false;
{
gdjs.LevelselectCode.condition0IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "max_level_reached");
}if (gdjs.LevelselectCode.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.readNumberFromJSONFile("game_data", "max_level_reached", runtimeScene, runtimeScene.getVariables().get("max_level_reached"));
}}

}


};gdjs.LevelselectCode.eventsList2 = function(runtimeScene) {

{


gdjs.LevelselectCode.condition0IsTrue_0.val = false;
{
gdjs.LevelselectCode.condition0IsTrue_0.val = !(gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "game_level"));
}if (gdjs.LevelselectCode.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.writeNumberInJSONFile("game_data", "game_level", 1);
}{runtimeScene.getVariables().get("game_level").setNumber(1);
}}

}


{


gdjs.LevelselectCode.condition0IsTrue_0.val = false;
{
gdjs.LevelselectCode.condition0IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "game_level");
}if (gdjs.LevelselectCode.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.readNumberFromJSONFile("game_data", "game_level", runtimeScene, runtimeScene.getVariables().get("game_level"));
}}

}


};gdjs.LevelselectCode.eventsList3 = function(runtimeScene) {

{


gdjs.LevelselectCode.condition0IsTrue_0.val = false;
{
gdjs.LevelselectCode.condition0IsTrue_0.val = !(gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "tutorial_number"));
}if (gdjs.LevelselectCode.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.writeNumberInJSONFile("game_data", "tutorial_number", 1);
}{runtimeScene.getVariables().get("tutorial_number").setNumber(1);
}}

}


{


gdjs.LevelselectCode.condition0IsTrue_0.val = false;
{
gdjs.LevelselectCode.condition0IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "tutorial_number");
}if (gdjs.LevelselectCode.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.readNumberFromJSONFile("game_data", "tutorial_number", runtimeScene, runtimeScene.getVariables().get("tutorial_number"));
}}

}


};gdjs.LevelselectCode.eventsList4 = function(runtimeScene) {

{


gdjs.LevelselectCode.condition0IsTrue_0.val = false;
{
gdjs.LevelselectCode.condition0IsTrue_0.val = !(gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "coins"));
}if (gdjs.LevelselectCode.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.writeNumberInJSONFile("game_data", "coins", 1200);
}{runtimeScene.getVariables().get("coins").setNumber(1200);
}}

}


{


gdjs.LevelselectCode.condition0IsTrue_0.val = false;
{
gdjs.LevelselectCode.condition0IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "coins");
}if (gdjs.LevelselectCode.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.readNumberFromJSONFile("game_data", "coins", runtimeScene, runtimeScene.getVariables().get("coins"));
}}

}


};gdjs.LevelselectCode.eventsList5 = function(runtimeScene) {

{


gdjs.LevelselectCode.eventsList0(runtimeScene);
}


{


gdjs.LevelselectCode.eventsList1(runtimeScene);
}


{


gdjs.LevelselectCode.eventsList2(runtimeScene);
}


{


gdjs.LevelselectCode.eventsList3(runtimeScene);
}


{


gdjs.LevelselectCode.eventsList4(runtimeScene);
}


};gdjs.LevelselectCode.mapOfGDgdjs_46LevelselectCode_46GDcursorObjects1Objects = Hashtable.newFrom({"cursor": gdjs.LevelselectCode.GDcursorObjects1});gdjs.LevelselectCode.eventsList6 = function(runtimeScene) {

};gdjs.LevelselectCode.eventsList7 = function(runtimeScene) {

{

/* Reuse gdjs.LevelselectCode.GDobj_95btn_95levelObjects1 */

for(gdjs.LevelselectCode.forEachIndex2 = 0;gdjs.LevelselectCode.forEachIndex2 < gdjs.LevelselectCode.GDobj_95btn_95levelObjects1.length;++gdjs.LevelselectCode.forEachIndex2) {
gdjs.LevelselectCode.GDobj_95btn_95levelObjects2.length = 0;


gdjs.LevelselectCode.forEachTemporary2 = gdjs.LevelselectCode.GDobj_95btn_95levelObjects1[gdjs.LevelselectCode.forEachIndex2];
gdjs.LevelselectCode.GDobj_95btn_95levelObjects2.push(gdjs.LevelselectCode.forEachTemporary2);
gdjs.LevelselectCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelselectCode.GDobj_95btn_95levelObjects2.length;i<l;++i) {
    if ( gdjs.LevelselectCode.GDobj_95btn_95levelObjects2[i].getVariableNumber(gdjs.LevelselectCode.GDobj_95btn_95levelObjects2[i].getVariables().getFromIndex(0)) <= gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("max_level_reached")) ) {
        gdjs.LevelselectCode.condition0IsTrue_0.val = true;
        gdjs.LevelselectCode.GDobj_95btn_95levelObjects2[k] = gdjs.LevelselectCode.GDobj_95btn_95levelObjects2[i];
        ++k;
    }
}
gdjs.LevelselectCode.GDobj_95btn_95levelObjects2.length = k;}if (gdjs.LevelselectCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.LevelselectCode.GDobj_95btn_95levelObjects2.length ;i < len;++i) {
    gdjs.LevelselectCode.GDobj_95btn_95levelObjects2[i].setAnimationName("idle");
}
}}
}

}


};gdjs.LevelselectCode.eventsList8 = function(runtimeScene) {

{



}


{


gdjs.LevelselectCode.condition0IsTrue_0.val = false;
{
gdjs.LevelselectCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.LevelselectCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.LevelselectCode.eventsList5(runtimeScene);} //End of subevents
}

}


{


gdjs.LevelselectCode.condition0IsTrue_0.val = false;
{
gdjs.LevelselectCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.LevelselectCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("obj_btn_back"), gdjs.LevelselectCode.GDobj_95btn_95backObjects1);
gdjs.copyArray(runtimeScene.getObjects("obj_btn_level"), gdjs.LevelselectCode.GDobj_95btn_95levelObjects1);
gdjs.LevelselectCode.GDcursorObjects1.length = 0;

{gdjs.evtTools.input.hideCursor(runtimeScene);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LevelselectCode.mapOfGDgdjs_46LevelselectCode_46GDcursorObjects1Objects, 0, 0, "HUD");
}{for(var i = 0, len = gdjs.LevelselectCode.GDobj_95btn_95levelObjects1.length ;i < len;++i) {
    gdjs.LevelselectCode.GDobj_95btn_95levelObjects1[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.LevelselectCode.GDobj_95btn_95backObjects1.length ;i < len;++i) {
    gdjs.LevelselectCode.GDobj_95btn_95backObjects1[i].setOpacity(0);
}
}{for(var i = 0, len = gdjs.LevelselectCode.GDcursorObjects1.length ;i < len;++i) {
    gdjs.LevelselectCode.GDcursorObjects1[i].setZOrder(1000);
}
}
{ //Subevents
gdjs.LevelselectCode.eventsList7(runtimeScene);} //End of subevents
}

}


};gdjs.LevelselectCode.eventsList9 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("cursor"), gdjs.LevelselectCode.GDcursorObjects2);
{for(var i = 0, len = gdjs.LevelselectCode.GDcursorObjects2.length ;i < len;++i) {
    gdjs.LevelselectCode.GDcursorObjects2[i].setPosition(gdjs.evtTools.input.getMouseX(runtimeScene, "", 0),gdjs.evtTools.input.getMouseY(runtimeScene, "", 0));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("obj_btn_level"), gdjs.LevelselectCode.GDobj_95btn_95levelObjects2);

gdjs.LevelselectCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelselectCode.GDobj_95btn_95levelObjects2.length;i<l;++i) {
    if ( gdjs.LevelselectCode.GDobj_95btn_95levelObjects2[i].getOpacity() < 255 ) {
        gdjs.LevelselectCode.condition0IsTrue_0.val = true;
        gdjs.LevelselectCode.GDobj_95btn_95levelObjects2[k] = gdjs.LevelselectCode.GDobj_95btn_95levelObjects2[i];
        ++k;
    }
}
gdjs.LevelselectCode.GDobj_95btn_95levelObjects2.length = k;}if (gdjs.LevelselectCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelselectCode.GDobj_95btn_95levelObjects2 */
{for(var i = 0, len = gdjs.LevelselectCode.GDobj_95btn_95levelObjects2.length ;i < len;++i) {
    gdjs.LevelselectCode.GDobj_95btn_95levelObjects2[i].setOpacity(gdjs.LevelselectCode.GDobj_95btn_95levelObjects2[i].getOpacity() + (255 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("obj_btn_back"), gdjs.LevelselectCode.GDobj_95btn_95backObjects2);

gdjs.LevelselectCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelselectCode.GDobj_95btn_95backObjects2.length;i<l;++i) {
    if ( gdjs.LevelselectCode.GDobj_95btn_95backObjects2[i].getOpacity() < 255 ) {
        gdjs.LevelselectCode.condition0IsTrue_0.val = true;
        gdjs.LevelselectCode.GDobj_95btn_95backObjects2[k] = gdjs.LevelselectCode.GDobj_95btn_95backObjects2[i];
        ++k;
    }
}
gdjs.LevelselectCode.GDobj_95btn_95backObjects2.length = k;}if (gdjs.LevelselectCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelselectCode.GDobj_95btn_95backObjects2 */
{for(var i = 0, len = gdjs.LevelselectCode.GDobj_95btn_95backObjects2.length ;i < len;++i) {
    gdjs.LevelselectCode.GDobj_95btn_95backObjects2[i].setOpacity(gdjs.LevelselectCode.GDobj_95btn_95backObjects2[i].getOpacity() + (255 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}}

}


{


{
{gdjs.evtsExt__Fullscreen__Fullscreen.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.LevelselectCode.mapOfGDgdjs_46LevelselectCode_46GDobj_9595btn_9595backObjects1Objects = Hashtable.newFrom({"obj_btn_back": gdjs.LevelselectCode.GDobj_95btn_95backObjects1});gdjs.LevelselectCode.eventsList10 = function(runtimeScene) {

{


gdjs.LevelselectCode.condition0IsTrue_0.val = false;
{
{gdjs.LevelselectCode.conditionTrue_1 = gdjs.LevelselectCode.condition0IsTrue_0;
gdjs.LevelselectCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11657012);
}
}if (gdjs.LevelselectCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\191756__leszek-szary__button-9.wav", 4, false, 100, 1);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "MainScene", true);
}}

}


};gdjs.LevelselectCode.eventsList11 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("obj_btn_back"), gdjs.LevelselectCode.GDobj_95btn_95backObjects1);

gdjs.LevelselectCode.condition0IsTrue_0.val = false;
gdjs.LevelselectCode.condition1IsTrue_0.val = false;
gdjs.LevelselectCode.condition2IsTrue_0.val = false;
{
gdjs.LevelselectCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.LevelselectCode.mapOfGDgdjs_46LevelselectCode_46GDobj_9595btn_9595backObjects1Objects, runtimeScene, true, false);
}if ( gdjs.LevelselectCode.condition0IsTrue_0.val ) {
{
gdjs.LevelselectCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.LevelselectCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.LevelselectCode.GDobj_95btn_95backObjects1.length;i<l;++i) {
    if ( gdjs.LevelselectCode.GDobj_95btn_95backObjects1[i].getOpacity() == 255 ) {
        gdjs.LevelselectCode.condition2IsTrue_0.val = true;
        gdjs.LevelselectCode.GDobj_95btn_95backObjects1[k] = gdjs.LevelselectCode.GDobj_95btn_95backObjects1[i];
        ++k;
    }
}
gdjs.LevelselectCode.GDobj_95btn_95backObjects1.length = k;}}
}
if (gdjs.LevelselectCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.LevelselectCode.eventsList10(runtimeScene);} //End of subevents
}

}


};gdjs.LevelselectCode.mapOfGDgdjs_46LevelselectCode_46GDobj_9595btn_9595levelObjects1Objects = Hashtable.newFrom({"obj_btn_level": gdjs.LevelselectCode.GDobj_95btn_95levelObjects1});gdjs.LevelselectCode.eventsList12 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.LevelselectCode.GDobj_95btn_95levelObjects1, gdjs.LevelselectCode.GDobj_95btn_95levelObjects2);


gdjs.LevelselectCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelselectCode.GDobj_95btn_95levelObjects2.length;i<l;++i) {
    if ( gdjs.LevelselectCode.GDobj_95btn_95levelObjects2[i].isCurrentAnimationName("idle") ) {
        gdjs.LevelselectCode.condition0IsTrue_0.val = true;
        gdjs.LevelselectCode.GDobj_95btn_95levelObjects2[k] = gdjs.LevelselectCode.GDobj_95btn_95levelObjects2[i];
        ++k;
    }
}
gdjs.LevelselectCode.GDobj_95btn_95levelObjects2.length = k;}if (gdjs.LevelselectCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelselectCode.GDobj_95btn_95levelObjects2 */
gdjs.copyArray(gdjs.LevelselectCode.GDselectorObjects1, gdjs.LevelselectCode.GDselectorObjects2);

{for(var i = 0, len = gdjs.LevelselectCode.GDselectorObjects2.length ;i < len;++i) {
    gdjs.LevelselectCode.GDselectorObjects2[i].returnVariable(gdjs.LevelselectCode.GDselectorObjects2[i].getVariables().getFromIndex(0)).setNumber((gdjs.RuntimeObject.getVariableNumber(((gdjs.LevelselectCode.GDobj_95btn_95levelObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.LevelselectCode.GDobj_95btn_95levelObjects2[0].getVariables()).getFromIndex(0))));
}
}}

}


{


gdjs.LevelselectCode.condition0IsTrue_0.val = false;
{
{gdjs.LevelselectCode.conditionTrue_1 = gdjs.LevelselectCode.condition0IsTrue_0;
gdjs.LevelselectCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11660252);
}
}if (gdjs.LevelselectCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\191756__leszek-szary__button-9.wav", 4, false, 100, 1);
}}

}


};gdjs.LevelselectCode.eventsList13 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("obj_btn_level"), gdjs.LevelselectCode.GDobj_95btn_95levelObjects1);

gdjs.LevelselectCode.condition0IsTrue_0.val = false;
gdjs.LevelselectCode.condition1IsTrue_0.val = false;
gdjs.LevelselectCode.condition2IsTrue_0.val = false;
{
gdjs.LevelselectCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.LevelselectCode.mapOfGDgdjs_46LevelselectCode_46GDobj_9595btn_9595levelObjects1Objects, runtimeScene, true, false);
}if ( gdjs.LevelselectCode.condition0IsTrue_0.val ) {
{
gdjs.LevelselectCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.LevelselectCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.LevelselectCode.GDobj_95btn_95levelObjects1.length;i<l;++i) {
    if ( gdjs.LevelselectCode.GDobj_95btn_95levelObjects1[i].getOpacity() == 255 ) {
        gdjs.LevelselectCode.condition2IsTrue_0.val = true;
        gdjs.LevelselectCode.GDobj_95btn_95levelObjects1[k] = gdjs.LevelselectCode.GDobj_95btn_95levelObjects1[i];
        ++k;
    }
}
gdjs.LevelselectCode.GDobj_95btn_95levelObjects1.length = k;}}
}
if (gdjs.LevelselectCode.condition2IsTrue_0.val) {
/* Reuse gdjs.LevelselectCode.GDobj_95btn_95levelObjects1 */
gdjs.copyArray(runtimeScene.getObjects("selector"), gdjs.LevelselectCode.GDselectorObjects1);
{for(var i = 0, len = gdjs.LevelselectCode.GDselectorObjects1.length ;i < len;++i) {
    gdjs.LevelselectCode.GDselectorObjects1[i].setPosition((( gdjs.LevelselectCode.GDobj_95btn_95levelObjects1.length === 0 ) ? 0 :gdjs.LevelselectCode.GDobj_95btn_95levelObjects1[0].getPointX("")),(( gdjs.LevelselectCode.GDobj_95btn_95levelObjects1.length === 0 ) ? 0 :gdjs.LevelselectCode.GDobj_95btn_95levelObjects1[0].getPointY("")));
}
}
{ //Subevents
gdjs.LevelselectCode.eventsList12(runtimeScene);} //End of subevents
}

}


};gdjs.LevelselectCode.mapOfGDgdjs_46LevelselectCode_46GDobj_9595btn_9595startObjects1Objects = Hashtable.newFrom({"obj_btn_start": gdjs.LevelselectCode.GDobj_95btn_95startObjects1});gdjs.LevelselectCode.mapOfGDgdjs_46LevelselectCode_46GDselectorObjects1Objects = Hashtable.newFrom({"selector": gdjs.LevelselectCode.GDselectorObjects1});gdjs.LevelselectCode.mapOfGDgdjs_46LevelselectCode_46GDobj_9595btn_9595levelObjects1Objects = Hashtable.newFrom({"obj_btn_level": gdjs.LevelselectCode.GDobj_95btn_95levelObjects1});gdjs.LevelselectCode.eventsList14 = function(runtimeScene) {

{


gdjs.LevelselectCode.condition0IsTrue_0.val = false;
{
{gdjs.LevelselectCode.conditionTrue_1 = gdjs.LevelselectCode.condition0IsTrue_0;
gdjs.LevelselectCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11663108);
}
}if (gdjs.LevelselectCode.condition0IsTrue_0.val) {
/* Reuse gdjs.LevelselectCode.GDselectorObjects1 */
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\191756__leszek-szary__button-9.wav", 5, false, 100, 1);
}{runtimeScene.getVariables().get("game_level").setNumber((gdjs.RuntimeObject.getVariableNumber(((gdjs.LevelselectCode.GDselectorObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.LevelselectCode.GDselectorObjects1[0].getVariables()).getFromIndex(0))));
}{gdjs.evtTools.storage.writeNumberInJSONFile("game_data", "game_level", gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("game_level")));
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "GameScene", true);
}}

}


};gdjs.LevelselectCode.eventsList15 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("obj_btn_level"), gdjs.LevelselectCode.GDobj_95btn_95levelObjects1);
/* Reuse gdjs.LevelselectCode.GDselectorObjects1 */

gdjs.LevelselectCode.condition0IsTrue_0.val = false;
gdjs.LevelselectCode.condition1IsTrue_0.val = false;
{
gdjs.LevelselectCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LevelselectCode.mapOfGDgdjs_46LevelselectCode_46GDselectorObjects1Objects, gdjs.LevelselectCode.mapOfGDgdjs_46LevelselectCode_46GDobj_9595btn_9595levelObjects1Objects, false, runtimeScene, false);
}if ( gdjs.LevelselectCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.LevelselectCode.GDselectorObjects1.length;i<l;++i) {
    if ( gdjs.LevelselectCode.GDselectorObjects1[i].getVariableNumber(gdjs.LevelselectCode.GDselectorObjects1[i].getVariables().getFromIndex(0)) == (gdjs.RuntimeObject.getVariableNumber(((gdjs.LevelselectCode.GDobj_95btn_95levelObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.LevelselectCode.GDobj_95btn_95levelObjects1[0].getVariables()).getFromIndex(0))) ) {
        gdjs.LevelselectCode.condition1IsTrue_0.val = true;
        gdjs.LevelselectCode.GDselectorObjects1[k] = gdjs.LevelselectCode.GDselectorObjects1[i];
        ++k;
    }
}
gdjs.LevelselectCode.GDselectorObjects1.length = k;}}
if (gdjs.LevelselectCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.LevelselectCode.eventsList14(runtimeScene);} //End of subevents
}

}


};gdjs.LevelselectCode.eventsList16 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("obj_btn_start"), gdjs.LevelselectCode.GDobj_95btn_95startObjects1);
gdjs.copyArray(runtimeScene.getObjects("selector"), gdjs.LevelselectCode.GDselectorObjects1);

gdjs.LevelselectCode.condition0IsTrue_0.val = false;
gdjs.LevelselectCode.condition1IsTrue_0.val = false;
gdjs.LevelselectCode.condition2IsTrue_0.val = false;
{
gdjs.LevelselectCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.LevelselectCode.mapOfGDgdjs_46LevelselectCode_46GDobj_9595btn_9595startObjects1Objects, runtimeScene, true, false);
}if ( gdjs.LevelselectCode.condition0IsTrue_0.val ) {
{
gdjs.LevelselectCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.LevelselectCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.LevelselectCode.GDselectorObjects1.length;i<l;++i) {
    if ( gdjs.LevelselectCode.GDselectorObjects1[i].getVariableNumber(gdjs.LevelselectCode.GDselectorObjects1[i].getVariables().getFromIndex(0)) <= gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("max_level_reached")) ) {
        gdjs.LevelselectCode.condition2IsTrue_0.val = true;
        gdjs.LevelselectCode.GDselectorObjects1[k] = gdjs.LevelselectCode.GDselectorObjects1[i];
        ++k;
    }
}
gdjs.LevelselectCode.GDselectorObjects1.length = k;}}
}
if (gdjs.LevelselectCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.LevelselectCode.eventsList15(runtimeScene);} //End of subevents
}

}


};gdjs.LevelselectCode.eventsList17 = function(runtimeScene) {

{


gdjs.LevelselectCode.eventsList8(runtimeScene);
}


{


gdjs.LevelselectCode.eventsList9(runtimeScene);
}


{


gdjs.LevelselectCode.eventsList11(runtimeScene);
}


{


gdjs.LevelselectCode.eventsList13(runtimeScene);
}


{


gdjs.LevelselectCode.eventsList16(runtimeScene);
}


};

gdjs.LevelselectCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.LevelselectCode.GDcursorObjects1.length = 0;
gdjs.LevelselectCode.GDcursorObjects2.length = 0;
gdjs.LevelselectCode.GDcursorObjects3.length = 0;
gdjs.LevelselectCode.GDcursorObjects4.length = 0;
gdjs.LevelselectCode.GDcursorObjects5.length = 0;
gdjs.LevelselectCode.GDlevel_951Objects1.length = 0;
gdjs.LevelselectCode.GDlevel_951Objects2.length = 0;
gdjs.LevelselectCode.GDlevel_951Objects3.length = 0;
gdjs.LevelselectCode.GDlevel_951Objects4.length = 0;
gdjs.LevelselectCode.GDlevel_951Objects5.length = 0;
gdjs.LevelselectCode.GDobj_95btn_95levelObjects1.length = 0;
gdjs.LevelselectCode.GDobj_95btn_95levelObjects2.length = 0;
gdjs.LevelselectCode.GDobj_95btn_95levelObjects3.length = 0;
gdjs.LevelselectCode.GDobj_95btn_95levelObjects4.length = 0;
gdjs.LevelselectCode.GDobj_95btn_95levelObjects5.length = 0;
gdjs.LevelselectCode.GDlevel_95selectObjects1.length = 0;
gdjs.LevelselectCode.GDlevel_95selectObjects2.length = 0;
gdjs.LevelselectCode.GDlevel_95selectObjects3.length = 0;
gdjs.LevelselectCode.GDlevel_95selectObjects4.length = 0;
gdjs.LevelselectCode.GDlevel_95selectObjects5.length = 0;
gdjs.LevelselectCode.GDobj_95btn_95backObjects1.length = 0;
gdjs.LevelselectCode.GDobj_95btn_95backObjects2.length = 0;
gdjs.LevelselectCode.GDobj_95btn_95backObjects3.length = 0;
gdjs.LevelselectCode.GDobj_95btn_95backObjects4.length = 0;
gdjs.LevelselectCode.GDobj_95btn_95backObjects5.length = 0;
gdjs.LevelselectCode.GDobj_95btn_95startObjects1.length = 0;
gdjs.LevelselectCode.GDobj_95btn_95startObjects2.length = 0;
gdjs.LevelselectCode.GDobj_95btn_95startObjects3.length = 0;
gdjs.LevelselectCode.GDobj_95btn_95startObjects4.length = 0;
gdjs.LevelselectCode.GDobj_95btn_95startObjects5.length = 0;
gdjs.LevelselectCode.GDselectorObjects1.length = 0;
gdjs.LevelselectCode.GDselectorObjects2.length = 0;
gdjs.LevelselectCode.GDselectorObjects3.length = 0;
gdjs.LevelselectCode.GDselectorObjects4.length = 0;
gdjs.LevelselectCode.GDselectorObjects5.length = 0;
gdjs.LevelselectCode.GDhud_95boxObjects1.length = 0;
gdjs.LevelselectCode.GDhud_95boxObjects2.length = 0;
gdjs.LevelselectCode.GDhud_95boxObjects3.length = 0;
gdjs.LevelselectCode.GDhud_95boxObjects4.length = 0;
gdjs.LevelselectCode.GDhud_95boxObjects5.length = 0;

gdjs.LevelselectCode.eventsList17(runtimeScene);
return;

}

gdjs['LevelselectCode'] = gdjs.LevelselectCode;
