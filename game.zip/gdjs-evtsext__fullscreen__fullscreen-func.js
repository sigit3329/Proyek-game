gdjs.evtsExt__Fullscreen__Fullscreen = {};

gdjs.evtsExt__Fullscreen__Fullscreen.conditionTrue_0 = {val:false};
gdjs.evtsExt__Fullscreen__Fullscreen.condition0IsTrue_0 = {val:false};
gdjs.evtsExt__Fullscreen__Fullscreen.condition1IsTrue_0 = {val:false};
gdjs.evtsExt__Fullscreen__Fullscreen.condition2IsTrue_0 = {val:false};
gdjs.evtsExt__Fullscreen__Fullscreen.conditionTrue_1 = {val:false};
gdjs.evtsExt__Fullscreen__Fullscreen.condition0IsTrue_1 = {val:false};
gdjs.evtsExt__Fullscreen__Fullscreen.condition1IsTrue_1 = {val:false};
gdjs.evtsExt__Fullscreen__Fullscreen.condition2IsTrue_1 = {val:false};


gdjs.evtsExt__Fullscreen__Fullscreen.eventsList0 = function(runtimeScene, eventsFunctionContext) {

{


gdjs.evtsExt__Fullscreen__Fullscreen.condition0IsTrue_0.val = false;
{
gdjs.evtsExt__Fullscreen__Fullscreen.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableBoolean(runtimeScene.getGame().getVariables().get("fullscreen"), true);
}if (gdjs.evtsExt__Fullscreen__Fullscreen.condition0IsTrue_0.val) {
{gdjs.evtTools.window.setFullScreen(runtimeScene, true, true);
}}

}


{


gdjs.evtsExt__Fullscreen__Fullscreen.condition0IsTrue_0.val = false;
{
gdjs.evtsExt__Fullscreen__Fullscreen.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableBoolean(runtimeScene.getGame().getVariables().get("fullscreen"), false);
}if (gdjs.evtsExt__Fullscreen__Fullscreen.condition0IsTrue_0.val) {
{gdjs.evtTools.window.setFullScreen(runtimeScene, false, true);
}}

}


};gdjs.evtsExt__Fullscreen__Fullscreen.eventsList1 = function(runtimeScene, eventsFunctionContext) {

{


gdjs.evtsExt__Fullscreen__Fullscreen.condition0IsTrue_0.val = false;
gdjs.evtsExt__Fullscreen__Fullscreen.condition1IsTrue_0.val = false;
{
gdjs.evtsExt__Fullscreen__Fullscreen.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "f");
}if ( gdjs.evtsExt__Fullscreen__Fullscreen.condition0IsTrue_0.val ) {
{
{gdjs.evtsExt__Fullscreen__Fullscreen.conditionTrue_1 = gdjs.evtsExt__Fullscreen__Fullscreen.condition1IsTrue_0;
gdjs.evtsExt__Fullscreen__Fullscreen.conditionTrue_1.val = eventsFunctionContext.getOnceTriggers().triggerOnce(11990092);
}
}}
if (gdjs.evtsExt__Fullscreen__Fullscreen.condition1IsTrue_0.val) {
{gdjs.evtTools.common.toggleVariableBoolean(runtimeScene.getGame().getVariables().get("fullscreen"));
}
{ //Subevents
gdjs.evtsExt__Fullscreen__Fullscreen.eventsList0(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__Fullscreen__Fullscreen.eventsList2 = function(runtimeScene, eventsFunctionContext) {

{


gdjs.evtsExt__Fullscreen__Fullscreen.condition0IsTrue_0.val = false;
gdjs.evtsExt__Fullscreen__Fullscreen.condition1IsTrue_0.val = false;
{
gdjs.evtsExt__Fullscreen__Fullscreen.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Escape");
}if ( gdjs.evtsExt__Fullscreen__Fullscreen.condition0IsTrue_0.val ) {
{
{gdjs.evtsExt__Fullscreen__Fullscreen.conditionTrue_1 = gdjs.evtsExt__Fullscreen__Fullscreen.condition1IsTrue_0;
gdjs.evtsExt__Fullscreen__Fullscreen.conditionTrue_1.val = eventsFunctionContext.getOnceTriggers().triggerOnce(11992516);
}
}}
if (gdjs.evtsExt__Fullscreen__Fullscreen.condition1IsTrue_0.val) {
{gdjs.evtTools.window.setFullScreen(runtimeScene, false, true);
}{gdjs.evtTools.common.setVariableBoolean(runtimeScene.getGame().getVariables().get("fullscreen"), false);
}}

}


};gdjs.evtsExt__Fullscreen__Fullscreen.eventsList3 = function(runtimeScene, eventsFunctionContext) {

{


gdjs.evtsExt__Fullscreen__Fullscreen.eventsList1(runtimeScene, eventsFunctionContext);
}


{


gdjs.evtsExt__Fullscreen__Fullscreen.eventsList2(runtimeScene, eventsFunctionContext);
}


};

gdjs.evtsExt__Fullscreen__Fullscreen.func = function(runtimeScene, parentEventsFunctionContext) {
var eventsFunctionContext = {
  _objectsMap: {
},
  _objectArraysMap: {
},
  _behaviorNamesMap: {
},
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName];
  },
  createObject: function(objectName) {
    var objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        eventsFunctionContext._objectArraysMap[objectName].push(object);
      }
      return object;    }
    return null;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
    return "";
  },
  getOnceTriggers: function() { return runtimeScene.getOnceTriggers(); }
};


gdjs.evtsExt__Fullscreen__Fullscreen.eventsList3(runtimeScene, eventsFunctionContext);
return;
}

