gdjs.evtsExt__Wait__WaitCondition = {};

gdjs.evtsExt__Wait__WaitCondition.conditionTrue_0 = {val:false};
gdjs.evtsExt__Wait__WaitCondition.condition0IsTrue_0 = {val:false};
gdjs.evtsExt__Wait__WaitCondition.condition1IsTrue_0 = {val:false};
gdjs.evtsExt__Wait__WaitCondition.condition2IsTrue_0 = {val:false};
gdjs.evtsExt__Wait__WaitCondition.conditionTrue_1 = {val:false};
gdjs.evtsExt__Wait__WaitCondition.condition0IsTrue_1 = {val:false};
gdjs.evtsExt__Wait__WaitCondition.condition1IsTrue_1 = {val:false};
gdjs.evtsExt__Wait__WaitCondition.condition2IsTrue_1 = {val:false};


gdjs.evtsExt__Wait__WaitCondition.eventsList0 = function(runtimeScene, eventsFunctionContext) {

{


gdjs.evtsExt__Wait__WaitCondition.condition0IsTrue_0.val = false;
{
gdjs.evtsExt__Wait__WaitCondition.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.evtsExt__Wait__WaitCondition.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? "" + eventsFunctionContext.getArgument("WaitTimerName") : ""));
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? "" + eventsFunctionContext.getArgument("WaitTimerName") : ""));
}}

}


{


gdjs.evtsExt__Wait__WaitCondition.condition0IsTrue_0.val = false;
gdjs.evtsExt__Wait__WaitCondition.condition1IsTrue_0.val = false;
{
gdjs.evtsExt__Wait__WaitCondition.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("WaitTime")) || 0 : 0), (typeof eventsFunctionContext !== 'undefined' ? "" + eventsFunctionContext.getArgument("WaitTimerName") : ""));
}if ( gdjs.evtsExt__Wait__WaitCondition.condition0IsTrue_0.val ) {
{
{gdjs.evtsExt__Wait__WaitCondition.conditionTrue_1 = gdjs.evtsExt__Wait__WaitCondition.condition1IsTrue_0;
gdjs.evtsExt__Wait__WaitCondition.conditionTrue_1.val = eventsFunctionContext.getOnceTriggers().triggerOnce(12025340);
}
}}
if (gdjs.evtsExt__Wait__WaitCondition.condition1IsTrue_0.val) {
{if (typeof eventsFunctionContext !== 'undefined') { eventsFunctionContext.returnValue = true; }}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? "" + eventsFunctionContext.getArgument("WaitTimerName") : ""));
}}

}


};gdjs.evtsExt__Wait__WaitCondition.eventsList1 = function(runtimeScene, eventsFunctionContext) {

{


gdjs.evtsExt__Wait__WaitCondition.eventsList0(runtimeScene, eventsFunctionContext);
}


};

gdjs.evtsExt__Wait__WaitCondition.func = function(runtimeScene, WaitTimerName, WaitTime, parentEventsFunctionContext) {
var eventsFunctionContext = {
  _objectsMap: {
},
  _objectArraysMap: {
},
  _behaviorNamesMap: {
},
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName];
  },
  createObject: function(objectName) {
    var objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        eventsFunctionContext._objectArraysMap[objectName].push(object);
      }
      return object;    }
    return null;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
if (argName === "WaitTimerName") return WaitTimerName;
if (argName === "WaitTime") return WaitTime;
    return "";
  },
  getOnceTriggers: function() { return runtimeScene.getOnceTriggers(); }
};


gdjs.evtsExt__Wait__WaitCondition.eventsList1(runtimeScene, eventsFunctionContext);
return !!eventsFunctionContext.returnValue;
}

