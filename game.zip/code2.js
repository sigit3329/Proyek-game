gdjs.EndSceneCode = {};
gdjs.EndSceneCode.GDcursorObjects1= [];
gdjs.EndSceneCode.GDcursorObjects2= [];
gdjs.EndSceneCode.GDcursorObjects3= [];
gdjs.EndSceneCode.GDcursorObjects4= [];
gdjs.EndSceneCode.GDcursorObjects5= [];
gdjs.EndSceneCode.GDlevel_951Objects1= [];
gdjs.EndSceneCode.GDlevel_951Objects2= [];
gdjs.EndSceneCode.GDlevel_951Objects3= [];
gdjs.EndSceneCode.GDlevel_951Objects4= [];
gdjs.EndSceneCode.GDlevel_951Objects5= [];
gdjs.EndSceneCode.GDlevel_95selectObjects1= [];
gdjs.EndSceneCode.GDlevel_95selectObjects2= [];
gdjs.EndSceneCode.GDlevel_95selectObjects3= [];
gdjs.EndSceneCode.GDlevel_95selectObjects4= [];
gdjs.EndSceneCode.GDlevel_95selectObjects5= [];
gdjs.EndSceneCode.GDobj_95btn_95backObjects1= [];
gdjs.EndSceneCode.GDobj_95btn_95backObjects2= [];
gdjs.EndSceneCode.GDobj_95btn_95backObjects3= [];
gdjs.EndSceneCode.GDobj_95btn_95backObjects4= [];
gdjs.EndSceneCode.GDobj_95btn_95backObjects5= [];
gdjs.EndSceneCode.GDtxt_95creditsObjects1= [];
gdjs.EndSceneCode.GDtxt_95creditsObjects2= [];
gdjs.EndSceneCode.GDtxt_95creditsObjects3= [];
gdjs.EndSceneCode.GDtxt_95creditsObjects4= [];
gdjs.EndSceneCode.GDtxt_95creditsObjects5= [];
gdjs.EndSceneCode.GDhud_95boxObjects1= [];
gdjs.EndSceneCode.GDhud_95boxObjects2= [];
gdjs.EndSceneCode.GDhud_95boxObjects3= [];
gdjs.EndSceneCode.GDhud_95boxObjects4= [];
gdjs.EndSceneCode.GDhud_95boxObjects5= [];

gdjs.EndSceneCode.conditionTrue_0 = {val:false};
gdjs.EndSceneCode.condition0IsTrue_0 = {val:false};
gdjs.EndSceneCode.condition1IsTrue_0 = {val:false};
gdjs.EndSceneCode.condition2IsTrue_0 = {val:false};
gdjs.EndSceneCode.conditionTrue_1 = {val:false};
gdjs.EndSceneCode.condition0IsTrue_1 = {val:false};
gdjs.EndSceneCode.condition1IsTrue_1 = {val:false};
gdjs.EndSceneCode.condition2IsTrue_1 = {val:false};


gdjs.EndSceneCode.eventsList0 = function(runtimeScene) {

{


gdjs.EndSceneCode.condition0IsTrue_0.val = false;
gdjs.EndSceneCode.condition1IsTrue_0.val = false;
{
gdjs.EndSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "first_play"));
}if ( gdjs.EndSceneCode.condition0IsTrue_0.val ) {
{
gdjs.EndSceneCode.condition1IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 0;
}}
if (gdjs.EndSceneCode.condition1IsTrue_0.val) {
{gdjs.evtTools.storage.writeNumberInJSONFile("game_data", "first_play", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(1);
}}

}


{


gdjs.EndSceneCode.condition0IsTrue_0.val = false;
{
gdjs.EndSceneCode.condition0IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "first_play");
}if (gdjs.EndSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.readNumberFromJSONFile("game_data", "first_play", runtimeScene, runtimeScene.getVariables().get("mm_first_play"));
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("mm_first_play")));
}}

}


};gdjs.EndSceneCode.eventsList1 = function(runtimeScene) {

{


gdjs.EndSceneCode.condition0IsTrue_0.val = false;
{
gdjs.EndSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "max_level_reached"));
}if (gdjs.EndSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.writeNumberInJSONFile("game_data", "max_level_reached", 1);
}{runtimeScene.getVariables().get("max_level_reached").setNumber(1);
}}

}


{


gdjs.EndSceneCode.condition0IsTrue_0.val = false;
{
gdjs.EndSceneCode.condition0IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "max_level_reached");
}if (gdjs.EndSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.readNumberFromJSONFile("game_data", "max_level_reached", runtimeScene, runtimeScene.getVariables().get("max_level_reached"));
}}

}


};gdjs.EndSceneCode.eventsList2 = function(runtimeScene) {

{


gdjs.EndSceneCode.condition0IsTrue_0.val = false;
{
gdjs.EndSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "game_level"));
}if (gdjs.EndSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.writeNumberInJSONFile("game_data", "game_level", 1);
}{runtimeScene.getVariables().get("game_level").setNumber(1);
}}

}


{


gdjs.EndSceneCode.condition0IsTrue_0.val = false;
{
gdjs.EndSceneCode.condition0IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "game_level");
}if (gdjs.EndSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.readNumberFromJSONFile("game_data", "game_level", runtimeScene, runtimeScene.getVariables().get("game_level"));
}}

}


};gdjs.EndSceneCode.eventsList3 = function(runtimeScene) {

{


gdjs.EndSceneCode.condition0IsTrue_0.val = false;
{
gdjs.EndSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "tutorial_number"));
}if (gdjs.EndSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.writeNumberInJSONFile("game_data", "tutorial_number", 1);
}{runtimeScene.getVariables().get("tutorial_number").setNumber(1);
}}

}


{


gdjs.EndSceneCode.condition0IsTrue_0.val = false;
{
gdjs.EndSceneCode.condition0IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "tutorial_number");
}if (gdjs.EndSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.readNumberFromJSONFile("game_data", "tutorial_number", runtimeScene, runtimeScene.getVariables().get("tutorial_number"));
}}

}


};gdjs.EndSceneCode.eventsList4 = function(runtimeScene) {

{


gdjs.EndSceneCode.condition0IsTrue_0.val = false;
{
gdjs.EndSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "coins"));
}if (gdjs.EndSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.writeNumberInJSONFile("game_data", "coins", 1200);
}{runtimeScene.getVariables().get("coins").setNumber(1200);
}}

}


{


gdjs.EndSceneCode.condition0IsTrue_0.val = false;
{
gdjs.EndSceneCode.condition0IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "coins");
}if (gdjs.EndSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.readNumberFromJSONFile("game_data", "coins", runtimeScene, runtimeScene.getVariables().get("coins"));
}}

}


};gdjs.EndSceneCode.eventsList5 = function(runtimeScene) {

{


gdjs.EndSceneCode.eventsList0(runtimeScene);
}


{


gdjs.EndSceneCode.eventsList1(runtimeScene);
}


{


gdjs.EndSceneCode.eventsList2(runtimeScene);
}


{


gdjs.EndSceneCode.eventsList3(runtimeScene);
}


{


gdjs.EndSceneCode.eventsList4(runtimeScene);
}


};gdjs.EndSceneCode.mapOfGDgdjs_46EndSceneCode_46GDcursorObjects1Objects = Hashtable.newFrom({"cursor": gdjs.EndSceneCode.GDcursorObjects1});gdjs.EndSceneCode.eventsList6 = function(runtimeScene) {

{


gdjs.EndSceneCode.condition0IsTrue_0.val = false;
{
gdjs.EndSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 1));
}if (gdjs.EndSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\music\\01-thetown.mp3", 1, true, 30, 1);
}}

}


};gdjs.EndSceneCode.eventsList7 = function(runtimeScene) {

{


gdjs.EndSceneCode.eventsList6(runtimeScene);
}


{



}


};gdjs.EndSceneCode.eventsList8 = function(runtimeScene) {

{



}


{


gdjs.EndSceneCode.condition0IsTrue_0.val = false;
{
gdjs.EndSceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.EndSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.EndSceneCode.eventsList5(runtimeScene);} //End of subevents
}

}


{


gdjs.EndSceneCode.condition0IsTrue_0.val = false;
{
gdjs.EndSceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.EndSceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("obj_btn_back"), gdjs.EndSceneCode.GDobj_95btn_95backObjects1);
gdjs.copyArray(runtimeScene.getObjects("txt_credits"), gdjs.EndSceneCode.GDtxt_95creditsObjects1);
gdjs.EndSceneCode.GDcursorObjects1.length = 0;

{gdjs.evtTools.input.hideCursor(runtimeScene);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.EndSceneCode.mapOfGDgdjs_46EndSceneCode_46GDcursorObjects1Objects, 0, 0, "HUD");
}{for(var i = 0, len = gdjs.EndSceneCode.GDcursorObjects1.length ;i < len;++i) {
    gdjs.EndSceneCode.GDcursorObjects1[i].setZOrder(1000);
}
}{for(var i = 0, len = gdjs.EndSceneCode.GDtxt_95creditsObjects1.length ;i < len;++i) {
    gdjs.EndSceneCode.GDtxt_95creditsObjects1[i].setGradient("LINEAR_VERTICAL", "255;255;255", "167;193;211", "72;113;167", "56;132;156");
}
}{for(var i = 0, len = gdjs.EndSceneCode.GDtxt_95creditsObjects1.length ;i < len;++i) {
    gdjs.EndSceneCode.GDtxt_95creditsObjects1[i].setOutline("0;0;0", 12);
}
}{for(var i = 0, len = gdjs.EndSceneCode.GDtxt_95creditsObjects1.length ;i < len;++i) {
    gdjs.EndSceneCode.GDtxt_95creditsObjects1[i].setCharacterSize(80);
}
}{for(var i = 0, len = gdjs.EndSceneCode.GDtxt_95creditsObjects1.length ;i < len;++i) {
    gdjs.EndSceneCode.GDtxt_95creditsObjects1[i].setScale(0.2);
}
}{for(var i = 0, len = gdjs.EndSceneCode.GDtxt_95creditsObjects1.length ;i < len;++i) {
    gdjs.EndSceneCode.GDtxt_95creditsObjects1[i].setWrapping(true);
}
}{for(var i = 0, len = gdjs.EndSceneCode.GDtxt_95creditsObjects1.length ;i < len;++i) {
    gdjs.EndSceneCode.GDtxt_95creditsObjects1[i].setWrappingWidth(1280);
}
}{for(var i = 0, len = gdjs.EndSceneCode.GDtxt_95creditsObjects1.length ;i < len;++i) {
    gdjs.EndSceneCode.GDtxt_95creditsObjects1[i].setPosition(gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2 - (gdjs.EndSceneCode.GDtxt_95creditsObjects1[i].getWidth()) / 2,(gdjs.EndSceneCode.GDtxt_95creditsObjects1[i].getY()));
}
}{for(var i = 0, len = gdjs.EndSceneCode.GDtxt_95creditsObjects1.length ;i < len;++i) {
    gdjs.EndSceneCode.GDtxt_95creditsObjects1[i].setTextAlignment("center");
}
}{for(var i = 0, len = gdjs.EndSceneCode.GDobj_95btn_95backObjects1.length ;i < len;++i) {
    gdjs.EndSceneCode.GDobj_95btn_95backObjects1[i].setPosition(gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2 - (gdjs.EndSceneCode.GDobj_95btn_95backObjects1[i].getWidth()) / 2,(gdjs.EndSceneCode.GDobj_95btn_95backObjects1[i].getPointY("")));
}
}
{ //Subevents
gdjs.EndSceneCode.eventsList7(runtimeScene);} //End of subevents
}

}


};gdjs.EndSceneCode.eventsList9 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("cursor"), gdjs.EndSceneCode.GDcursorObjects1);
{for(var i = 0, len = gdjs.EndSceneCode.GDcursorObjects1.length ;i < len;++i) {
    gdjs.EndSceneCode.GDcursorObjects1[i].setPosition(gdjs.evtTools.input.getMouseX(runtimeScene, "", 0),gdjs.evtTools.input.getMouseY(runtimeScene, "", 0));
}
}}

}


};gdjs.EndSceneCode.mapOfGDgdjs_46EndSceneCode_46GDobj_9595btn_9595backObjects1Objects = Hashtable.newFrom({"obj_btn_back": gdjs.EndSceneCode.GDobj_95btn_95backObjects1});gdjs.EndSceneCode.eventsList10 = function(runtimeScene) {

{


{
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "MainScene", true);
}}

}


};gdjs.EndSceneCode.eventsList11 = function(runtimeScene) {

{


gdjs.EndSceneCode.condition0IsTrue_0.val = false;
{
{gdjs.EndSceneCode.conditionTrue_1 = gdjs.EndSceneCode.condition0IsTrue_0;
gdjs.EndSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11645260);
}
}if (gdjs.EndSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\191756__leszek-szary__button-9.wav", 1, false, 100, 1);
}
{ //Subevents
gdjs.EndSceneCode.eventsList10(runtimeScene);} //End of subevents
}

}


};gdjs.EndSceneCode.eventsList12 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("obj_btn_back"), gdjs.EndSceneCode.GDobj_95btn_95backObjects1);

gdjs.EndSceneCode.condition0IsTrue_0.val = false;
gdjs.EndSceneCode.condition1IsTrue_0.val = false;
{
gdjs.EndSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.EndSceneCode.mapOfGDgdjs_46EndSceneCode_46GDobj_9595btn_9595backObjects1Objects, runtimeScene, true, false);
}if ( gdjs.EndSceneCode.condition0IsTrue_0.val ) {
{
gdjs.EndSceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.EndSceneCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.EndSceneCode.eventsList11(runtimeScene);} //End of subevents
}

}


};gdjs.EndSceneCode.eventsList13 = function(runtimeScene) {

{


gdjs.EndSceneCode.eventsList8(runtimeScene);
}


{


gdjs.EndSceneCode.eventsList9(runtimeScene);
}


{


gdjs.EndSceneCode.eventsList12(runtimeScene);
}


};

gdjs.EndSceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.EndSceneCode.GDcursorObjects1.length = 0;
gdjs.EndSceneCode.GDcursorObjects2.length = 0;
gdjs.EndSceneCode.GDcursorObjects3.length = 0;
gdjs.EndSceneCode.GDcursorObjects4.length = 0;
gdjs.EndSceneCode.GDcursorObjects5.length = 0;
gdjs.EndSceneCode.GDlevel_951Objects1.length = 0;
gdjs.EndSceneCode.GDlevel_951Objects2.length = 0;
gdjs.EndSceneCode.GDlevel_951Objects3.length = 0;
gdjs.EndSceneCode.GDlevel_951Objects4.length = 0;
gdjs.EndSceneCode.GDlevel_951Objects5.length = 0;
gdjs.EndSceneCode.GDlevel_95selectObjects1.length = 0;
gdjs.EndSceneCode.GDlevel_95selectObjects2.length = 0;
gdjs.EndSceneCode.GDlevel_95selectObjects3.length = 0;
gdjs.EndSceneCode.GDlevel_95selectObjects4.length = 0;
gdjs.EndSceneCode.GDlevel_95selectObjects5.length = 0;
gdjs.EndSceneCode.GDobj_95btn_95backObjects1.length = 0;
gdjs.EndSceneCode.GDobj_95btn_95backObjects2.length = 0;
gdjs.EndSceneCode.GDobj_95btn_95backObjects3.length = 0;
gdjs.EndSceneCode.GDobj_95btn_95backObjects4.length = 0;
gdjs.EndSceneCode.GDobj_95btn_95backObjects5.length = 0;
gdjs.EndSceneCode.GDtxt_95creditsObjects1.length = 0;
gdjs.EndSceneCode.GDtxt_95creditsObjects2.length = 0;
gdjs.EndSceneCode.GDtxt_95creditsObjects3.length = 0;
gdjs.EndSceneCode.GDtxt_95creditsObjects4.length = 0;
gdjs.EndSceneCode.GDtxt_95creditsObjects5.length = 0;
gdjs.EndSceneCode.GDhud_95boxObjects1.length = 0;
gdjs.EndSceneCode.GDhud_95boxObjects2.length = 0;
gdjs.EndSceneCode.GDhud_95boxObjects3.length = 0;
gdjs.EndSceneCode.GDhud_95boxObjects4.length = 0;
gdjs.EndSceneCode.GDhud_95boxObjects5.length = 0;

gdjs.EndSceneCode.eventsList13(runtimeScene);
return;

}

gdjs['EndSceneCode'] = gdjs.EndSceneCode;
