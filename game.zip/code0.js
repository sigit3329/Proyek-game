gdjs.SplashSceneCode = {};
gdjs.SplashSceneCode.GDcursorObjects1= [];
gdjs.SplashSceneCode.GDcursorObjects2= [];
gdjs.SplashSceneCode.GDcursorObjects3= [];
gdjs.SplashSceneCode.GDtxt_95creditsObjects1= [];
gdjs.SplashSceneCode.GDtxt_95creditsObjects2= [];
gdjs.SplashSceneCode.GDtxt_95creditsObjects3= [];

gdjs.SplashSceneCode.conditionTrue_0 = {val:false};
gdjs.SplashSceneCode.condition0IsTrue_0 = {val:false};
gdjs.SplashSceneCode.condition1IsTrue_0 = {val:false};


gdjs.SplashSceneCode.eventsList0 = function(runtimeScene) {

{


gdjs.SplashSceneCode.condition0IsTrue_0.val = false;
{
gdjs.SplashSceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.SplashSceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("txt_credits"), gdjs.SplashSceneCode.GDtxt_95creditsObjects1);
{for(var i = 0, len = gdjs.SplashSceneCode.GDtxt_95creditsObjects1.length ;i < len;++i) {
    gdjs.SplashSceneCode.GDtxt_95creditsObjects1[i].setCharacterSize(100);
}
}{for(var i = 0, len = gdjs.SplashSceneCode.GDtxt_95creditsObjects1.length ;i < len;++i) {
    gdjs.SplashSceneCode.GDtxt_95creditsObjects1[i].setGradient("LINEAR_VERTICAL", "236;230;158", "216;206;89", "173;68;80", "150;13;30");
}
}{for(var i = 0, len = gdjs.SplashSceneCode.GDtxt_95creditsObjects1.length ;i < len;++i) {
    gdjs.SplashSceneCode.GDtxt_95creditsObjects1[i].setOutline("0;0;0", 14);
}
}{for(var i = 0, len = gdjs.SplashSceneCode.GDtxt_95creditsObjects1.length ;i < len;++i) {
    gdjs.SplashSceneCode.GDtxt_95creditsObjects1[i].setScale(0.25);
}
}{for(var i = 0, len = gdjs.SplashSceneCode.GDtxt_95creditsObjects1.length ;i < len;++i) {
    gdjs.SplashSceneCode.GDtxt_95creditsObjects1[i].setWrapping(true);
}
}{for(var i = 0, len = gdjs.SplashSceneCode.GDtxt_95creditsObjects1.length ;i < len;++i) {
    gdjs.SplashSceneCode.GDtxt_95creditsObjects1[i].setWrappingWidth(1600);
}
}{for(var i = 0, len = gdjs.SplashSceneCode.GDtxt_95creditsObjects1.length ;i < len;++i) {
    gdjs.SplashSceneCode.GDtxt_95creditsObjects1[i].setTextAlignment("center");
}
}{for(var i = 0, len = gdjs.SplashSceneCode.GDtxt_95creditsObjects1.length ;i < len;++i) {
    gdjs.SplashSceneCode.GDtxt_95creditsObjects1[i].setPosition(gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2 - (gdjs.SplashSceneCode.GDtxt_95creditsObjects1[i].getWidth()) / 2,gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) / 2 - (gdjs.SplashSceneCode.GDtxt_95creditsObjects1[i].getHeight()) / 2);
}
}{for(var i = 0, len = gdjs.SplashSceneCode.GDtxt_95creditsObjects1.length ;i < len;++i) {
    gdjs.SplashSceneCode.GDtxt_95creditsObjects1[i].setPadding(80);
}
}}

}


};gdjs.SplashSceneCode.eventsList1 = function(runtimeScene) {

{


gdjs.SplashSceneCode.condition0IsTrue_0.val = false;
{
gdjs.SplashSceneCode.condition0IsTrue_0.val = gdjs.evtsExt__Wait__WaitCondition.func(runtimeScene, "start", 2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.SplashSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "MainScene", true);
}}

}


{


{
{gdjs.evtsExt__Wait__WaitAction.func(runtimeScene, "start", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.SplashSceneCode.eventsList2 = function(runtimeScene) {

{


{
}

}


{


gdjs.SplashSceneCode.eventsList0(runtimeScene);
}


{


gdjs.SplashSceneCode.eventsList1(runtimeScene);
}


};

gdjs.SplashSceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.SplashSceneCode.GDcursorObjects1.length = 0;
gdjs.SplashSceneCode.GDcursorObjects2.length = 0;
gdjs.SplashSceneCode.GDcursorObjects3.length = 0;
gdjs.SplashSceneCode.GDtxt_95creditsObjects1.length = 0;
gdjs.SplashSceneCode.GDtxt_95creditsObjects2.length = 0;
gdjs.SplashSceneCode.GDtxt_95creditsObjects3.length = 0;

gdjs.SplashSceneCode.eventsList2(runtimeScene);
return;

}

gdjs['SplashSceneCode'] = gdjs.SplashSceneCode;
