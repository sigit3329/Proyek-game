gdjs.GameSceneCode = {};
gdjs.GameSceneCode.GDenemy_950Objects2_1final = [];

gdjs.GameSceneCode.GDenemy_950Objects3_1final = [];

gdjs.GameSceneCode.GDenemy_951Objects2_1final = [];

gdjs.GameSceneCode.GDenemy_951Objects3_1final = [];

gdjs.GameSceneCode.GDenemy_952Objects2_1final = [];

gdjs.GameSceneCode.GDenemy_952Objects3_1final = [];

gdjs.GameSceneCode.GDtower_95btnObjects3_2final = [];

gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects2_1final = [];

gdjs.GameSceneCode.forEachCount0_2 = 0;

gdjs.GameSceneCode.forEachCount0_4 = 0;

gdjs.GameSceneCode.forEachCount1_2 = 0;

gdjs.GameSceneCode.forEachCount1_4 = 0;

gdjs.GameSceneCode.forEachCount2_2 = 0;

gdjs.GameSceneCode.forEachCount2_4 = 0;

gdjs.GameSceneCode.forEachIndex2 = 0;

gdjs.GameSceneCode.forEachIndex3 = 0;

gdjs.GameSceneCode.forEachIndex4 = 0;

gdjs.GameSceneCode.forEachObjects2 = [];

gdjs.GameSceneCode.forEachObjects3 = [];

gdjs.GameSceneCode.forEachObjects4 = [];

gdjs.GameSceneCode.forEachTemporary3 = null;

gdjs.GameSceneCode.forEachTemporary4 = null;

gdjs.GameSceneCode.forEachTotalCount2 = 0;

gdjs.GameSceneCode.forEachTotalCount3 = 0;

gdjs.GameSceneCode.forEachTotalCount4 = 0;

gdjs.GameSceneCode.repeatCount2 = 0;

gdjs.GameSceneCode.repeatCount4 = 0;

gdjs.GameSceneCode.repeatIndex2 = 0;

gdjs.GameSceneCode.repeatIndex4 = 0;

gdjs.GameSceneCode.GDcursorObjects1= [];
gdjs.GameSceneCode.GDcursorObjects2= [];
gdjs.GameSceneCode.GDcursorObjects3= [];
gdjs.GameSceneCode.GDcursorObjects4= [];
gdjs.GameSceneCode.GDcursorObjects5= [];
gdjs.GameSceneCode.GDcursorObjects6= [];
gdjs.GameSceneCode.GDcursorObjects7= [];
gdjs.GameSceneCode.GDlevel_956Objects1= [];
gdjs.GameSceneCode.GDlevel_956Objects2= [];
gdjs.GameSceneCode.GDlevel_956Objects3= [];
gdjs.GameSceneCode.GDlevel_956Objects4= [];
gdjs.GameSceneCode.GDlevel_956Objects5= [];
gdjs.GameSceneCode.GDlevel_956Objects6= [];
gdjs.GameSceneCode.GDlevel_956Objects7= [];
gdjs.GameSceneCode.GDlevel_955Objects1= [];
gdjs.GameSceneCode.GDlevel_955Objects2= [];
gdjs.GameSceneCode.GDlevel_955Objects3= [];
gdjs.GameSceneCode.GDlevel_955Objects4= [];
gdjs.GameSceneCode.GDlevel_955Objects5= [];
gdjs.GameSceneCode.GDlevel_955Objects6= [];
gdjs.GameSceneCode.GDlevel_955Objects7= [];
gdjs.GameSceneCode.GDlevel_954Objects1= [];
gdjs.GameSceneCode.GDlevel_954Objects2= [];
gdjs.GameSceneCode.GDlevel_954Objects3= [];
gdjs.GameSceneCode.GDlevel_954Objects4= [];
gdjs.GameSceneCode.GDlevel_954Objects5= [];
gdjs.GameSceneCode.GDlevel_954Objects6= [];
gdjs.GameSceneCode.GDlevel_954Objects7= [];
gdjs.GameSceneCode.GDlevel_953Objects1= [];
gdjs.GameSceneCode.GDlevel_953Objects2= [];
gdjs.GameSceneCode.GDlevel_953Objects3= [];
gdjs.GameSceneCode.GDlevel_953Objects4= [];
gdjs.GameSceneCode.GDlevel_953Objects5= [];
gdjs.GameSceneCode.GDlevel_953Objects6= [];
gdjs.GameSceneCode.GDlevel_953Objects7= [];
gdjs.GameSceneCode.GDlevel_952Objects1= [];
gdjs.GameSceneCode.GDlevel_952Objects2= [];
gdjs.GameSceneCode.GDlevel_952Objects3= [];
gdjs.GameSceneCode.GDlevel_952Objects4= [];
gdjs.GameSceneCode.GDlevel_952Objects5= [];
gdjs.GameSceneCode.GDlevel_952Objects6= [];
gdjs.GameSceneCode.GDlevel_952Objects7= [];
gdjs.GameSceneCode.GDlevel_951Objects1= [];
gdjs.GameSceneCode.GDlevel_951Objects2= [];
gdjs.GameSceneCode.GDlevel_951Objects3= [];
gdjs.GameSceneCode.GDlevel_951Objects4= [];
gdjs.GameSceneCode.GDlevel_951Objects5= [];
gdjs.GameSceneCode.GDlevel_951Objects6= [];
gdjs.GameSceneCode.GDlevel_951Objects7= [];
gdjs.GameSceneCode.GDtower_953_95topObjects1= [];
gdjs.GameSceneCode.GDtower_953_95topObjects2= [];
gdjs.GameSceneCode.GDtower_953_95topObjects3= [];
gdjs.GameSceneCode.GDtower_953_95topObjects4= [];
gdjs.GameSceneCode.GDtower_953_95topObjects5= [];
gdjs.GameSceneCode.GDtower_953_95topObjects6= [];
gdjs.GameSceneCode.GDtower_953_95topObjects7= [];
gdjs.GameSceneCode.GDtower_952_95topObjects1= [];
gdjs.GameSceneCode.GDtower_952_95topObjects2= [];
gdjs.GameSceneCode.GDtower_952_95topObjects3= [];
gdjs.GameSceneCode.GDtower_952_95topObjects4= [];
gdjs.GameSceneCode.GDtower_952_95topObjects5= [];
gdjs.GameSceneCode.GDtower_952_95topObjects6= [];
gdjs.GameSceneCode.GDtower_952_95topObjects7= [];
gdjs.GameSceneCode.GDtower_952_95bulletObjects1= [];
gdjs.GameSceneCode.GDtower_952_95bulletObjects2= [];
gdjs.GameSceneCode.GDtower_952_95bulletObjects3= [];
gdjs.GameSceneCode.GDtower_952_95bulletObjects4= [];
gdjs.GameSceneCode.GDtower_952_95bulletObjects5= [];
gdjs.GameSceneCode.GDtower_952_95bulletObjects6= [];
gdjs.GameSceneCode.GDtower_952_95bulletObjects7= [];
gdjs.GameSceneCode.GDtower_951_95topObjects1= [];
gdjs.GameSceneCode.GDtower_951_95topObjects2= [];
gdjs.GameSceneCode.GDtower_951_95topObjects3= [];
gdjs.GameSceneCode.GDtower_951_95topObjects4= [];
gdjs.GameSceneCode.GDtower_951_95topObjects5= [];
gdjs.GameSceneCode.GDtower_951_95topObjects6= [];
gdjs.GameSceneCode.GDtower_951_95topObjects7= [];
gdjs.GameSceneCode.GDtower_951_95bulletObjects1= [];
gdjs.GameSceneCode.GDtower_951_95bulletObjects2= [];
gdjs.GameSceneCode.GDtower_951_95bulletObjects3= [];
gdjs.GameSceneCode.GDtower_951_95bulletObjects4= [];
gdjs.GameSceneCode.GDtower_951_95bulletObjects5= [];
gdjs.GameSceneCode.GDtower_951_95bulletObjects6= [];
gdjs.GameSceneCode.GDtower_951_95bulletObjects7= [];
gdjs.GameSceneCode.GDtowerObjects1= [];
gdjs.GameSceneCode.GDtowerObjects2= [];
gdjs.GameSceneCode.GDtowerObjects3= [];
gdjs.GameSceneCode.GDtowerObjects4= [];
gdjs.GameSceneCode.GDtowerObjects5= [];
gdjs.GameSceneCode.GDtowerObjects6= [];
gdjs.GameSceneCode.GDtowerObjects7= [];
gdjs.GameSceneCode.GDtower_95btnObjects1= [];
gdjs.GameSceneCode.GDtower_95btnObjects2= [];
gdjs.GameSceneCode.GDtower_95btnObjects3= [];
gdjs.GameSceneCode.GDtower_95btnObjects4= [];
gdjs.GameSceneCode.GDtower_95btnObjects5= [];
gdjs.GameSceneCode.GDtower_95btnObjects6= [];
gdjs.GameSceneCode.GDtower_95btnObjects7= [];
gdjs.GameSceneCode.GDtower_95selectedObjects1= [];
gdjs.GameSceneCode.GDtower_95selectedObjects2= [];
gdjs.GameSceneCode.GDtower_95selectedObjects3= [];
gdjs.GameSceneCode.GDtower_95selectedObjects4= [];
gdjs.GameSceneCode.GDtower_95selectedObjects5= [];
gdjs.GameSceneCode.GDtower_95selectedObjects6= [];
gdjs.GameSceneCode.GDtower_95selectedObjects7= [];
gdjs.GameSceneCode.GDtower_951_95bullet_95trailObjects1= [];
gdjs.GameSceneCode.GDtower_951_95bullet_95trailObjects2= [];
gdjs.GameSceneCode.GDtower_951_95bullet_95trailObjects3= [];
gdjs.GameSceneCode.GDtower_951_95bullet_95trailObjects4= [];
gdjs.GameSceneCode.GDtower_951_95bullet_95trailObjects5= [];
gdjs.GameSceneCode.GDtower_951_95bullet_95trailObjects6= [];
gdjs.GameSceneCode.GDtower_951_95bullet_95trailObjects7= [];
gdjs.GameSceneCode.GDtower_952_95bullet_95trailObjects1= [];
gdjs.GameSceneCode.GDtower_952_95bullet_95trailObjects2= [];
gdjs.GameSceneCode.GDtower_952_95bullet_95trailObjects3= [];
gdjs.GameSceneCode.GDtower_952_95bullet_95trailObjects4= [];
gdjs.GameSceneCode.GDtower_952_95bullet_95trailObjects5= [];
gdjs.GameSceneCode.GDtower_952_95bullet_95trailObjects6= [];
gdjs.GameSceneCode.GDtower_952_95bullet_95trailObjects7= [];
gdjs.GameSceneCode.GDarrow_95explosionObjects1= [];
gdjs.GameSceneCode.GDarrow_95explosionObjects2= [];
gdjs.GameSceneCode.GDarrow_95explosionObjects3= [];
gdjs.GameSceneCode.GDarrow_95explosionObjects4= [];
gdjs.GameSceneCode.GDarrow_95explosionObjects5= [];
gdjs.GameSceneCode.GDarrow_95explosionObjects6= [];
gdjs.GameSceneCode.GDarrow_95explosionObjects7= [];
gdjs.GameSceneCode.GDupgrade_95barObjects1= [];
gdjs.GameSceneCode.GDupgrade_95barObjects2= [];
gdjs.GameSceneCode.GDupgrade_95barObjects3= [];
gdjs.GameSceneCode.GDupgrade_95barObjects4= [];
gdjs.GameSceneCode.GDupgrade_95barObjects5= [];
gdjs.GameSceneCode.GDupgrade_95barObjects6= [];
gdjs.GameSceneCode.GDupgrade_95barObjects7= [];
gdjs.GameSceneCode.GDenemy_952Objects1= [];
gdjs.GameSceneCode.GDenemy_952Objects2= [];
gdjs.GameSceneCode.GDenemy_952Objects3= [];
gdjs.GameSceneCode.GDenemy_952Objects4= [];
gdjs.GameSceneCode.GDenemy_952Objects5= [];
gdjs.GameSceneCode.GDenemy_952Objects6= [];
gdjs.GameSceneCode.GDenemy_952Objects7= [];
gdjs.GameSceneCode.GDenemy_951Objects1= [];
gdjs.GameSceneCode.GDenemy_951Objects2= [];
gdjs.GameSceneCode.GDenemy_951Objects3= [];
gdjs.GameSceneCode.GDenemy_951Objects4= [];
gdjs.GameSceneCode.GDenemy_951Objects5= [];
gdjs.GameSceneCode.GDenemy_951Objects6= [];
gdjs.GameSceneCode.GDenemy_951Objects7= [];
gdjs.GameSceneCode.GDenemy_950Objects1= [];
gdjs.GameSceneCode.GDenemy_950Objects2= [];
gdjs.GameSceneCode.GDenemy_950Objects3= [];
gdjs.GameSceneCode.GDenemy_950Objects4= [];
gdjs.GameSceneCode.GDenemy_950Objects5= [];
gdjs.GameSceneCode.GDenemy_950Objects6= [];
gdjs.GameSceneCode.GDenemy_950Objects7= [];
gdjs.GameSceneCode.GDend_95pathObjects1= [];
gdjs.GameSceneCode.GDend_95pathObjects2= [];
gdjs.GameSceneCode.GDend_95pathObjects3= [];
gdjs.GameSceneCode.GDend_95pathObjects4= [];
gdjs.GameSceneCode.GDend_95pathObjects5= [];
gdjs.GameSceneCode.GDend_95pathObjects6= [];
gdjs.GameSceneCode.GDend_95pathObjects7= [];
gdjs.GameSceneCode.GDstart_95pathObjects1= [];
gdjs.GameSceneCode.GDstart_95pathObjects2= [];
gdjs.GameSceneCode.GDstart_95pathObjects3= [];
gdjs.GameSceneCode.GDstart_95pathObjects4= [];
gdjs.GameSceneCode.GDstart_95pathObjects5= [];
gdjs.GameSceneCode.GDstart_95pathObjects6= [];
gdjs.GameSceneCode.GDstart_95pathObjects7= [];
gdjs.GameSceneCode.GDobstacleObjects1= [];
gdjs.GameSceneCode.GDobstacleObjects2= [];
gdjs.GameSceneCode.GDobstacleObjects3= [];
gdjs.GameSceneCode.GDobstacleObjects4= [];
gdjs.GameSceneCode.GDobstacleObjects5= [];
gdjs.GameSceneCode.GDobstacleObjects6= [];
gdjs.GameSceneCode.GDobstacleObjects7= [];
gdjs.GameSceneCode.GDtxt_95kills_95this_95waveObjects1= [];
gdjs.GameSceneCode.GDtxt_95kills_95this_95waveObjects2= [];
gdjs.GameSceneCode.GDtxt_95kills_95this_95waveObjects3= [];
gdjs.GameSceneCode.GDtxt_95kills_95this_95waveObjects4= [];
gdjs.GameSceneCode.GDtxt_95kills_95this_95waveObjects5= [];
gdjs.GameSceneCode.GDtxt_95kills_95this_95waveObjects6= [];
gdjs.GameSceneCode.GDtxt_95kills_95this_95waveObjects7= [];
gdjs.GameSceneCode.GDtxt_95enemies_95escapedObjects1= [];
gdjs.GameSceneCode.GDtxt_95enemies_95escapedObjects2= [];
gdjs.GameSceneCode.GDtxt_95enemies_95escapedObjects3= [];
gdjs.GameSceneCode.GDtxt_95enemies_95escapedObjects4= [];
gdjs.GameSceneCode.GDtxt_95enemies_95escapedObjects5= [];
gdjs.GameSceneCode.GDtxt_95enemies_95escapedObjects6= [];
gdjs.GameSceneCode.GDtxt_95enemies_95escapedObjects7= [];
gdjs.GameSceneCode.GDtxt_95waveObjects1= [];
gdjs.GameSceneCode.GDtxt_95waveObjects2= [];
gdjs.GameSceneCode.GDtxt_95waveObjects3= [];
gdjs.GameSceneCode.GDtxt_95waveObjects4= [];
gdjs.GameSceneCode.GDtxt_95waveObjects5= [];
gdjs.GameSceneCode.GDtxt_95waveObjects6= [];
gdjs.GameSceneCode.GDtxt_95waveObjects7= [];
gdjs.GameSceneCode.GDtxt_95coinsObjects1= [];
gdjs.GameSceneCode.GDtxt_95coinsObjects2= [];
gdjs.GameSceneCode.GDtxt_95coinsObjects3= [];
gdjs.GameSceneCode.GDtxt_95coinsObjects4= [];
gdjs.GameSceneCode.GDtxt_95coinsObjects5= [];
gdjs.GameSceneCode.GDtxt_95coinsObjects6= [];
gdjs.GameSceneCode.GDtxt_95coinsObjects7= [];
gdjs.GameSceneCode.GDtower_95panelObjects1= [];
gdjs.GameSceneCode.GDtower_95panelObjects2= [];
gdjs.GameSceneCode.GDtower_95panelObjects3= [];
gdjs.GameSceneCode.GDtower_95panelObjects4= [];
gdjs.GameSceneCode.GDtower_95panelObjects5= [];
gdjs.GameSceneCode.GDtower_95panelObjects6= [];
gdjs.GameSceneCode.GDtower_95panelObjects7= [];
gdjs.GameSceneCode.GDtower_95btn_95sellObjects1= [];
gdjs.GameSceneCode.GDtower_95btn_95sellObjects2= [];
gdjs.GameSceneCode.GDtower_95btn_95sellObjects3= [];
gdjs.GameSceneCode.GDtower_95btn_95sellObjects4= [];
gdjs.GameSceneCode.GDtower_95btn_95sellObjects5= [];
gdjs.GameSceneCode.GDtower_95btn_95sellObjects6= [];
gdjs.GameSceneCode.GDtower_95btn_95sellObjects7= [];
gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects1= [];
gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects2= [];
gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3= [];
gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects4= [];
gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects5= [];
gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects6= [];
gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects7= [];
gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects1= [];
gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects2= [];
gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects3= [];
gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects4= [];
gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects5= [];
gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects6= [];
gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects7= [];
gdjs.GameSceneCode.GDlevelupObjects1= [];
gdjs.GameSceneCode.GDlevelupObjects2= [];
gdjs.GameSceneCode.GDlevelupObjects3= [];
gdjs.GameSceneCode.GDlevelupObjects4= [];
gdjs.GameSceneCode.GDlevelupObjects5= [];
gdjs.GameSceneCode.GDlevelupObjects6= [];
gdjs.GameSceneCode.GDlevelupObjects7= [];
gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects1= [];
gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects2= [];
gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects3= [];
gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects4= [];
gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects5= [];
gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects6= [];
gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects7= [];
gdjs.GameSceneCode.GDtxt_95pausedObjects1= [];
gdjs.GameSceneCode.GDtxt_95pausedObjects2= [];
gdjs.GameSceneCode.GDtxt_95pausedObjects3= [];
gdjs.GameSceneCode.GDtxt_95pausedObjects4= [];
gdjs.GameSceneCode.GDtxt_95pausedObjects5= [];
gdjs.GameSceneCode.GDtxt_95pausedObjects6= [];
gdjs.GameSceneCode.GDtxt_95pausedObjects7= [];
gdjs.GameSceneCode.GDtxt_95rankingsObjects1= [];
gdjs.GameSceneCode.GDtxt_95rankingsObjects2= [];
gdjs.GameSceneCode.GDtxt_95rankingsObjects3= [];
gdjs.GameSceneCode.GDtxt_95rankingsObjects4= [];
gdjs.GameSceneCode.GDtxt_95rankingsObjects5= [];
gdjs.GameSceneCode.GDtxt_95rankingsObjects6= [];
gdjs.GameSceneCode.GDtxt_95rankingsObjects7= [];
gdjs.GameSceneCode.GDhud_95box2Objects1= [];
gdjs.GameSceneCode.GDhud_95box2Objects2= [];
gdjs.GameSceneCode.GDhud_95box2Objects3= [];
gdjs.GameSceneCode.GDhud_95box2Objects4= [];
gdjs.GameSceneCode.GDhud_95box2Objects5= [];
gdjs.GameSceneCode.GDhud_95box2Objects6= [];
gdjs.GameSceneCode.GDhud_95box2Objects7= [];
gdjs.GameSceneCode.GDhud_95boxObjects1= [];
gdjs.GameSceneCode.GDhud_95boxObjects2= [];
gdjs.GameSceneCode.GDhud_95boxObjects3= [];
gdjs.GameSceneCode.GDhud_95boxObjects4= [];
gdjs.GameSceneCode.GDhud_95boxObjects5= [];
gdjs.GameSceneCode.GDhud_95boxObjects6= [];
gdjs.GameSceneCode.GDhud_95boxObjects7= [];
gdjs.GameSceneCode.GDtxt_95debug_951Objects1= [];
gdjs.GameSceneCode.GDtxt_95debug_951Objects2= [];
gdjs.GameSceneCode.GDtxt_95debug_951Objects3= [];
gdjs.GameSceneCode.GDtxt_95debug_951Objects4= [];
gdjs.GameSceneCode.GDtxt_95debug_951Objects5= [];
gdjs.GameSceneCode.GDtxt_95debug_951Objects6= [];
gdjs.GameSceneCode.GDtxt_95debug_951Objects7= [];
gdjs.GameSceneCode.GDhud_95bottom_95panelObjects1= [];
gdjs.GameSceneCode.GDhud_95bottom_95panelObjects2= [];
gdjs.GameSceneCode.GDhud_95bottom_95panelObjects3= [];
gdjs.GameSceneCode.GDhud_95bottom_95panelObjects4= [];
gdjs.GameSceneCode.GDhud_95bottom_95panelObjects5= [];
gdjs.GameSceneCode.GDhud_95bottom_95panelObjects6= [];
gdjs.GameSceneCode.GDhud_95bottom_95panelObjects7= [];
gdjs.GameSceneCode.GDvictoryObjects1= [];
gdjs.GameSceneCode.GDvictoryObjects2= [];
gdjs.GameSceneCode.GDvictoryObjects3= [];
gdjs.GameSceneCode.GDvictoryObjects4= [];
gdjs.GameSceneCode.GDvictoryObjects5= [];
gdjs.GameSceneCode.GDvictoryObjects6= [];
gdjs.GameSceneCode.GDvictoryObjects7= [];
gdjs.GameSceneCode.GDvictory_95effectObjects1= [];
gdjs.GameSceneCode.GDvictory_95effectObjects2= [];
gdjs.GameSceneCode.GDvictory_95effectObjects3= [];
gdjs.GameSceneCode.GDvictory_95effectObjects4= [];
gdjs.GameSceneCode.GDvictory_95effectObjects5= [];
gdjs.GameSceneCode.GDvictory_95effectObjects6= [];
gdjs.GameSceneCode.GDvictory_95effectObjects7= [];
gdjs.GameSceneCode.GDobj_95btn_95continueObjects1= [];
gdjs.GameSceneCode.GDobj_95btn_95continueObjects2= [];
gdjs.GameSceneCode.GDobj_95btn_95continueObjects3= [];
gdjs.GameSceneCode.GDobj_95btn_95continueObjects4= [];
gdjs.GameSceneCode.GDobj_95btn_95continueObjects5= [];
gdjs.GameSceneCode.GDobj_95btn_95continueObjects6= [];
gdjs.GameSceneCode.GDobj_95btn_95continueObjects7= [];
gdjs.GameSceneCode.GDobj_95btn_95nextObjects1= [];
gdjs.GameSceneCode.GDobj_95btn_95nextObjects2= [];
gdjs.GameSceneCode.GDobj_95btn_95nextObjects3= [];
gdjs.GameSceneCode.GDobj_95btn_95nextObjects4= [];
gdjs.GameSceneCode.GDobj_95btn_95nextObjects5= [];
gdjs.GameSceneCode.GDobj_95btn_95nextObjects6= [];
gdjs.GameSceneCode.GDobj_95btn_95nextObjects7= [];
gdjs.GameSceneCode.GDobj_95btn_95levelselectObjects1= [];
gdjs.GameSceneCode.GDobj_95btn_95levelselectObjects2= [];
gdjs.GameSceneCode.GDobj_95btn_95levelselectObjects3= [];
gdjs.GameSceneCode.GDobj_95btn_95levelselectObjects4= [];
gdjs.GameSceneCode.GDobj_95btn_95levelselectObjects5= [];
gdjs.GameSceneCode.GDobj_95btn_95levelselectObjects6= [];
gdjs.GameSceneCode.GDobj_95btn_95levelselectObjects7= [];
gdjs.GameSceneCode.GDobj_95btn_95pauseObjects1= [];
gdjs.GameSceneCode.GDobj_95btn_95pauseObjects2= [];
gdjs.GameSceneCode.GDobj_95btn_95pauseObjects3= [];
gdjs.GameSceneCode.GDobj_95btn_95pauseObjects4= [];
gdjs.GameSceneCode.GDobj_95btn_95pauseObjects5= [];
gdjs.GameSceneCode.GDobj_95btn_95pauseObjects6= [];
gdjs.GameSceneCode.GDobj_95btn_95pauseObjects7= [];
gdjs.GameSceneCode.GDobj_95btn_95levelObjects1= [];
gdjs.GameSceneCode.GDobj_95btn_95levelObjects2= [];
gdjs.GameSceneCode.GDobj_95btn_95levelObjects3= [];
gdjs.GameSceneCode.GDobj_95btn_95levelObjects4= [];
gdjs.GameSceneCode.GDobj_95btn_95levelObjects5= [];
gdjs.GameSceneCode.GDobj_95btn_95levelObjects6= [];
gdjs.GameSceneCode.GDobj_95btn_95levelObjects7= [];
gdjs.GameSceneCode.GDobj_95btn_95ffObjects1= [];
gdjs.GameSceneCode.GDobj_95btn_95ffObjects2= [];
gdjs.GameSceneCode.GDobj_95btn_95ffObjects3= [];
gdjs.GameSceneCode.GDobj_95btn_95ffObjects4= [];
gdjs.GameSceneCode.GDobj_95btn_95ffObjects5= [];
gdjs.GameSceneCode.GDobj_95btn_95ffObjects6= [];
gdjs.GameSceneCode.GDobj_95btn_95ffObjects7= [];
gdjs.GameSceneCode.GDtxt_95tutorialObjects1= [];
gdjs.GameSceneCode.GDtxt_95tutorialObjects2= [];
gdjs.GameSceneCode.GDtxt_95tutorialObjects3= [];
gdjs.GameSceneCode.GDtxt_95tutorialObjects4= [];
gdjs.GameSceneCode.GDtxt_95tutorialObjects5= [];
gdjs.GameSceneCode.GDtxt_95tutorialObjects6= [];
gdjs.GameSceneCode.GDtxt_95tutorialObjects7= [];
gdjs.GameSceneCode.GDtiledbackgroundObjects1= [];
gdjs.GameSceneCode.GDtiledbackgroundObjects2= [];
gdjs.GameSceneCode.GDtiledbackgroundObjects3= [];
gdjs.GameSceneCode.GDtiledbackgroundObjects4= [];
gdjs.GameSceneCode.GDtiledbackgroundObjects5= [];
gdjs.GameSceneCode.GDtiledbackgroundObjects6= [];
gdjs.GameSceneCode.GDtiledbackgroundObjects7= [];
gdjs.GameSceneCode.GDbase_95hpObjects1= [];
gdjs.GameSceneCode.GDbase_95hpObjects2= [];
gdjs.GameSceneCode.GDbase_95hpObjects3= [];
gdjs.GameSceneCode.GDbase_95hpObjects4= [];
gdjs.GameSceneCode.GDbase_95hpObjects5= [];
gdjs.GameSceneCode.GDbase_95hpObjects6= [];
gdjs.GameSceneCode.GDbase_95hpObjects7= [];

gdjs.GameSceneCode.conditionTrue_0 = {val:false};
gdjs.GameSceneCode.condition0IsTrue_0 = {val:false};
gdjs.GameSceneCode.condition1IsTrue_0 = {val:false};
gdjs.GameSceneCode.condition2IsTrue_0 = {val:false};
gdjs.GameSceneCode.condition3IsTrue_0 = {val:false};
gdjs.GameSceneCode.condition4IsTrue_0 = {val:false};
gdjs.GameSceneCode.condition5IsTrue_0 = {val:false};
gdjs.GameSceneCode.condition6IsTrue_0 = {val:false};
gdjs.GameSceneCode.conditionTrue_1 = {val:false};
gdjs.GameSceneCode.condition0IsTrue_1 = {val:false};
gdjs.GameSceneCode.condition1IsTrue_1 = {val:false};
gdjs.GameSceneCode.condition2IsTrue_1 = {val:false};
gdjs.GameSceneCode.condition3IsTrue_1 = {val:false};
gdjs.GameSceneCode.condition4IsTrue_1 = {val:false};
gdjs.GameSceneCode.condition5IsTrue_1 = {val:false};
gdjs.GameSceneCode.condition6IsTrue_1 = {val:false};
gdjs.GameSceneCode.conditionTrue_2 = {val:false};
gdjs.GameSceneCode.condition0IsTrue_2 = {val:false};
gdjs.GameSceneCode.condition1IsTrue_2 = {val:false};
gdjs.GameSceneCode.condition2IsTrue_2 = {val:false};
gdjs.GameSceneCode.condition3IsTrue_2 = {val:false};
gdjs.GameSceneCode.condition4IsTrue_2 = {val:false};
gdjs.GameSceneCode.condition5IsTrue_2 = {val:false};
gdjs.GameSceneCode.condition6IsTrue_2 = {val:false};


gdjs.GameSceneCode.eventsList0 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "first_play"));
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition1IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 0;
}}
if (gdjs.GameSceneCode.condition1IsTrue_0.val) {
{gdjs.evtTools.storage.writeNumberInJSONFile("game_data", "first_play", 1);
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(1);
}}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "first_play");
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.readNumberFromJSONFile("game_data", "first_play", runtimeScene, runtimeScene.getVariables().get("mm_first_play"));
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("mm_first_play")));
}}

}


};gdjs.GameSceneCode.eventsList1 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "max_level_reached"));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.writeNumberInJSONFile("game_data", "max_level_reached", 1);
}{runtimeScene.getVariables().get("max_level_reached").setNumber(1);
}}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "max_level_reached");
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.readNumberFromJSONFile("game_data", "max_level_reached", runtimeScene, runtimeScene.getVariables().get("max_level_reached"));
}}

}


};gdjs.GameSceneCode.eventsList2 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "game_level"));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.writeNumberInJSONFile("game_data", "game_level", 1);
}{runtimeScene.getVariables().get("game_level").setNumber(1);
}}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "game_level");
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.readNumberFromJSONFile("game_data", "game_level", runtimeScene, runtimeScene.getVariables().get("game_level"));
}}

}


};gdjs.GameSceneCode.eventsList3 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "tutorial_number"));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.writeNumberInJSONFile("game_data", "tutorial_number", 1);
}{runtimeScene.getVariables().getFromIndex(11).setNumber(1);
}}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "tutorial_number");
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.readNumberFromJSONFile("game_data", "tutorial_number", runtimeScene, runtimeScene.getVariables().getFromIndex(11));
}}

}


};gdjs.GameSceneCode.eventsList4 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "coins"));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.writeNumberInJSONFile("game_data", "coins", 1200);
}{runtimeScene.getVariables().getFromIndex(0).setNumber(1200);
}}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("game_data", "coins");
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.readNumberFromJSONFile("game_data", "coins", runtimeScene, runtimeScene.getVariables().getFromIndex(0));
}}

}


};gdjs.GameSceneCode.eventsList5 = function(runtimeScene) {

{


gdjs.GameSceneCode.eventsList0(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList1(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList2(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList3(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList4(runtimeScene);
}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDcursorObjects1Objects = Hashtable.newFrom({"cursor": gdjs.GameSceneCode.GDcursorObjects1});gdjs.GameSceneCode.eventsList6 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 1));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\music\\02-level-1.wav", 1, true, 30, 1);
}}

}


};gdjs.GameSceneCode.eventsList7 = function(runtimeScene) {

{


{
{gdjs.evtTools.common.setVariableBoolean(runtimeScene.getVariables().get("tutorial"), false);
}{gdjs.evtTools.common.setVariableBoolean(runtimeScene.getVariables().getFromIndex(9), false);
}{runtimeScene.getVariables().getFromIndex(4).setNumber(1);
}{runtimeScene.getVariables().getFromIndex(1).setNumber(0);
}{runtimeScene.getVariables().getFromIndex(2).setNumber(1);
}{runtimeScene.getVariables().getFromIndex(6).setNumber(0);
}{runtimeScene.getVariables().get("total_for_next_wave").setNumber(0);
}{runtimeScene.getVariables().getFromIndex(8).setNumber(1);
}{runtimeScene.getVariables().get("end_stage_counter").setNumber(1);
}{runtimeScene.getVariables().getFromIndex(5).setNumber(1);
}{runtimeScene.getVariables().get("scroll_speed").setNumber(0.8);
}}

}


};gdjs.GameSceneCode.eventsList8 = function(runtimeScene) {

{


{
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "PAUSE", 0, 0);
}{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "HUD", 0, 0);
}{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "WINLOSE", 0, 0);
}{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "TUTORIAL", 0, 0);
}}

}


};gdjs.GameSceneCode.eventsList9 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("game_level")) == 1;
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "level_1", 0, 0);
}{runtimeScene.getVariables().getFromIndex(2).setNumber(1);
}{runtimeScene.getVariables().getFromIndex(3).setNumber(10);
}}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("game_level")) == 2;
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "level_2", 0, 0);
}{runtimeScene.getVariables().getFromIndex(2).setNumber(2);
}{runtimeScene.getVariables().getFromIndex(3).setNumber(5);
}}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("game_level")) == 3;
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "level_3", 0, 0);
}{runtimeScene.getVariables().getFromIndex(2).setNumber(3);
}{runtimeScene.getVariables().getFromIndex(3).setNumber(5);
}}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("game_level")) == 4;
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "level_4", 0, 0);
}{runtimeScene.getVariables().getFromIndex(2).setNumber(3);
}{runtimeScene.getVariables().getFromIndex(3).setNumber(5);
}}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("game_level")) == 5;
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "level_5", 0, 0);
}{runtimeScene.getVariables().getFromIndex(2).setNumber(4);
}{runtimeScene.getVariables().getFromIndex(3).setNumber(5);
}}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("game_level")) == 6;
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "level_6", 0, 0);
}{runtimeScene.getVariables().getFromIndex(2).setNumber(5);
}{runtimeScene.getVariables().getFromIndex(3).setNumber(5);
}}

}


};gdjs.GameSceneCode.eventsList10 = function(runtimeScene) {

};gdjs.GameSceneCode.eventsList11 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("tower"), gdjs.GameSceneCode.GDtowerObjects2);

for(gdjs.GameSceneCode.forEachIndex3 = 0;gdjs.GameSceneCode.forEachIndex3 < gdjs.GameSceneCode.GDtowerObjects2.length;++gdjs.GameSceneCode.forEachIndex3) {
gdjs.GameSceneCode.GDtowerObjects3.length = 0;


gdjs.GameSceneCode.forEachTemporary3 = gdjs.GameSceneCode.GDtowerObjects2[gdjs.GameSceneCode.forEachIndex3];
gdjs.GameSceneCode.GDtowerObjects3.push(gdjs.GameSceneCode.forEachTemporary3);
if (true) {
{for(var i = 0, len = gdjs.GameSceneCode.GDtowerObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtowerObjects3[i].returnVariable(gdjs.GameSceneCode.GDtowerObjects3[i].getVariables().getFromIndex(3)).add(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(5)));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtowerObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtowerObjects3[i].returnVariable(gdjs.GameSceneCode.GDtowerObjects3[i].getVariables().getFromIndex(1)).setNumber(1);
}
}{runtimeScene.getVariables().getFromIndex(5).add(1);
}}
}

}


};gdjs.GameSceneCode.eventsList12 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("end_path"), gdjs.GameSceneCode.GDend_95pathObjects2);
gdjs.copyArray(runtimeScene.getObjects("obj_btn_continue"), gdjs.GameSceneCode.GDobj_95btn_95continueObjects2);
gdjs.copyArray(runtimeScene.getObjects("start_path"), gdjs.GameSceneCode.GDstart_95pathObjects2);
gdjs.copyArray(runtimeScene.getObjects("tower_btn_bullets"), gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects2);
gdjs.copyArray(runtimeScene.getObjects("tower_btn_sell"), gdjs.GameSceneCode.GDtower_95btn_95sellObjects2);
gdjs.copyArray(runtimeScene.getObjects("tower_btn_upgrade"), gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects2);
gdjs.copyArray(runtimeScene.getObjects("tower_panel"), gdjs.GameSceneCode.GDtower_95panelObjects2);
gdjs.copyArray(runtimeScene.getObjects("txt_paused"), gdjs.GameSceneCode.GDtxt_95pausedObjects2);
{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95panelObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95panelObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95sellObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95sellObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDstart_95pathObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDstart_95pathObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDend_95pathObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDend_95pathObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95pausedObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95pausedObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDobj_95btn_95continueObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDobj_95btn_95continueObjects2[i].hide();
}
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "OBSTACLES");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "WINLOSE");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "PAUSE");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "TUTORIAL");
}}

}


};gdjs.GameSceneCode.eventsList13 = function(runtimeScene) {

};gdjs.GameSceneCode.eventsList14 = function(runtimeScene) {

{


gdjs.GameSceneCode.repeatCount2 = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(2));
for(gdjs.GameSceneCode.repeatIndex2 = 0;gdjs.GameSceneCode.repeatIndex2 < gdjs.GameSceneCode.repeatCount2;++gdjs.GameSceneCode.repeatIndex2) {

if (true)
{
{runtimeScene.getVariables().getFromIndex(7).getChild("Wave:" + gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(8)))).getChild("enemies_killed").setNumber(0);
}{runtimeScene.getVariables().getFromIndex(7).getChild("Wave:" + gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(8)))).getChild("enemies_escaped").setNumber(0);
}{runtimeScene.getVariables().getFromIndex(8).add(1);
}}
}

}


};gdjs.GameSceneCode.eventsList15 = function(runtimeScene) {

{


gdjs.GameSceneCode.eventsList6(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList7(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList8(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList9(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList11(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList12(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList14(runtimeScene);
}


};gdjs.GameSceneCode.eventsList16 = function(runtimeScene) {

{



}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList5(runtimeScene);} //End of subevents
}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
gdjs.GameSceneCode.GDcursorObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDcursorObjects1Objects, 0, 0, "HUD");
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 1, "", 0);
}{for(var i = 0, len = gdjs.GameSceneCode.GDcursorObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDcursorObjects1[i].setLayer("HUD");
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "endpanel");
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "endpanel");
}{gdjs.evtTools.input.hideCursor(runtimeScene);
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "BlurMe", false);
}{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 1);
}
{ //Subevents
gdjs.GameSceneCode.eventsList15(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList17 = function(runtimeScene) {

};gdjs.GameSceneCode.eventsList18 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("tiledbackground"), gdjs.GameSceneCode.GDtiledbackgroundObjects2);

for(gdjs.GameSceneCode.forEachIndex3 = 0;gdjs.GameSceneCode.forEachIndex3 < gdjs.GameSceneCode.GDtiledbackgroundObjects2.length;++gdjs.GameSceneCode.forEachIndex3) {
gdjs.GameSceneCode.GDtiledbackgroundObjects3.length = 0;


gdjs.GameSceneCode.forEachTemporary3 = gdjs.GameSceneCode.GDtiledbackgroundObjects2[gdjs.GameSceneCode.forEachIndex3];
gdjs.GameSceneCode.GDtiledbackgroundObjects3.push(gdjs.GameSceneCode.forEachTemporary3);
gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtiledbackgroundObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtiledbackgroundObjects3[i].getX() >= 0 ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtiledbackgroundObjects3[k] = gdjs.GameSceneCode.GDtiledbackgroundObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtiledbackgroundObjects3.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.GameSceneCode.GDtiledbackgroundObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtiledbackgroundObjects3[i].setX(-((gdjs.GameSceneCode.GDtiledbackgroundObjects3[i].getWidth())) / 2);
}
}}
}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("tiledbackground"), gdjs.GameSceneCode.GDtiledbackgroundObjects1);
{for(var i = 0, len = gdjs.GameSceneCode.GDtiledbackgroundObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtiledbackgroundObjects1[i].setX(gdjs.GameSceneCode.GDtiledbackgroundObjects1[i].getX() + (gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("scroll_speed"))));
}
}}

}


};gdjs.GameSceneCode.eventsList19 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("txt_coins"), gdjs.GameSceneCode.GDtxt_95coinsObjects2);
gdjs.copyArray(runtimeScene.getObjects("txt_enemies_escaped"), gdjs.GameSceneCode.GDtxt_95enemies_95escapedObjects2);
gdjs.copyArray(runtimeScene.getObjects("txt_kills_this_wave"), gdjs.GameSceneCode.GDtxt_95kills_95this_95waveObjects2);
gdjs.copyArray(runtimeScene.getObjects("txt_paused"), gdjs.GameSceneCode.GDtxt_95pausedObjects2);
gdjs.copyArray(runtimeScene.getObjects("txt_rankings"), gdjs.GameSceneCode.GDtxt_95rankingsObjects2);
gdjs.copyArray(runtimeScene.getObjects("txt_wave"), gdjs.GameSceneCode.GDtxt_95waveObjects2);
{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95kills_95this_95waveObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95kills_95this_95waveObjects2[i].setCharacterSize(40);
}
for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95enemies_95escapedObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95enemies_95escapedObjects2[i].setCharacterSize(40);
}
for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95waveObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95waveObjects2[i].setCharacterSize(40);
}
for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95coinsObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95coinsObjects2[i].setCharacterSize(40);
}
for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95rankingsObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95rankingsObjects2[i].setCharacterSize(40);
}
for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95pausedObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95pausedObjects2[i].setCharacterSize(40);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95kills_95this_95waveObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95kills_95this_95waveObjects2[i].setWrappingWidth(512);
}
for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95enemies_95escapedObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95enemies_95escapedObjects2[i].setWrappingWidth(512);
}
for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95waveObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95waveObjects2[i].setWrappingWidth(512);
}
for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95coinsObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95coinsObjects2[i].setWrappingWidth(512);
}
for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95rankingsObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95rankingsObjects2[i].setWrappingWidth(512);
}
for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95pausedObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95pausedObjects2[i].setWrappingWidth(512);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95kills_95this_95waveObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95kills_95this_95waveObjects2[i].setWrapping(false);
}
for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95enemies_95escapedObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95enemies_95escapedObjects2[i].setWrapping(false);
}
for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95waveObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95waveObjects2[i].setWrapping(false);
}
for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95coinsObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95coinsObjects2[i].setWrapping(false);
}
for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95rankingsObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95rankingsObjects2[i].setWrapping(false);
}
for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95pausedObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95pausedObjects2[i].setWrapping(false);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95kills_95this_95waveObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95kills_95this_95waveObjects2[i].setScale(0.2);
}
for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95enemies_95escapedObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95enemies_95escapedObjects2[i].setScale(0.2);
}
for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95waveObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95waveObjects2[i].setScale(0.2);
}
for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95coinsObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95coinsObjects2[i].setScale(0.2);
}
for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95rankingsObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95rankingsObjects2[i].setScale(0.2);
}
for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95pausedObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95pausedObjects2[i].setScale(0.2);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95kills_95this_95waveObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95kills_95this_95waveObjects2[i].setOutline("0;0;0", 10);
}
for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95enemies_95escapedObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95enemies_95escapedObjects2[i].setOutline("0;0;0", 10);
}
for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95waveObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95waveObjects2[i].setOutline("0;0;0", 10);
}
for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95coinsObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95coinsObjects2[i].setOutline("0;0;0", 10);
}
for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95rankingsObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95rankingsObjects2[i].setOutline("0;0;0", 10);
}
for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95pausedObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95pausedObjects2[i].setOutline("0;0;0", 10);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95kills_95this_95waveObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95kills_95this_95waveObjects2[i].setGradient("LINEAR_VERTICAL", "255;251;191", "212;205;109", "177;167;44", "136;126;12");
}
for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95enemies_95escapedObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95enemies_95escapedObjects2[i].setGradient("LINEAR_VERTICAL", "255;251;191", "212;205;109", "177;167;44", "136;126;12");
}
for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95waveObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95waveObjects2[i].setGradient("LINEAR_VERTICAL", "255;251;191", "212;205;109", "177;167;44", "136;126;12");
}
for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95coinsObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95coinsObjects2[i].setGradient("LINEAR_VERTICAL", "255;251;191", "212;205;109", "177;167;44", "136;126;12");
}
for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95rankingsObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95rankingsObjects2[i].setGradient("LINEAR_VERTICAL", "255;251;191", "212;205;109", "177;167;44", "136;126;12");
}
for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95pausedObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95pausedObjects2[i].setGradient("LINEAR_VERTICAL", "255;251;191", "212;205;109", "177;167;44", "136;126;12");
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("txt_tutorial"), gdjs.GameSceneCode.GDtxt_95tutorialObjects2);
{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95tutorialObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95tutorialObjects2[i].setCharacterSize(60);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95tutorialObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95tutorialObjects2[i].setScale(0.2);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95tutorialObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95tutorialObjects2[i].setWrapping(true);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95tutorialObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95tutorialObjects2[i].setWrappingWidth(1820);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95tutorialObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95tutorialObjects2[i].setGradient("LINEAR_VERTICAL", "255;251;191", "212;205;109", "177;167;44", "136;126;12");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95tutorialObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95tutorialObjects2[i].setOutline("0;0;0", 6);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("txt_paused"), gdjs.GameSceneCode.GDtxt_95pausedObjects1);
{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95pausedObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95pausedObjects1[i].setCharacterSize(80);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95pausedObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95pausedObjects1[i].setPosition(gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2 - (gdjs.GameSceneCode.GDtxt_95pausedObjects1[i].getWidth()) / 2,gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) / 2 - (gdjs.GameSceneCode.GDtxt_95pausedObjects1[i].getHeight()) / 2);
}
}}

}


};gdjs.GameSceneCode.eventsList20 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 11));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\welcome-male-6.wav", 11, false, 100, 1);
}}

}


};gdjs.GameSceneCode.eventsList21 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 11));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\tutorial-archers.wav", 11, false, 100, 1);
}}

}


};gdjs.GameSceneCode.eventsList22 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 11));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\tutorial-wizards.wav", 11, false, 100, 1);
}}

}


};gdjs.GameSceneCode.eventsList23 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 11));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\tutorial-melee.wav", 11, false, 100, 1);
}}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDobj_9595btn_9595continueObjects1Objects = Hashtable.newFrom({"obj_btn_continue": gdjs.GameSceneCode.GDobj_95btn_95continueObjects1});gdjs.GameSceneCode.eventsList24 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
gdjs.GameSceneCode.condition2IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("game_level")) == 1;
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition1IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(11)) == 1;
}if ( gdjs.GameSceneCode.condition1IsTrue_0.val ) {
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition2IsTrue_0;
gdjs.GameSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11707164);
}
}}
}
if (gdjs.GameSceneCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("txt_tutorial"), gdjs.GameSceneCode.GDtxt_95tutorialObjects2);
gdjs.copyArray(runtimeScene.getObjects("victory"), gdjs.GameSceneCode.GDvictoryObjects2);
{for(var i = 0, len = gdjs.GameSceneCode.GDvictoryObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDvictoryObjects2[i].setAnimationName("welcome");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95tutorialObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95tutorialObjects2[i].setString("Welcome to the tower defense template, use your mouse to drag and drop towers on the tower locations.\nRight-click on a tower to open its upgrade panel, then select an action to take.\nYou can upgrade the tower, upgrade the bullets and their units, or sell the tower.");
}
}
{ //Subevents
gdjs.GameSceneCode.eventsList20(runtimeScene);} //End of subevents
}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
gdjs.GameSceneCode.condition2IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("game_level")) == 1;
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition1IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(11)) == 2;
}if ( gdjs.GameSceneCode.condition1IsTrue_0.val ) {
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition2IsTrue_0;
gdjs.GameSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11709708);
}
}}
}
if (gdjs.GameSceneCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("txt_tutorial"), gdjs.GameSceneCode.GDtxt_95tutorialObjects2);
gdjs.copyArray(runtimeScene.getObjects("victory"), gdjs.GameSceneCode.GDvictoryObjects2);
{for(var i = 0, len = gdjs.GameSceneCode.GDvictoryObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDvictoryObjects2[i].setAnimationName("tutorial");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95tutorialObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95tutorialObjects2[i].setString("In this area you are going to use archer towers, try to place some towers on the field, so that the archers can stop the incoming enemies.");
}
}
{ //Subevents
gdjs.GameSceneCode.eventsList21(runtimeScene);} //End of subevents
}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
gdjs.GameSceneCode.condition2IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("game_level")) == 2;
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition1IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(11)) == 3;
}if ( gdjs.GameSceneCode.condition1IsTrue_0.val ) {
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition2IsTrue_0;
gdjs.GameSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11711964);
}
}}
}
if (gdjs.GameSceneCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("txt_tutorial"), gdjs.GameSceneCode.GDtxt_95tutorialObjects2);
gdjs.copyArray(runtimeScene.getObjects("victory"), gdjs.GameSceneCode.GDvictoryObjects2);
{for(var i = 0, len = gdjs.GameSceneCode.GDvictoryObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDvictoryObjects2[i].setAnimationName("tutorial");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95tutorialObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95tutorialObjects2[i].setString("Now it's up to the wizards, add a few wizard towers to stop the enemy orde. Also use some archer towers and between them they will be unstoppable.");
}
}
{ //Subevents
gdjs.GameSceneCode.eventsList22(runtimeScene);} //End of subevents
}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
gdjs.GameSceneCode.condition2IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("game_level")) == 3;
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition1IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(11)) == 4;
}if ( gdjs.GameSceneCode.condition1IsTrue_0.val ) {
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition2IsTrue_0;
gdjs.GameSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11713756);
}
}}
}
if (gdjs.GameSceneCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("txt_tutorial"), gdjs.GameSceneCode.GDtxt_95tutorialObjects2);
gdjs.copyArray(runtimeScene.getObjects("victory"), gdjs.GameSceneCode.GDvictoryObjects2);
{for(var i = 0, len = gdjs.GameSceneCode.GDvictoryObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDvictoryObjects2[i].setAnimationName("tutorial");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95tutorialObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95tutorialObjects2[i].setString("You're doing very well, now it's the turn of the melee towers, these towers create a melee-type unit that can slow down enemies, ideal for combining with archers and wizards.");
}
}
{ //Subevents
gdjs.GameSceneCode.eventsList23(runtimeScene);} //End of subevents
}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.sound.isSoundOnChannelStopped(runtimeScene, 11);
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("obj_btn_continue"), gdjs.GameSceneCode.GDobj_95btn_95continueObjects2);
{for(var i = 0, len = gdjs.GameSceneCode.GDobj_95btn_95continueObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDobj_95btn_95continueObjects2[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("obj_btn_continue"), gdjs.GameSceneCode.GDobj_95btn_95continueObjects1);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
gdjs.GameSceneCode.condition2IsTrue_0.val = false;
gdjs.GameSceneCode.condition3IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDobj_9595btn_9595continueObjects1Objects, runtimeScene, true, false);
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameSceneCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDobj_95btn_95continueObjects1.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDobj_95btn_95continueObjects1[i].isVisible() ) {
        gdjs.GameSceneCode.condition2IsTrue_0.val = true;
        gdjs.GameSceneCode.GDobj_95btn_95continueObjects1[k] = gdjs.GameSceneCode.GDobj_95btn_95continueObjects1[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDobj_95btn_95continueObjects1.length = k;}if ( gdjs.GameSceneCode.condition2IsTrue_0.val ) {
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition3IsTrue_0;
gdjs.GameSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11717324);
}
}}
}
}
if (gdjs.GameSceneCode.condition3IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDcursorObjects1 */
/* Reuse gdjs.GameSceneCode.GDobj_95btn_95continueObjects1 */
{for(var i = 0, len = gdjs.GameSceneCode.GDcursorObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDcursorObjects1[i].setLayer("HUD");
}
}{gdjs.evtTools.camera.showLayer(runtimeScene, "HUD");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "TUTORIAL");
}{for(var i = 0, len = gdjs.GameSceneCode.GDobj_95btn_95continueObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDobj_95btn_95continueObjects1[i].hide();
}
}{gdjs.evtTools.common.setVariableBoolean(runtimeScene.getVariables().get("tutorial"), false);
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(3);
}{gdjs.evtTools.storage.writeNumberInJSONFile("game_data", "first_play", 3);
}{runtimeScene.getVariables().getFromIndex(11).add(1);
}{gdjs.evtTools.storage.writeNumberInJSONFile("game_data", "tutorial_number", gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(11)));
}{gdjs.evtTools.camera.setLayerTimeScale(runtimeScene, "", 0);
}}

}


};gdjs.GameSceneCode.eventsList25 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 1;
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.common.setVariableBoolean(runtimeScene.getVariables().get("tutorial"), true);
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(2);
}{gdjs.evtTools.storage.writeNumberInJSONFile("game_data", "first_play", 2);
}}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
gdjs.GameSceneCode.condition2IsTrue_0.val = false;
gdjs.GameSceneCode.condition3IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableBoolean(runtimeScene.getVariables().get("tutorial"), false);
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition1IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("game_level")) == 1;
}if ( gdjs.GameSceneCode.condition1IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition2IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(11)) == 2;
}if ( gdjs.GameSceneCode.condition2IsTrue_0.val ) {
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition3IsTrue_0;
gdjs.GameSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11702164);
}
}}
}
}
if (gdjs.GameSceneCode.condition3IsTrue_0.val) {
{gdjs.evtTools.common.setVariableBoolean(runtimeScene.getVariables().get("tutorial"), true);
}}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
gdjs.GameSceneCode.condition2IsTrue_0.val = false;
gdjs.GameSceneCode.condition3IsTrue_0.val = false;
gdjs.GameSceneCode.condition4IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableBoolean(runtimeScene.getVariables().getFromIndex(9), false);
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition1IsTrue_0.val = gdjs.evtTools.common.getVariableBoolean(runtimeScene.getVariables().get("tutorial"), false);
}if ( gdjs.GameSceneCode.condition1IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition2IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("game_level")) == 2;
}if ( gdjs.GameSceneCode.condition2IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition3IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(11)) == 3;
}if ( gdjs.GameSceneCode.condition3IsTrue_0.val ) {
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition4IsTrue_0;
gdjs.GameSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11703220);
}
}}
}
}
}
if (gdjs.GameSceneCode.condition4IsTrue_0.val) {
{gdjs.evtTools.common.setVariableBoolean(runtimeScene.getVariables().get("tutorial"), true);
}}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
gdjs.GameSceneCode.condition2IsTrue_0.val = false;
gdjs.GameSceneCode.condition3IsTrue_0.val = false;
gdjs.GameSceneCode.condition4IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableBoolean(runtimeScene.getVariables().getFromIndex(9), false);
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition1IsTrue_0.val = gdjs.evtTools.common.getVariableBoolean(runtimeScene.getVariables().get("tutorial"), false);
}if ( gdjs.GameSceneCode.condition1IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition2IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("game_level")) == 3;
}if ( gdjs.GameSceneCode.condition2IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition3IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(11)) == 4;
}if ( gdjs.GameSceneCode.condition3IsTrue_0.val ) {
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition4IsTrue_0;
gdjs.GameSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11704684);
}
}}
}
}
}
if (gdjs.GameSceneCode.condition4IsTrue_0.val) {
{gdjs.evtTools.common.setVariableBoolean(runtimeScene.getVariables().get("tutorial"), true);
}}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableBoolean(runtimeScene.getVariables().get("tutorial"), true);
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("cursor"), gdjs.GameSceneCode.GDcursorObjects1);
{gdjs.evtTools.camera.setLayerTimeScale(runtimeScene, "", 0);
}{gdjs.evtTools.camera.showLayer(runtimeScene, "TUTORIAL");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "HUD");
}{for(var i = 0, len = gdjs.GameSceneCode.GDcursorObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDcursorObjects1[i].setLayer("TUTORIAL");
}
}
{ //Subevents
gdjs.GameSceneCode.eventsList24(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList26 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("txt_coins"), gdjs.GameSceneCode.GDtxt_95coinsObjects2);
gdjs.copyArray(runtimeScene.getObjects("txt_enemies_escaped"), gdjs.GameSceneCode.GDtxt_95enemies_95escapedObjects2);
gdjs.copyArray(runtimeScene.getObjects("txt_kills_this_wave"), gdjs.GameSceneCode.GDtxt_95kills_95this_95waveObjects2);
gdjs.copyArray(runtimeScene.getObjects("txt_wave"), gdjs.GameSceneCode.GDtxt_95waveObjects2);
{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95kills_95this_95waveObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95kills_95this_95waveObjects2[i].setString("Killed:" + gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(1)));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95coinsObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95coinsObjects2[i].setString("Coins:" + gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95waveObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95waveObjects2[i].setString("Wave:" + gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(4)) + " of " + gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95enemies_95escapedObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95enemies_95escapedObjects2[i].setString("Escaped:" + gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(6)));
}
}}

}


};gdjs.GameSceneCode.eventsList27 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("cursor"), gdjs.GameSceneCode.GDcursorObjects2);
gdjs.copyArray(runtimeScene.getObjects("hud_box"), gdjs.GameSceneCode.GDhud_95boxObjects2);
gdjs.copyArray(runtimeScene.getObjects("obj_btn_next"), gdjs.GameSceneCode.GDobj_95btn_95nextObjects2);
gdjs.copyArray(runtimeScene.getObjects("victory"), gdjs.GameSceneCode.GDvictoryObjects2);
{for(var i = 0, len = gdjs.GameSceneCode.GDcursorObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDcursorObjects2[i].setPosition(gdjs.evtTools.input.getMouseX(runtimeScene, "", 0),gdjs.evtTools.input.getMouseY(runtimeScene, "", 0));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDhud_95boxObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDhud_95boxObjects2[i].setPosition(gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2 - (gdjs.GameSceneCode.GDhud_95boxObjects2[i].getWidth()) / 2,(gdjs.GameSceneCode.GDhud_95boxObjects2[i].getPointY("")));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDvictoryObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDvictoryObjects2[i].setPosition(gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2 - (gdjs.GameSceneCode.GDvictoryObjects2[i].getWidth()) / 2,(gdjs.GameSceneCode.GDvictoryObjects2[i].getPointY("")));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDobj_95btn_95nextObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDobj_95btn_95nextObjects2[i].setPosition(gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2 - (gdjs.GameSceneCode.GDobj_95btn_95nextObjects2[i].getWidth()) / 2,(gdjs.GameSceneCode.GDobj_95btn_95nextObjects2[i].getPointY("")));
}
}}

}


};gdjs.GameSceneCode.eventsList28 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("cursor"), gdjs.GameSceneCode.GDcursorObjects2);
gdjs.copyArray(runtimeScene.getObjects("tower_btn"), gdjs.GameSceneCode.GDtower_95btnObjects2);
gdjs.copyArray(runtimeScene.getObjects("tower_btn_bullets"), gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects2);
gdjs.copyArray(runtimeScene.getObjects("tower_btn_sell"), gdjs.GameSceneCode.GDtower_95btn_95sellObjects2);
gdjs.copyArray(runtimeScene.getObjects("tower_btn_upgrade"), gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects2);
gdjs.copyArray(runtimeScene.getObjects("tower_panel"), gdjs.GameSceneCode.GDtower_95panelObjects2);
{for(var i = 0, len = gdjs.GameSceneCode.GDcursorObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDcursorObjects2[i].setZOrder(1000);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btnObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btnObjects2[i].setZOrder(10);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95panelObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95panelObjects2[i].setZOrder(10);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects2[i].setZOrder(11);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95sellObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95sellObjects2[i].setZOrder(11);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects2[i].setZOrder(11);
}
}}

}


};gdjs.GameSceneCode.eventsList29 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("tower_panel"), gdjs.GameSceneCode.GDtower_95panelObjects2);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtower_95panelObjects2.length;i<l;++i) {
    if ( !(gdjs.GameSceneCode.GDtower_95panelObjects2[i].isVisible()) ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtower_95panelObjects2[k] = gdjs.GameSceneCode.GDtower_95panelObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtower_95panelObjects2.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("tower_btn_bullets"), gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects2);
gdjs.copyArray(runtimeScene.getObjects("tower_btn_sell"), gdjs.GameSceneCode.GDtower_95btn_95sellObjects2);
gdjs.copyArray(runtimeScene.getObjects("tower_btn_upgrade"), gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects2);
/* Reuse gdjs.GameSceneCode.GDtower_95panelObjects2 */
gdjs.copyArray(runtimeScene.getObjects("tower_selected"), gdjs.GameSceneCode.GDtower_95selectedObjects2);
{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95panelObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95panelObjects2[i].setPosition(gdjs.evtTools.input.getMouseX(runtimeScene, "", 0),gdjs.evtTools.input.getMouseY(runtimeScene, "", 0));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95selectedObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95selectedObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95sellObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95sellObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects2[i].hide();
}
}}

}


};gdjs.GameSceneCode.eventsList30 = function(runtimeScene) {

{


{
{runtimeScene.getVariables().getFromIndex(7).getChild("Wave:" + gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(4)))).getChild("enemies_killed").setNumber(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)));
}{runtimeScene.getVariables().getFromIndex(7).getChild("Wave:" + gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(4)))).getChild("enemies_escaped").setNumber(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(6)));
}}

}


};gdjs.GameSceneCode.eventsList31 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition0IsTrue_0;
gdjs.GameSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11729588);
}
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(1).setNumber(0);
}{runtimeScene.getVariables().getFromIndex(6).setNumber(0);
}{runtimeScene.getVariables().getFromIndex(4).add(1);
}}

}


};gdjs.GameSceneCode.eventsList32 = function(runtimeScene) {

{


{
{runtimeScene.getVariables().get("total_for_next_wave").setNumber(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) + gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(6)));
}}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("total_for_next_wave")) == gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(3));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList31(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList33 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
gdjs.GameSceneCode.condition2IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) == 0;
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition1IsTrue_0.val = gdjs.evtTools.common.getVariableBoolean(runtimeScene.getVariables().getFromIndex(9), false);
}if ( gdjs.GameSceneCode.condition1IsTrue_0.val ) {
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition2IsTrue_0;
gdjs.GameSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11731332);
}
}}
}
if (gdjs.GameSceneCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("cursor"), gdjs.GameSceneCode.GDcursorObjects2);
gdjs.copyArray(runtimeScene.getObjects("hud_box"), gdjs.GameSceneCode.GDhud_95boxObjects2);
gdjs.copyArray(runtimeScene.getObjects("obj_btn_next"), gdjs.GameSceneCode.GDobj_95btn_95nextObjects2);
gdjs.copyArray(runtimeScene.getObjects("victory"), gdjs.GameSceneCode.GDvictoryObjects2);
{gdjs.evtTools.common.setVariableBoolean(runtimeScene.getVariables().getFromIndex(9), true);
}{gdjs.evtTools.runtimeScene.unpauseTimer(runtimeScene, "endpanel");
}{for(var i = 0, len = gdjs.GameSceneCode.GDcursorObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDcursorObjects2[i].setLayer("WINLOSE");
}
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "HUD");
}{gdjs.evtTools.camera.showLayer(runtimeScene, "WINLOSE");
}{for(var i = 0, len = gdjs.GameSceneCode.GDobj_95btn_95nextObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDobj_95btn_95nextObjects2[i].setAnimationName("restart");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDvictoryObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDvictoryObjects2[i].setAnimationName("lose");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDhud_95boxObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDhud_95boxObjects2[i].setScaleY(0.1);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDhud_95boxObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDhud_95boxObjects2[i].setScaleX(0.1);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDvictoryObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDvictoryObjects2[i].setScaleY(0.1);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDvictoryObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDvictoryObjects2[i].setScaleX(0.1);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDobj_95btn_95nextObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDobj_95btn_95nextObjects2[i].setScaleX(0.1);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDobj_95btn_95nextObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDobj_95btn_95nextObjects2[i].setScaleY(0.1);
}
}}

}


};gdjs.GameSceneCode.eventsList34 = function(runtimeScene) {

};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtxt_9595rankingsObjects4Objects = Hashtable.newFrom({"txt_rankings": gdjs.GameSceneCode.GDtxt_95rankingsObjects4});gdjs.GameSceneCode.eventsList35 = function(runtimeScene) {

};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDvictory_9595effectObjects4Objects = Hashtable.newFrom({"victory_effect": gdjs.GameSceneCode.GDvictory_95effectObjects4});gdjs.GameSceneCode.eventsList36 = function(runtimeScene) {

};gdjs.GameSceneCode.eventsList37 = function(runtimeScene) {

{



}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("game_level")) > gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("max_level_reached"));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("max_level_reached").setNumber(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("game_level")));
}{gdjs.evtTools.storage.writeNumberInJSONFile("game_data", "max_level_reached", gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("max_level_reached")));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("enemy_0"), gdjs.GameSceneCode.GDenemy_950Objects3);
gdjs.copyArray(runtimeScene.getObjects("enemy_1"), gdjs.GameSceneCode.GDenemy_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("enemy_2"), gdjs.GameSceneCode.GDenemy_952Objects3);

gdjs.GameSceneCode.forEachTotalCount4 = 0;
gdjs.GameSceneCode.forEachObjects4.length = 0;
gdjs.GameSceneCode.forEachCount0_4 = gdjs.GameSceneCode.GDenemy_950Objects3.length;
gdjs.GameSceneCode.forEachTotalCount4 += gdjs.GameSceneCode.forEachCount0_4;
gdjs.GameSceneCode.forEachObjects4.push.apply(gdjs.GameSceneCode.forEachObjects4,gdjs.GameSceneCode.GDenemy_950Objects3);
gdjs.GameSceneCode.forEachCount1_4 = gdjs.GameSceneCode.GDenemy_951Objects3.length;
gdjs.GameSceneCode.forEachTotalCount4 += gdjs.GameSceneCode.forEachCount1_4;
gdjs.GameSceneCode.forEachObjects4.push.apply(gdjs.GameSceneCode.forEachObjects4,gdjs.GameSceneCode.GDenemy_951Objects3);
gdjs.GameSceneCode.forEachCount2_4 = gdjs.GameSceneCode.GDenemy_952Objects3.length;
gdjs.GameSceneCode.forEachTotalCount4 += gdjs.GameSceneCode.forEachCount2_4;
gdjs.GameSceneCode.forEachObjects4.push.apply(gdjs.GameSceneCode.forEachObjects4,gdjs.GameSceneCode.GDenemy_952Objects3);
for(gdjs.GameSceneCode.forEachIndex4 = 0;gdjs.GameSceneCode.forEachIndex4 < gdjs.GameSceneCode.forEachTotalCount4;++gdjs.GameSceneCode.forEachIndex4) {
gdjs.GameSceneCode.GDenemy_950Objects4.length = 0;

gdjs.GameSceneCode.GDenemy_951Objects4.length = 0;

gdjs.GameSceneCode.GDenemy_952Objects4.length = 0;


if (gdjs.GameSceneCode.forEachIndex4 < gdjs.GameSceneCode.forEachCount0_4) {
    gdjs.GameSceneCode.GDenemy_950Objects4.push(gdjs.GameSceneCode.forEachObjects4[gdjs.GameSceneCode.forEachIndex4]);
}
else if (gdjs.GameSceneCode.forEachIndex4 < gdjs.GameSceneCode.forEachCount0_4+gdjs.GameSceneCode.forEachCount1_4) {
    gdjs.GameSceneCode.GDenemy_951Objects4.push(gdjs.GameSceneCode.forEachObjects4[gdjs.GameSceneCode.forEachIndex4]);
}
else if (gdjs.GameSceneCode.forEachIndex4 < gdjs.GameSceneCode.forEachCount0_4+gdjs.GameSceneCode.forEachCount1_4+gdjs.GameSceneCode.forEachCount2_4) {
    gdjs.GameSceneCode.GDenemy_952Objects4.push(gdjs.GameSceneCode.forEachObjects4[gdjs.GameSceneCode.forEachIndex4]);
}
if (true) {
{for(var i = 0, len = gdjs.GameSceneCode.GDenemy_950Objects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDenemy_950Objects4[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameSceneCode.GDenemy_951Objects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDenemy_951Objects4[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameSceneCode.GDenemy_952Objects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDenemy_952Objects4[i].deleteFromScene(runtimeScene);
}
}}
}

}


{


gdjs.GameSceneCode.repeatCount4 = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(2));
for(gdjs.GameSceneCode.repeatIndex4 = 0;gdjs.GameSceneCode.repeatIndex4 < gdjs.GameSceneCode.repeatCount4;++gdjs.GameSceneCode.repeatIndex4) {
gdjs.GameSceneCode.GDtxt_95rankingsObjects4.length = 0;


if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtxt_9595rankingsObjects4Objects, 24, 128, "WINLOSE");
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95rankingsObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95rankingsObjects4[i].setString("Wave:" + gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("end_stage_counter")) + " Enemies killed: " + gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(7).getChild("Wave:" + gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("end_stage_counter")))).getChild("enemies_killed")) + " Enemies escaped: " + gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(7).getChild("Wave:" + gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("end_stage_counter")))).getChild("enemies_escaped")) + gdjs.evtTools.string.newLine());
}
}{runtimeScene.getVariables().get("end_stage_counter").add(1);
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95rankingsObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95rankingsObjects4[i].setY((gdjs.GameSceneCode.GDtxt_95rankingsObjects4[i].getY()) + gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("end_stage_counter")) * 16);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95rankingsObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95rankingsObjects4[i].setZOrder(1000);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95rankingsObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95rankingsObjects4[i].hide();
}
}}
}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 30));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\music\\572935__gertraut-hecher__medieval-fanfare.wav", 30, false, 100, 1);
}}

}


{


gdjs.GameSceneCode.repeatCount4 = 6;
for(gdjs.GameSceneCode.repeatIndex4 = 0;gdjs.GameSceneCode.repeatIndex4 < gdjs.GameSceneCode.repeatCount4;++gdjs.GameSceneCode.repeatIndex4) {
gdjs.GameSceneCode.GDvictory_95effectObjects4.length = 0;


if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDvictory_9595effectObjects4Objects, gdjs.randomInRange(64, 580), gdjs.randomInRange(128, 360), "WINLOSE");
}{for(var i = 0, len = gdjs.GameSceneCode.GDvictory_95effectObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDvictory_95effectObjects4[i].setZOrder(1000);
}
}}
}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 31));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\09-fireworks.wav", 31, false, 100, 1);
}}

}


};gdjs.GameSceneCode.eventsList38 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
gdjs.GameSceneCode.condition2IsTrue_0.val = false;
gdjs.GameSceneCode.condition3IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(4)) > gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(2));
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition1IsTrue_0;
gdjs.GameSceneCode.conditionTrue_1.val = (0 == 0);
}
}if ( gdjs.GameSceneCode.condition1IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition2IsTrue_0.val = gdjs.evtTools.common.getVariableBoolean(runtimeScene.getVariables().getFromIndex(9), false);
}if ( gdjs.GameSceneCode.condition2IsTrue_0.val ) {
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition3IsTrue_0;
gdjs.GameSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11734540);
}
}}
}
}
if (gdjs.GameSceneCode.condition3IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("cursor"), gdjs.GameSceneCode.GDcursorObjects2);
gdjs.copyArray(runtimeScene.getObjects("hud_box"), gdjs.GameSceneCode.GDhud_95boxObjects2);
gdjs.copyArray(runtimeScene.getObjects("obj_btn_next"), gdjs.GameSceneCode.GDobj_95btn_95nextObjects2);
gdjs.copyArray(runtimeScene.getObjects("victory"), gdjs.GameSceneCode.GDvictoryObjects2);
{gdjs.evtTools.common.setVariableBoolean(runtimeScene.getVariables().getFromIndex(9), true);
}{gdjs.evtTools.runtimeScene.unpauseTimer(runtimeScene, "endpanel");
}{for(var i = 0, len = gdjs.GameSceneCode.GDhud_95boxObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDhud_95boxObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDhud_95boxObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDhud_95boxObjects2[i].setScaleX(0.1);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDhud_95boxObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDhud_95boxObjects2[i].setScaleY(0.1);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDvictoryObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDvictoryObjects2[i].setScaleY(0.1);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDvictoryObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDvictoryObjects2[i].setScaleX(0.1);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDobj_95btn_95nextObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDobj_95btn_95nextObjects2[i].setScaleY(0.1);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDobj_95btn_95nextObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDobj_95btn_95nextObjects2[i].setScaleX(0.1);
}
}{runtimeScene.getVariables().get("game_level").add(1);
}{gdjs.evtTools.storage.writeNumberInJSONFile("game_data", "game_level", gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("game_level")));
}{for(var i = 0, len = gdjs.GameSceneCode.GDobj_95btn_95nextObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDobj_95btn_95nextObjects2[i].setAnimationName("next_stage");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDvictoryObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDvictoryObjects2[i].setAnimationName("win");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDcursorObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDcursorObjects2[i].setLayer("WINLOSE");
}
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "HUD");
}{gdjs.evtTools.camera.showLayer(runtimeScene, "WINLOSE");
}
{ //Subevents
gdjs.GameSceneCode.eventsList37(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList39 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("txt_rankings"), gdjs.GameSceneCode.GDtxt_95rankingsObjects2);
{gdjs.evtTools.runtimeScene.removeTimer(runtimeScene, "endpanel");
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95rankingsObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95rankingsObjects2[i].hide(false);
}
}}

}


};gdjs.GameSceneCode.eventsList40 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition0IsTrue_0;
gdjs.GameSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11748044);
}
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList39(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList41 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("hud_box"), gdjs.GameSceneCode.GDhud_95boxObjects3);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
gdjs.GameSceneCode.condition2IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 1, "endpanel"));
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDhud_95boxObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDhud_95boxObjects3[i].getScaleY() < 1 ) {
        gdjs.GameSceneCode.condition1IsTrue_0.val = true;
        gdjs.GameSceneCode.GDhud_95boxObjects3[k] = gdjs.GameSceneCode.GDhud_95boxObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDhud_95boxObjects3.length = k;}if ( gdjs.GameSceneCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDhud_95boxObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDhud_95boxObjects3[i].getScaleX() < 1 ) {
        gdjs.GameSceneCode.condition2IsTrue_0.val = true;
        gdjs.GameSceneCode.GDhud_95boxObjects3[k] = gdjs.GameSceneCode.GDhud_95boxObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDhud_95boxObjects3.length = k;}}
}
if (gdjs.GameSceneCode.condition2IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDhud_95boxObjects3 */
gdjs.copyArray(runtimeScene.getObjects("obj_btn_next"), gdjs.GameSceneCode.GDobj_95btn_95nextObjects3);
gdjs.copyArray(runtimeScene.getObjects("victory"), gdjs.GameSceneCode.GDvictoryObjects3);
{for(var i = 0, len = gdjs.GameSceneCode.GDhud_95boxObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDhud_95boxObjects3[i].setScale(gdjs.GameSceneCode.GDhud_95boxObjects3[i].getScale() + (1 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDvictoryObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDvictoryObjects3[i].setScale(gdjs.GameSceneCode.GDvictoryObjects3[i].getScale() + (1 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDobj_95btn_95nextObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDobj_95btn_95nextObjects3[i].setScale(gdjs.GameSceneCode.GDobj_95btn_95nextObjects3[i].getScale() + (1 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 1, "endpanel");
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList40(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList42 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("tower_btn_bullets"), gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects2);
gdjs.copyArray(runtimeScene.getObjects("tower_btn_sell"), gdjs.GameSceneCode.GDtower_95btn_95sellObjects2);
gdjs.copyArray(runtimeScene.getObjects("tower_btn_upgrade"), gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects2);
gdjs.copyArray(runtimeScene.getObjects("tower_panel"), gdjs.GameSceneCode.GDtower_95panelObjects2);
{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95sellObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95sellObjects2[i].setPosition((( gdjs.GameSceneCode.GDtower_95panelObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDtower_95panelObjects2[0].getPointX("sell")),(( gdjs.GameSceneCode.GDtower_95panelObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDtower_95panelObjects2[0].getPointY("sell")));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects2[i].setPosition((( gdjs.GameSceneCode.GDtower_95panelObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDtower_95panelObjects2[0].getPointX("upgrade")),(( gdjs.GameSceneCode.GDtower_95panelObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDtower_95panelObjects2[0].getPointY("upgrade")));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects2[i].setPosition((( gdjs.GameSceneCode.GDtower_95panelObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDtower_95panelObjects2[0].getPointX("bullets")),(( gdjs.GameSceneCode.GDtower_95panelObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDtower_95panelObjects2[0].getPointY("bullets")));
}
}}

}


};gdjs.GameSceneCode.eventsList43 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("txt_rankings"), gdjs.GameSceneCode.GDtxt_95rankingsObjects1);
{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95rankingsObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95rankingsObjects1[i].setX(gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2 - (gdjs.GameSceneCode.GDtxt_95rankingsObjects1[i].getWidth()) / 2);
}
}}

}


};gdjs.GameSceneCode.eventsList44 = function(runtimeScene) {

{


gdjs.GameSceneCode.eventsList26(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList27(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList28(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList29(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList30(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList32(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList33(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList38(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList41(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList42(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList43(runtimeScene);
}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDenemy_95950Objects4ObjectsGDgdjs_46GameSceneCode_46GDenemy_95951Objects4ObjectsGDgdjs_46GameSceneCode_46GDenemy_95952Objects4Objects = Hashtable.newFrom({"enemy_0": gdjs.GameSceneCode.GDenemy_950Objects4, "enemy_1": gdjs.GameSceneCode.GDenemy_951Objects4, "enemy_2": gdjs.GameSceneCode.GDenemy_952Objects4});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDenemy_95950Objects4ObjectsGDgdjs_46GameSceneCode_46GDenemy_95951Objects4ObjectsGDgdjs_46GameSceneCode_46GDenemy_95952Objects4Objects = Hashtable.newFrom({"enemy_0": gdjs.GameSceneCode.GDenemy_950Objects4, "enemy_1": gdjs.GameSceneCode.GDenemy_951Objects4, "enemy_2": gdjs.GameSceneCode.GDenemy_952Objects4});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDenemy_95950Objects3Objects = Hashtable.newFrom({"enemy_0": gdjs.GameSceneCode.GDenemy_950Objects3});gdjs.GameSceneCode.eventsList45 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition0IsTrue_0;
gdjs.GameSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11755036);
}
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("start_path"), gdjs.GameSceneCode.GDstart_95pathObjects3);
/* Reuse gdjs.GameSceneCode.GDenemy_950Objects3 */
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDenemy_95950Objects3Objects, (( gdjs.GameSceneCode.GDstart_95pathObjects3.length === 0 ) ? 0 :gdjs.GameSceneCode.GDstart_95pathObjects3[0].getPointX("")), (( gdjs.GameSceneCode.GDstart_95pathObjects3.length === 0 ) ? 0 :gdjs.GameSceneCode.GDstart_95pathObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.GameSceneCode.GDenemy_950Objects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDenemy_950Objects3[i].setZOrder(3);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDenemy_950Objects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDenemy_950Objects3[i].returnVariable(gdjs.GameSceneCode.GDenemy_950Objects3[i].getVariables().getFromIndex(0)).setNumber(5);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDenemy_950Objects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDenemy_950Objects3[i].returnVariable(gdjs.GameSceneCode.GDenemy_950Objects3[i].getVariables().getFromIndex(2)).setNumber(gdjs.randomInRange(1, 30));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDenemy_950Objects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDenemy_950Objects3[i].getBehavior("Pathfinding").setMaxSpeed(24);
}
}}

}


};gdjs.GameSceneCode.eventsList46 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtsExt__RepeatEveryXSeconds__Repeat.func(runtimeScene, "wave0", 2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList45(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList47 = function(runtimeScene) {

{

gdjs.GameSceneCode.GDenemy_950Objects3.length = 0;

gdjs.GameSceneCode.GDenemy_951Objects3.length = 0;

gdjs.GameSceneCode.GDenemy_952Objects3.length = 0;


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition0IsTrue_0;
gdjs.GameSceneCode.GDenemy_950Objects3_1final.length = 0;gdjs.GameSceneCode.GDenemy_951Objects3_1final.length = 0;gdjs.GameSceneCode.GDenemy_952Objects3_1final.length = 0;gdjs.GameSceneCode.condition0IsTrue_1.val = false;
gdjs.GameSceneCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("enemy_0"), gdjs.GameSceneCode.GDenemy_950Objects4);
gdjs.copyArray(runtimeScene.getObjects("enemy_1"), gdjs.GameSceneCode.GDenemy_951Objects4);
gdjs.copyArray(runtimeScene.getObjects("enemy_2"), gdjs.GameSceneCode.GDenemy_952Objects4);
{gdjs.GameSceneCode.conditionTrue_2 = gdjs.GameSceneCode.condition0IsTrue_1;
gdjs.GameSceneCode.conditionTrue_2.val = (gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) + gdjs.evtTools.object.pickedObjectsCount(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDenemy_95950Objects4ObjectsGDgdjs_46GameSceneCode_46GDenemy_95951Objects4ObjectsGDgdjs_46GameSceneCode_46GDenemy_95952Objects4Objects) + gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(6)) < gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(3)));
}
if( gdjs.GameSceneCode.condition0IsTrue_1.val ) {
    gdjs.GameSceneCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.GameSceneCode.GDenemy_950Objects4.length;j<jLen;++j) {
        if ( gdjs.GameSceneCode.GDenemy_950Objects3_1final.indexOf(gdjs.GameSceneCode.GDenemy_950Objects4[j]) === -1 )
            gdjs.GameSceneCode.GDenemy_950Objects3_1final.push(gdjs.GameSceneCode.GDenemy_950Objects4[j]);
    }
    for(var j = 0, jLen = gdjs.GameSceneCode.GDenemy_951Objects4.length;j<jLen;++j) {
        if ( gdjs.GameSceneCode.GDenemy_951Objects3_1final.indexOf(gdjs.GameSceneCode.GDenemy_951Objects4[j]) === -1 )
            gdjs.GameSceneCode.GDenemy_951Objects3_1final.push(gdjs.GameSceneCode.GDenemy_951Objects4[j]);
    }
    for(var j = 0, jLen = gdjs.GameSceneCode.GDenemy_952Objects4.length;j<jLen;++j) {
        if ( gdjs.GameSceneCode.GDenemy_952Objects3_1final.indexOf(gdjs.GameSceneCode.GDenemy_952Objects4[j]) === -1 )
            gdjs.GameSceneCode.GDenemy_952Objects3_1final.push(gdjs.GameSceneCode.GDenemy_952Objects4[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("enemy_0"), gdjs.GameSceneCode.GDenemy_950Objects4);
gdjs.copyArray(runtimeScene.getObjects("enemy_1"), gdjs.GameSceneCode.GDenemy_951Objects4);
gdjs.copyArray(runtimeScene.getObjects("enemy_2"), gdjs.GameSceneCode.GDenemy_952Objects4);
{gdjs.GameSceneCode.conditionTrue_2 = gdjs.GameSceneCode.condition1IsTrue_1;
gdjs.GameSceneCode.conditionTrue_2.val = (gdjs.evtTools.object.pickedObjectsCount(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDenemy_95950Objects4ObjectsGDgdjs_46GameSceneCode_46GDenemy_95951Objects4ObjectsGDgdjs_46GameSceneCode_46GDenemy_95952Objects4Objects) == 0);
}
if( gdjs.GameSceneCode.condition1IsTrue_1.val ) {
    gdjs.GameSceneCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.GameSceneCode.GDenemy_950Objects4.length;j<jLen;++j) {
        if ( gdjs.GameSceneCode.GDenemy_950Objects3_1final.indexOf(gdjs.GameSceneCode.GDenemy_950Objects4[j]) === -1 )
            gdjs.GameSceneCode.GDenemy_950Objects3_1final.push(gdjs.GameSceneCode.GDenemy_950Objects4[j]);
    }
    for(var j = 0, jLen = gdjs.GameSceneCode.GDenemy_951Objects4.length;j<jLen;++j) {
        if ( gdjs.GameSceneCode.GDenemy_951Objects3_1final.indexOf(gdjs.GameSceneCode.GDenemy_951Objects4[j]) === -1 )
            gdjs.GameSceneCode.GDenemy_951Objects3_1final.push(gdjs.GameSceneCode.GDenemy_951Objects4[j]);
    }
    for(var j = 0, jLen = gdjs.GameSceneCode.GDenemy_952Objects4.length;j<jLen;++j) {
        if ( gdjs.GameSceneCode.GDenemy_952Objects3_1final.indexOf(gdjs.GameSceneCode.GDenemy_952Objects4[j]) === -1 )
            gdjs.GameSceneCode.GDenemy_952Objects3_1final.push(gdjs.GameSceneCode.GDenemy_952Objects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameSceneCode.GDenemy_950Objects3_1final, gdjs.GameSceneCode.GDenemy_950Objects3);
gdjs.copyArray(gdjs.GameSceneCode.GDenemy_951Objects3_1final, gdjs.GameSceneCode.GDenemy_951Objects3);
gdjs.copyArray(gdjs.GameSceneCode.GDenemy_952Objects3_1final, gdjs.GameSceneCode.GDenemy_952Objects3);
}
}
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList46(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList48 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(4)) <= gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(2));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList47(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDenemy_95950Objects4ObjectsGDgdjs_46GameSceneCode_46GDenemy_95951Objects4ObjectsGDgdjs_46GameSceneCode_46GDenemy_95952Objects4Objects = Hashtable.newFrom({"enemy_0": gdjs.GameSceneCode.GDenemy_950Objects4, "enemy_1": gdjs.GameSceneCode.GDenemy_951Objects4, "enemy_2": gdjs.GameSceneCode.GDenemy_952Objects4});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDenemy_95950Objects4ObjectsGDgdjs_46GameSceneCode_46GDenemy_95951Objects4ObjectsGDgdjs_46GameSceneCode_46GDenemy_95952Objects4Objects = Hashtable.newFrom({"enemy_0": gdjs.GameSceneCode.GDenemy_950Objects4, "enemy_1": gdjs.GameSceneCode.GDenemy_951Objects4, "enemy_2": gdjs.GameSceneCode.GDenemy_952Objects4});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDenemy_95950Objects3ObjectsGDgdjs_46GameSceneCode_46GDenemy_95951Objects3ObjectsGDgdjs_46GameSceneCode_46GDenemy_95952Objects3Objects = Hashtable.newFrom({"enemy_0": gdjs.GameSceneCode.GDenemy_950Objects3, "enemy_1": gdjs.GameSceneCode.GDenemy_951Objects3, "enemy_2": gdjs.GameSceneCode.GDenemy_952Objects3});gdjs.GameSceneCode.eventsList49 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition0IsTrue_0;
gdjs.GameSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11759156);
}
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("start_path"), gdjs.GameSceneCode.GDstart_95pathObjects3);
/* Reuse gdjs.GameSceneCode.GDenemy_950Objects3 */
/* Reuse gdjs.GameSceneCode.GDenemy_951Objects3 */
/* Reuse gdjs.GameSceneCode.GDenemy_952Objects3 */
{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDenemy_95950Objects3ObjectsGDgdjs_46GameSceneCode_46GDenemy_95951Objects3ObjectsGDgdjs_46GameSceneCode_46GDenemy_95952Objects3Objects, "enemy_1", (( gdjs.GameSceneCode.GDstart_95pathObjects3.length === 0 ) ? 0 :gdjs.GameSceneCode.GDstart_95pathObjects3[0].getPointX("")), (( gdjs.GameSceneCode.GDstart_95pathObjects3.length === 0 ) ? 0 :gdjs.GameSceneCode.GDstart_95pathObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.GameSceneCode.GDenemy_951Objects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDenemy_951Objects3[i].setZOrder(4);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDenemy_951Objects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDenemy_951Objects3[i].returnVariable(gdjs.GameSceneCode.GDenemy_951Objects3[i].getVariables().getFromIndex(0)).setNumber(6);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDenemy_951Objects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDenemy_951Objects3[i].returnVariable(gdjs.GameSceneCode.GDenemy_951Objects3[i].getVariables().getFromIndex(2)).setNumber(gdjs.randomInRange(31, 60));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDenemy_951Objects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDenemy_951Objects3[i].getBehavior("Pathfinding").setMaxSpeed(32);
}
}}

}


};gdjs.GameSceneCode.eventsList50 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtsExt__RepeatEveryXSeconds__Repeat.func(runtimeScene, "wave1", 1.8, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList49(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList51 = function(runtimeScene) {

{

gdjs.GameSceneCode.GDenemy_950Objects3.length = 0;

gdjs.GameSceneCode.GDenemy_951Objects3.length = 0;

gdjs.GameSceneCode.GDenemy_952Objects3.length = 0;


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition0IsTrue_0;
gdjs.GameSceneCode.GDenemy_950Objects3_1final.length = 0;gdjs.GameSceneCode.GDenemy_951Objects3_1final.length = 0;gdjs.GameSceneCode.GDenemy_952Objects3_1final.length = 0;gdjs.GameSceneCode.condition0IsTrue_1.val = false;
gdjs.GameSceneCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("enemy_0"), gdjs.GameSceneCode.GDenemy_950Objects4);
gdjs.copyArray(runtimeScene.getObjects("enemy_1"), gdjs.GameSceneCode.GDenemy_951Objects4);
gdjs.copyArray(runtimeScene.getObjects("enemy_2"), gdjs.GameSceneCode.GDenemy_952Objects4);
{gdjs.GameSceneCode.conditionTrue_2 = gdjs.GameSceneCode.condition0IsTrue_1;
gdjs.GameSceneCode.conditionTrue_2.val = (gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) + gdjs.evtTools.object.pickedObjectsCount(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDenemy_95950Objects4ObjectsGDgdjs_46GameSceneCode_46GDenemy_95951Objects4ObjectsGDgdjs_46GameSceneCode_46GDenemy_95952Objects4Objects) + gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(6)) < gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(3)));
}
if( gdjs.GameSceneCode.condition0IsTrue_1.val ) {
    gdjs.GameSceneCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.GameSceneCode.GDenemy_950Objects4.length;j<jLen;++j) {
        if ( gdjs.GameSceneCode.GDenemy_950Objects3_1final.indexOf(gdjs.GameSceneCode.GDenemy_950Objects4[j]) === -1 )
            gdjs.GameSceneCode.GDenemy_950Objects3_1final.push(gdjs.GameSceneCode.GDenemy_950Objects4[j]);
    }
    for(var j = 0, jLen = gdjs.GameSceneCode.GDenemy_951Objects4.length;j<jLen;++j) {
        if ( gdjs.GameSceneCode.GDenemy_951Objects3_1final.indexOf(gdjs.GameSceneCode.GDenemy_951Objects4[j]) === -1 )
            gdjs.GameSceneCode.GDenemy_951Objects3_1final.push(gdjs.GameSceneCode.GDenemy_951Objects4[j]);
    }
    for(var j = 0, jLen = gdjs.GameSceneCode.GDenemy_952Objects4.length;j<jLen;++j) {
        if ( gdjs.GameSceneCode.GDenemy_952Objects3_1final.indexOf(gdjs.GameSceneCode.GDenemy_952Objects4[j]) === -1 )
            gdjs.GameSceneCode.GDenemy_952Objects3_1final.push(gdjs.GameSceneCode.GDenemy_952Objects4[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("enemy_0"), gdjs.GameSceneCode.GDenemy_950Objects4);
gdjs.copyArray(runtimeScene.getObjects("enemy_1"), gdjs.GameSceneCode.GDenemy_951Objects4);
gdjs.copyArray(runtimeScene.getObjects("enemy_2"), gdjs.GameSceneCode.GDenemy_952Objects4);
{gdjs.GameSceneCode.conditionTrue_2 = gdjs.GameSceneCode.condition1IsTrue_1;
gdjs.GameSceneCode.conditionTrue_2.val = (gdjs.evtTools.object.pickedObjectsCount(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDenemy_95950Objects4ObjectsGDgdjs_46GameSceneCode_46GDenemy_95951Objects4ObjectsGDgdjs_46GameSceneCode_46GDenemy_95952Objects4Objects) == 0);
}
if( gdjs.GameSceneCode.condition1IsTrue_1.val ) {
    gdjs.GameSceneCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.GameSceneCode.GDenemy_950Objects4.length;j<jLen;++j) {
        if ( gdjs.GameSceneCode.GDenemy_950Objects3_1final.indexOf(gdjs.GameSceneCode.GDenemy_950Objects4[j]) === -1 )
            gdjs.GameSceneCode.GDenemy_950Objects3_1final.push(gdjs.GameSceneCode.GDenemy_950Objects4[j]);
    }
    for(var j = 0, jLen = gdjs.GameSceneCode.GDenemy_951Objects4.length;j<jLen;++j) {
        if ( gdjs.GameSceneCode.GDenemy_951Objects3_1final.indexOf(gdjs.GameSceneCode.GDenemy_951Objects4[j]) === -1 )
            gdjs.GameSceneCode.GDenemy_951Objects3_1final.push(gdjs.GameSceneCode.GDenemy_951Objects4[j]);
    }
    for(var j = 0, jLen = gdjs.GameSceneCode.GDenemy_952Objects4.length;j<jLen;++j) {
        if ( gdjs.GameSceneCode.GDenemy_952Objects3_1final.indexOf(gdjs.GameSceneCode.GDenemy_952Objects4[j]) === -1 )
            gdjs.GameSceneCode.GDenemy_952Objects3_1final.push(gdjs.GameSceneCode.GDenemy_952Objects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameSceneCode.GDenemy_950Objects3_1final, gdjs.GameSceneCode.GDenemy_950Objects3);
gdjs.copyArray(gdjs.GameSceneCode.GDenemy_951Objects3_1final, gdjs.GameSceneCode.GDenemy_951Objects3);
gdjs.copyArray(gdjs.GameSceneCode.GDenemy_952Objects3_1final, gdjs.GameSceneCode.GDenemy_952Objects3);
}
}
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList50(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList52 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(4)) <= gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(2));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList51(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDenemy_95950Objects3ObjectsGDgdjs_46GameSceneCode_46GDenemy_95951Objects3ObjectsGDgdjs_46GameSceneCode_46GDenemy_95952Objects3Objects = Hashtable.newFrom({"enemy_0": gdjs.GameSceneCode.GDenemy_950Objects3, "enemy_1": gdjs.GameSceneCode.GDenemy_951Objects3, "enemy_2": gdjs.GameSceneCode.GDenemy_952Objects3});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDenemy_95950Objects3ObjectsGDgdjs_46GameSceneCode_46GDenemy_95951Objects3ObjectsGDgdjs_46GameSceneCode_46GDenemy_95952Objects3Objects = Hashtable.newFrom({"enemy_0": gdjs.GameSceneCode.GDenemy_950Objects3, "enemy_1": gdjs.GameSceneCode.GDenemy_951Objects3, "enemy_2": gdjs.GameSceneCode.GDenemy_952Objects3});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDenemy_95950Objects2ObjectsGDgdjs_46GameSceneCode_46GDenemy_95951Objects2ObjectsGDgdjs_46GameSceneCode_46GDenemy_95952Objects2Objects = Hashtable.newFrom({"enemy_0": gdjs.GameSceneCode.GDenemy_950Objects2, "enemy_1": gdjs.GameSceneCode.GDenemy_951Objects2, "enemy_2": gdjs.GameSceneCode.GDenemy_952Objects2});gdjs.GameSceneCode.eventsList53 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition0IsTrue_0;
gdjs.GameSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11763332);
}
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("start_path"), gdjs.GameSceneCode.GDstart_95pathObjects2);
/* Reuse gdjs.GameSceneCode.GDenemy_950Objects2 */
/* Reuse gdjs.GameSceneCode.GDenemy_951Objects2 */
/* Reuse gdjs.GameSceneCode.GDenemy_952Objects2 */
{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDenemy_95950Objects2ObjectsGDgdjs_46GameSceneCode_46GDenemy_95951Objects2ObjectsGDgdjs_46GameSceneCode_46GDenemy_95952Objects2Objects, "enemy_2", (( gdjs.GameSceneCode.GDstart_95pathObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDstart_95pathObjects2[0].getPointX("")), (( gdjs.GameSceneCode.GDstart_95pathObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDstart_95pathObjects2[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.GameSceneCode.GDenemy_952Objects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDenemy_952Objects2[i].setZOrder(5);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDenemy_952Objects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDenemy_952Objects2[i].returnVariable(gdjs.GameSceneCode.GDenemy_952Objects2[i].getVariables().getFromIndex(0)).setNumber(10);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDenemy_952Objects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDenemy_952Objects2[i].returnVariable(gdjs.GameSceneCode.GDenemy_952Objects2[i].getVariables().getFromIndex(2)).setNumber(gdjs.randomInRange(61, 80));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDenemy_952Objects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDenemy_952Objects2[i].getBehavior("Pathfinding").setMaxSpeed(45);
}
}}

}


};gdjs.GameSceneCode.eventsList54 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtsExt__RepeatEveryXSeconds__Repeat.func(runtimeScene, "wave2", 3, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList53(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList55 = function(runtimeScene) {

{

gdjs.GameSceneCode.GDenemy_950Objects2.length = 0;

gdjs.GameSceneCode.GDenemy_951Objects2.length = 0;

gdjs.GameSceneCode.GDenemy_952Objects2.length = 0;


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition0IsTrue_0;
gdjs.GameSceneCode.GDenemy_950Objects2_1final.length = 0;gdjs.GameSceneCode.GDenemy_951Objects2_1final.length = 0;gdjs.GameSceneCode.GDenemy_952Objects2_1final.length = 0;gdjs.GameSceneCode.condition0IsTrue_1.val = false;
gdjs.GameSceneCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("enemy_0"), gdjs.GameSceneCode.GDenemy_950Objects3);
gdjs.copyArray(runtimeScene.getObjects("enemy_1"), gdjs.GameSceneCode.GDenemy_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("enemy_2"), gdjs.GameSceneCode.GDenemy_952Objects3);
{gdjs.GameSceneCode.conditionTrue_2 = gdjs.GameSceneCode.condition0IsTrue_1;
gdjs.GameSceneCode.conditionTrue_2.val = (gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) + gdjs.evtTools.object.pickedObjectsCount(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDenemy_95950Objects3ObjectsGDgdjs_46GameSceneCode_46GDenemy_95951Objects3ObjectsGDgdjs_46GameSceneCode_46GDenemy_95952Objects3Objects) + gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(6)) < gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(3)));
}
if( gdjs.GameSceneCode.condition0IsTrue_1.val ) {
    gdjs.GameSceneCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.GameSceneCode.GDenemy_950Objects3.length;j<jLen;++j) {
        if ( gdjs.GameSceneCode.GDenemy_950Objects2_1final.indexOf(gdjs.GameSceneCode.GDenemy_950Objects3[j]) === -1 )
            gdjs.GameSceneCode.GDenemy_950Objects2_1final.push(gdjs.GameSceneCode.GDenemy_950Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.GameSceneCode.GDenemy_951Objects3.length;j<jLen;++j) {
        if ( gdjs.GameSceneCode.GDenemy_951Objects2_1final.indexOf(gdjs.GameSceneCode.GDenemy_951Objects3[j]) === -1 )
            gdjs.GameSceneCode.GDenemy_951Objects2_1final.push(gdjs.GameSceneCode.GDenemy_951Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.GameSceneCode.GDenemy_952Objects3.length;j<jLen;++j) {
        if ( gdjs.GameSceneCode.GDenemy_952Objects2_1final.indexOf(gdjs.GameSceneCode.GDenemy_952Objects3[j]) === -1 )
            gdjs.GameSceneCode.GDenemy_952Objects2_1final.push(gdjs.GameSceneCode.GDenemy_952Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("enemy_0"), gdjs.GameSceneCode.GDenemy_950Objects3);
gdjs.copyArray(runtimeScene.getObjects("enemy_1"), gdjs.GameSceneCode.GDenemy_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("enemy_2"), gdjs.GameSceneCode.GDenemy_952Objects3);
{gdjs.GameSceneCode.conditionTrue_2 = gdjs.GameSceneCode.condition1IsTrue_1;
gdjs.GameSceneCode.conditionTrue_2.val = (gdjs.evtTools.object.pickedObjectsCount(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDenemy_95950Objects3ObjectsGDgdjs_46GameSceneCode_46GDenemy_95951Objects3ObjectsGDgdjs_46GameSceneCode_46GDenemy_95952Objects3Objects) == 0);
}
if( gdjs.GameSceneCode.condition1IsTrue_1.val ) {
    gdjs.GameSceneCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.GameSceneCode.GDenemy_950Objects3.length;j<jLen;++j) {
        if ( gdjs.GameSceneCode.GDenemy_950Objects2_1final.indexOf(gdjs.GameSceneCode.GDenemy_950Objects3[j]) === -1 )
            gdjs.GameSceneCode.GDenemy_950Objects2_1final.push(gdjs.GameSceneCode.GDenemy_950Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.GameSceneCode.GDenemy_951Objects3.length;j<jLen;++j) {
        if ( gdjs.GameSceneCode.GDenemy_951Objects2_1final.indexOf(gdjs.GameSceneCode.GDenemy_951Objects3[j]) === -1 )
            gdjs.GameSceneCode.GDenemy_951Objects2_1final.push(gdjs.GameSceneCode.GDenemy_951Objects3[j]);
    }
    for(var j = 0, jLen = gdjs.GameSceneCode.GDenemy_952Objects3.length;j<jLen;++j) {
        if ( gdjs.GameSceneCode.GDenemy_952Objects2_1final.indexOf(gdjs.GameSceneCode.GDenemy_952Objects3[j]) === -1 )
            gdjs.GameSceneCode.GDenemy_952Objects2_1final.push(gdjs.GameSceneCode.GDenemy_952Objects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameSceneCode.GDenemy_950Objects2_1final, gdjs.GameSceneCode.GDenemy_950Objects2);
gdjs.copyArray(gdjs.GameSceneCode.GDenemy_951Objects2_1final, gdjs.GameSceneCode.GDenemy_951Objects2);
gdjs.copyArray(gdjs.GameSceneCode.GDenemy_952Objects2_1final, gdjs.GameSceneCode.GDenemy_952Objects2);
}
}
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList54(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList56 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(4)) <= gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(2));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList55(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList57 = function(runtimeScene) {

{


gdjs.GameSceneCode.eventsList48(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList52(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList56(runtimeScene);
}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDenemy_95950Objects5ObjectsGDgdjs_46GameSceneCode_46GDenemy_95951Objects5ObjectsGDgdjs_46GameSceneCode_46GDenemy_95952Objects5Objects = Hashtable.newFrom({"enemy_0": gdjs.GameSceneCode.GDenemy_950Objects5, "enemy_1": gdjs.GameSceneCode.GDenemy_951Objects5, "enemy_2": gdjs.GameSceneCode.GDenemy_952Objects5});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDstart_9595pathObjects5Objects = Hashtable.newFrom({"start_path": gdjs.GameSceneCode.GDstart_95pathObjects5});gdjs.GameSceneCode.eventsList58 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameSceneCode.GDenemy_950Objects4, gdjs.GameSceneCode.GDenemy_950Objects5);

gdjs.copyArray(gdjs.GameSceneCode.GDenemy_951Objects4, gdjs.GameSceneCode.GDenemy_951Objects5);

gdjs.copyArray(gdjs.GameSceneCode.GDenemy_952Objects4, gdjs.GameSceneCode.GDenemy_952Objects5);

gdjs.copyArray(runtimeScene.getObjects("start_path"), gdjs.GameSceneCode.GDstart_95pathObjects5);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDenemy_95950Objects5ObjectsGDgdjs_46GameSceneCode_46GDenemy_95951Objects5ObjectsGDgdjs_46GameSceneCode_46GDenemy_95952Objects5Objects, gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDstart_9595pathObjects5Objects, false, runtimeScene, false);
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("end_path"), gdjs.GameSceneCode.GDend_95pathObjects5);
/* Reuse gdjs.GameSceneCode.GDenemy_950Objects5 */
/* Reuse gdjs.GameSceneCode.GDenemy_951Objects5 */
/* Reuse gdjs.GameSceneCode.GDenemy_952Objects5 */
{for(var i = 0, len = gdjs.GameSceneCode.GDenemy_950Objects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDenemy_950Objects5[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.GameSceneCode.GDend_95pathObjects5.length === 0 ) ? 0 :gdjs.GameSceneCode.GDend_95pathObjects5[0].getPointX("")), (( gdjs.GameSceneCode.GDend_95pathObjects5.length === 0 ) ? 0 :gdjs.GameSceneCode.GDend_95pathObjects5[0].getPointY("")));
}
for(var i = 0, len = gdjs.GameSceneCode.GDenemy_951Objects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDenemy_951Objects5[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.GameSceneCode.GDend_95pathObjects5.length === 0 ) ? 0 :gdjs.GameSceneCode.GDend_95pathObjects5[0].getPointX("")), (( gdjs.GameSceneCode.GDend_95pathObjects5.length === 0 ) ? 0 :gdjs.GameSceneCode.GDend_95pathObjects5[0].getPointY("")));
}
for(var i = 0, len = gdjs.GameSceneCode.GDenemy_952Objects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDenemy_952Objects5[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.GameSceneCode.GDend_95pathObjects5.length === 0 ) ? 0 :gdjs.GameSceneCode.GDend_95pathObjects5[0].getPointX("")), (( gdjs.GameSceneCode.GDend_95pathObjects5.length === 0 ) ? 0 :gdjs.GameSceneCode.GDend_95pathObjects5[0].getPointY("")));
}
}}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDenemy_95950Objects2ObjectsGDgdjs_46GameSceneCode_46GDenemy_95951Objects2ObjectsGDgdjs_46GameSceneCode_46GDenemy_95952Objects2Objects = Hashtable.newFrom({"enemy_0": gdjs.GameSceneCode.GDenemy_950Objects2, "enemy_1": gdjs.GameSceneCode.GDenemy_951Objects2, "enemy_2": gdjs.GameSceneCode.GDenemy_952Objects2});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDobstacleObjects2Objects = Hashtable.newFrom({"obstacle": gdjs.GameSceneCode.GDobstacleObjects2});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDobstacleObjects2Objects = Hashtable.newFrom({"obstacle": gdjs.GameSceneCode.GDobstacleObjects2});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDobstacleObjects2Objects = Hashtable.newFrom({"obstacle": gdjs.GameSceneCode.GDobstacleObjects2});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDobstacleObjects2Objects = Hashtable.newFrom({"obstacle": gdjs.GameSceneCode.GDobstacleObjects2});gdjs.GameSceneCode.eventsList59 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("enemy_0"), gdjs.GameSceneCode.GDenemy_950Objects3);
gdjs.copyArray(runtimeScene.getObjects("enemy_1"), gdjs.GameSceneCode.GDenemy_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("enemy_2"), gdjs.GameSceneCode.GDenemy_952Objects3);

gdjs.GameSceneCode.forEachTotalCount4 = 0;
gdjs.GameSceneCode.forEachObjects4.length = 0;
gdjs.GameSceneCode.forEachCount0_4 = gdjs.GameSceneCode.GDenemy_950Objects3.length;
gdjs.GameSceneCode.forEachTotalCount4 += gdjs.GameSceneCode.forEachCount0_4;
gdjs.GameSceneCode.forEachObjects4.push.apply(gdjs.GameSceneCode.forEachObjects4,gdjs.GameSceneCode.GDenemy_950Objects3);
gdjs.GameSceneCode.forEachCount1_4 = gdjs.GameSceneCode.GDenemy_951Objects3.length;
gdjs.GameSceneCode.forEachTotalCount4 += gdjs.GameSceneCode.forEachCount1_4;
gdjs.GameSceneCode.forEachObjects4.push.apply(gdjs.GameSceneCode.forEachObjects4,gdjs.GameSceneCode.GDenemy_951Objects3);
gdjs.GameSceneCode.forEachCount2_4 = gdjs.GameSceneCode.GDenemy_952Objects3.length;
gdjs.GameSceneCode.forEachTotalCount4 += gdjs.GameSceneCode.forEachCount2_4;
gdjs.GameSceneCode.forEachObjects4.push.apply(gdjs.GameSceneCode.forEachObjects4,gdjs.GameSceneCode.GDenemy_952Objects3);
for(gdjs.GameSceneCode.forEachIndex4 = 0;gdjs.GameSceneCode.forEachIndex4 < gdjs.GameSceneCode.forEachTotalCount4;++gdjs.GameSceneCode.forEachIndex4) {
gdjs.GameSceneCode.GDenemy_950Objects4.length = 0;

gdjs.GameSceneCode.GDenemy_951Objects4.length = 0;

gdjs.GameSceneCode.GDenemy_952Objects4.length = 0;


if (gdjs.GameSceneCode.forEachIndex4 < gdjs.GameSceneCode.forEachCount0_4) {
    gdjs.GameSceneCode.GDenemy_950Objects4.push(gdjs.GameSceneCode.forEachObjects4[gdjs.GameSceneCode.forEachIndex4]);
}
else if (gdjs.GameSceneCode.forEachIndex4 < gdjs.GameSceneCode.forEachCount0_4+gdjs.GameSceneCode.forEachCount1_4) {
    gdjs.GameSceneCode.GDenemy_951Objects4.push(gdjs.GameSceneCode.forEachObjects4[gdjs.GameSceneCode.forEachIndex4]);
}
else if (gdjs.GameSceneCode.forEachIndex4 < gdjs.GameSceneCode.forEachCount0_4+gdjs.GameSceneCode.forEachCount1_4+gdjs.GameSceneCode.forEachCount2_4) {
    gdjs.GameSceneCode.GDenemy_952Objects4.push(gdjs.GameSceneCode.forEachObjects4[gdjs.GameSceneCode.forEachIndex4]);
}
if (true) {

{ //Subevents: 
gdjs.GameSceneCode.eventsList58(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("enemy_0"), gdjs.GameSceneCode.GDenemy_950Objects2);
gdjs.copyArray(runtimeScene.getObjects("enemy_1"), gdjs.GameSceneCode.GDenemy_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("enemy_2"), gdjs.GameSceneCode.GDenemy_952Objects2);
gdjs.copyArray(runtimeScene.getObjects("obstacle"), gdjs.GameSceneCode.GDobstacleObjects2);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDenemy_95950Objects2ObjectsGDgdjs_46GameSceneCode_46GDenemy_95951Objects2ObjectsGDgdjs_46GameSceneCode_46GDenemy_95952Objects2Objects, gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDobstacleObjects2Objects, false, runtimeScene, false);
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDenemy_950Objects2 */
/* Reuse gdjs.GameSceneCode.GDenemy_951Objects2 */
/* Reuse gdjs.GameSceneCode.GDenemy_952Objects2 */
/* Reuse gdjs.GameSceneCode.GDobstacleObjects2 */
{for(var i = 0, len = gdjs.GameSceneCode.GDenemy_950Objects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDenemy_950Objects2[i].separateFromObjectsList(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDobstacleObjects2Objects, true);
}
for(var i = 0, len = gdjs.GameSceneCode.GDenemy_951Objects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDenemy_951Objects2[i].separateFromObjectsList(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDobstacleObjects2Objects, true);
}
for(var i = 0, len = gdjs.GameSceneCode.GDenemy_952Objects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDenemy_952Objects2[i].separateFromObjectsList(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDobstacleObjects2Objects, true);
}
}}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDarrow_9595explosionObjects3Objects = Hashtable.newFrom({"arrow_explosion": gdjs.GameSceneCode.GDarrow_95explosionObjects3});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDarrow_9595explosionObjects3Objects = Hashtable.newFrom({"arrow_explosion": gdjs.GameSceneCode.GDarrow_95explosionObjects3});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDarrow_9595explosionObjects3Objects = Hashtable.newFrom({"arrow_explosion": gdjs.GameSceneCode.GDarrow_95explosionObjects3});gdjs.GameSceneCode.eventsList60 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("tower"), gdjs.GameSceneCode.GDtowerObjects3);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtowerObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtowerObjects3[i].getVariableString(gdjs.GameSceneCode.GDtowerObjects3[i].getVariables().getFromIndex(7)) == "archers" ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtowerObjects3[k] = gdjs.GameSceneCode.GDtowerObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtowerObjects3.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.GameSceneCode.GDenemy_950Objects2, gdjs.GameSceneCode.GDenemy_950Objects3);

gdjs.copyArray(gdjs.GameSceneCode.GDenemy_951Objects2, gdjs.GameSceneCode.GDenemy_951Objects3);

gdjs.copyArray(gdjs.GameSceneCode.GDenemy_952Objects2, gdjs.GameSceneCode.GDenemy_952Objects3);

gdjs.GameSceneCode.GDarrow_95explosionObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDarrow_9595explosionObjects3Objects, (( gdjs.GameSceneCode.GDenemy_952Objects3.length === 0 ) ? (( gdjs.GameSceneCode.GDenemy_951Objects3.length === 0 ) ? (( gdjs.GameSceneCode.GDenemy_950Objects3.length === 0 ) ? 0 :gdjs.GameSceneCode.GDenemy_950Objects3[0].getPointX("")) :gdjs.GameSceneCode.GDenemy_951Objects3[0].getPointX("")) :gdjs.GameSceneCode.GDenemy_952Objects3[0].getPointX("")), (( gdjs.GameSceneCode.GDenemy_952Objects3.length === 0 ) ? (( gdjs.GameSceneCode.GDenemy_951Objects3.length === 0 ) ? (( gdjs.GameSceneCode.GDenemy_950Objects3.length === 0 ) ? 0 :gdjs.GameSceneCode.GDenemy_950Objects3[0].getPointY("")) :gdjs.GameSceneCode.GDenemy_951Objects3[0].getPointY("")) :gdjs.GameSceneCode.GDenemy_952Objects3[0].getPointY("")), "");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("tower"), gdjs.GameSceneCode.GDtowerObjects3);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtowerObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtowerObjects3[i].getVariableString(gdjs.GameSceneCode.GDtowerObjects3[i].getVariables().getFromIndex(7)) == "wizards" ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtowerObjects3[k] = gdjs.GameSceneCode.GDtowerObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtowerObjects3.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.GameSceneCode.GDenemy_950Objects2, gdjs.GameSceneCode.GDenemy_950Objects3);

gdjs.copyArray(gdjs.GameSceneCode.GDenemy_951Objects2, gdjs.GameSceneCode.GDenemy_951Objects3);

gdjs.copyArray(gdjs.GameSceneCode.GDenemy_952Objects2, gdjs.GameSceneCode.GDenemy_952Objects3);

gdjs.GameSceneCode.GDarrow_95explosionObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDarrow_9595explosionObjects3Objects, (( gdjs.GameSceneCode.GDenemy_952Objects3.length === 0 ) ? (( gdjs.GameSceneCode.GDenemy_951Objects3.length === 0 ) ? (( gdjs.GameSceneCode.GDenemy_950Objects3.length === 0 ) ? 0 :gdjs.GameSceneCode.GDenemy_950Objects3[0].getPointX("")) :gdjs.GameSceneCode.GDenemy_951Objects3[0].getPointX("")) :gdjs.GameSceneCode.GDenemy_952Objects3[0].getPointX("")), (( gdjs.GameSceneCode.GDenemy_952Objects3.length === 0 ) ? (( gdjs.GameSceneCode.GDenemy_951Objects3.length === 0 ) ? (( gdjs.GameSceneCode.GDenemy_950Objects3.length === 0 ) ? 0 :gdjs.GameSceneCode.GDenemy_950Objects3[0].getPointY("")) :gdjs.GameSceneCode.GDenemy_951Objects3[0].getPointY("")) :gdjs.GameSceneCode.GDenemy_952Objects3[0].getPointY("")), "");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("tower"), gdjs.GameSceneCode.GDtowerObjects3);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtowerObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtowerObjects3[i].getVariableString(gdjs.GameSceneCode.GDtowerObjects3[i].getVariables().getFromIndex(7)) == "melee" ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtowerObjects3[k] = gdjs.GameSceneCode.GDtowerObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtowerObjects3.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.GameSceneCode.GDenemy_950Objects2, gdjs.GameSceneCode.GDenemy_950Objects3);

gdjs.copyArray(gdjs.GameSceneCode.GDenemy_951Objects2, gdjs.GameSceneCode.GDenemy_951Objects3);

gdjs.copyArray(gdjs.GameSceneCode.GDenemy_952Objects2, gdjs.GameSceneCode.GDenemy_952Objects3);

gdjs.GameSceneCode.GDarrow_95explosionObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDarrow_9595explosionObjects3Objects, (( gdjs.GameSceneCode.GDenemy_952Objects3.length === 0 ) ? (( gdjs.GameSceneCode.GDenemy_951Objects3.length === 0 ) ? (( gdjs.GameSceneCode.GDenemy_950Objects3.length === 0 ) ? 0 :gdjs.GameSceneCode.GDenemy_950Objects3[0].getPointX("")) :gdjs.GameSceneCode.GDenemy_951Objects3[0].getPointX("")) :gdjs.GameSceneCode.GDenemy_952Objects3[0].getPointX("")), (( gdjs.GameSceneCode.GDenemy_952Objects3.length === 0 ) ? (( gdjs.GameSceneCode.GDenemy_951Objects3.length === 0 ) ? (( gdjs.GameSceneCode.GDenemy_950Objects3.length === 0 ) ? 0 :gdjs.GameSceneCode.GDenemy_950Objects3[0].getPointY("")) :gdjs.GameSceneCode.GDenemy_951Objects3[0].getPointY("")) :gdjs.GameSceneCode.GDenemy_952Objects3[0].getPointY("")), "");
}}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 22));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\crashbones.wav", 22, false, 100, 1);
}}

}


{


{
/* Reuse gdjs.GameSceneCode.GDenemy_950Objects2 */
/* Reuse gdjs.GameSceneCode.GDenemy_951Objects2 */
/* Reuse gdjs.GameSceneCode.GDenemy_952Objects2 */
{for(var i = 0, len = gdjs.GameSceneCode.GDenemy_950Objects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDenemy_950Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameSceneCode.GDenemy_951Objects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDenemy_951Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameSceneCode.GDenemy_952Objects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDenemy_952Objects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getVariables().getFromIndex(1).add(1);
}{runtimeScene.getVariables().getFromIndex(0).add((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDenemy_952Objects2.length === 0 ) ? ((gdjs.GameSceneCode.GDenemy_951Objects2.length === 0 ) ? ((gdjs.GameSceneCode.GDenemy_950Objects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDenemy_950Objects2[0].getVariables()) : gdjs.GameSceneCode.GDenemy_951Objects2[0].getVariables()) : gdjs.GameSceneCode.GDenemy_952Objects2[0].getVariables()).get("coins"))));
}}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDenemy_95950Objects2ObjectsGDgdjs_46GameSceneCode_46GDenemy_95951Objects2ObjectsGDgdjs_46GameSceneCode_46GDenemy_95952Objects2Objects = Hashtable.newFrom({"enemy_0": gdjs.GameSceneCode.GDenemy_950Objects2, "enemy_1": gdjs.GameSceneCode.GDenemy_951Objects2, "enemy_2": gdjs.GameSceneCode.GDenemy_952Objects2});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDend_9595pathObjects2Objects = Hashtable.newFrom({"end_path": gdjs.GameSceneCode.GDend_95pathObjects2});gdjs.GameSceneCode.eventsList61 = function(runtimeScene) {

};gdjs.GameSceneCode.eventsList62 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("enemy_0"), gdjs.GameSceneCode.GDenemy_950Objects2);
gdjs.copyArray(runtimeScene.getObjects("enemy_1"), gdjs.GameSceneCode.GDenemy_951Objects2);
gdjs.copyArray(runtimeScene.getObjects("enemy_2"), gdjs.GameSceneCode.GDenemy_952Objects2);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDenemy_950Objects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDenemy_950Objects2[i].getVariableNumber(gdjs.GameSceneCode.GDenemy_950Objects2[i].getVariables().get("hp")) <= 0 ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDenemy_950Objects2[k] = gdjs.GameSceneCode.GDenemy_950Objects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDenemy_950Objects2.length = k;for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDenemy_951Objects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDenemy_951Objects2[i].getVariableNumber(gdjs.GameSceneCode.GDenemy_951Objects2[i].getVariables().get("hp")) <= 0 ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDenemy_951Objects2[k] = gdjs.GameSceneCode.GDenemy_951Objects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDenemy_951Objects2.length = k;for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDenemy_952Objects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDenemy_952Objects2[i].getVariableNumber(gdjs.GameSceneCode.GDenemy_952Objects2[i].getVariables().get("hp")) <= 0 ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDenemy_952Objects2[k] = gdjs.GameSceneCode.GDenemy_952Objects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDenemy_952Objects2.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList60(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("enemy_0"), gdjs.GameSceneCode.GDenemy_950Objects1);
gdjs.copyArray(runtimeScene.getObjects("enemy_1"), gdjs.GameSceneCode.GDenemy_951Objects1);
gdjs.copyArray(runtimeScene.getObjects("enemy_2"), gdjs.GameSceneCode.GDenemy_952Objects1);

gdjs.GameSceneCode.forEachTotalCount2 = 0;
gdjs.GameSceneCode.forEachObjects2.length = 0;
gdjs.GameSceneCode.forEachCount0_2 = gdjs.GameSceneCode.GDenemy_950Objects1.length;
gdjs.GameSceneCode.forEachTotalCount2 += gdjs.GameSceneCode.forEachCount0_2;
gdjs.GameSceneCode.forEachObjects2.push.apply(gdjs.GameSceneCode.forEachObjects2,gdjs.GameSceneCode.GDenemy_950Objects1);
gdjs.GameSceneCode.forEachCount1_2 = gdjs.GameSceneCode.GDenemy_951Objects1.length;
gdjs.GameSceneCode.forEachTotalCount2 += gdjs.GameSceneCode.forEachCount1_2;
gdjs.GameSceneCode.forEachObjects2.push.apply(gdjs.GameSceneCode.forEachObjects2,gdjs.GameSceneCode.GDenemy_951Objects1);
gdjs.GameSceneCode.forEachCount2_2 = gdjs.GameSceneCode.GDenemy_952Objects1.length;
gdjs.GameSceneCode.forEachTotalCount2 += gdjs.GameSceneCode.forEachCount2_2;
gdjs.GameSceneCode.forEachObjects2.push.apply(gdjs.GameSceneCode.forEachObjects2,gdjs.GameSceneCode.GDenemy_952Objects1);
for(gdjs.GameSceneCode.forEachIndex2 = 0;gdjs.GameSceneCode.forEachIndex2 < gdjs.GameSceneCode.forEachTotalCount2;++gdjs.GameSceneCode.forEachIndex2) {
gdjs.copyArray(runtimeScene.getObjects("base_hp"), gdjs.GameSceneCode.GDbase_95hpObjects2);
gdjs.copyArray(runtimeScene.getObjects("end_path"), gdjs.GameSceneCode.GDend_95pathObjects2);
gdjs.GameSceneCode.GDenemy_950Objects2.length = 0;

gdjs.GameSceneCode.GDenemy_951Objects2.length = 0;

gdjs.GameSceneCode.GDenemy_952Objects2.length = 0;


if (gdjs.GameSceneCode.forEachIndex2 < gdjs.GameSceneCode.forEachCount0_2) {
    gdjs.GameSceneCode.GDenemy_950Objects2.push(gdjs.GameSceneCode.forEachObjects2[gdjs.GameSceneCode.forEachIndex2]);
}
else if (gdjs.GameSceneCode.forEachIndex2 < gdjs.GameSceneCode.forEachCount0_2+gdjs.GameSceneCode.forEachCount1_2) {
    gdjs.GameSceneCode.GDenemy_951Objects2.push(gdjs.GameSceneCode.forEachObjects2[gdjs.GameSceneCode.forEachIndex2]);
}
else if (gdjs.GameSceneCode.forEachIndex2 < gdjs.GameSceneCode.forEachCount0_2+gdjs.GameSceneCode.forEachCount1_2+gdjs.GameSceneCode.forEachCount2_2) {
    gdjs.GameSceneCode.GDenemy_952Objects2.push(gdjs.GameSceneCode.forEachObjects2[gdjs.GameSceneCode.forEachIndex2]);
}
gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDenemy_95950Objects2ObjectsGDgdjs_46GameSceneCode_46GDenemy_95951Objects2ObjectsGDgdjs_46GameSceneCode_46GDenemy_95952Objects2Objects, gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDend_9595pathObjects2Objects, false, runtimeScene, false);
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.GameSceneCode.GDenemy_950Objects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDenemy_950Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameSceneCode.GDenemy_951Objects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDenemy_951Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameSceneCode.GDenemy_952Objects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDenemy_952Objects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getVariables().getFromIndex(6).add(1);
}{runtimeScene.getVariables().getFromIndex(10).sub(1);
}{for(var i = 0, len = gdjs.GameSceneCode.GDbase_95hpObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDbase_95hpObjects2[i].setAnimationFrame(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)));
}
}}
}

}


};gdjs.GameSceneCode.eventsList63 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableBoolean(runtimeScene.getVariables().getFromIndex(9), false);
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition1IsTrue_0.val = gdjs.evtTools.common.getVariableBoolean(runtimeScene.getVariables().get("tutorial"), false);
}}
if (gdjs.GameSceneCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList57(runtimeScene);} //End of subevents
}

}


{


gdjs.GameSceneCode.eventsList59(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList62(runtimeScene);
}


};gdjs.GameSceneCode.eventsList64 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("hud_bottom_panel"), gdjs.GameSceneCode.GDhud_95bottom_95panelObjects2);
gdjs.copyArray(runtimeScene.getObjects("txt_coins"), gdjs.GameSceneCode.GDtxt_95coinsObjects2);
gdjs.copyArray(runtimeScene.getObjects("txt_enemies_escaped"), gdjs.GameSceneCode.GDtxt_95enemies_95escapedObjects2);
gdjs.copyArray(runtimeScene.getObjects("txt_kills_this_wave"), gdjs.GameSceneCode.GDtxt_95kills_95this_95waveObjects2);
gdjs.copyArray(runtimeScene.getObjects("txt_wave"), gdjs.GameSceneCode.GDtxt_95waveObjects2);
{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95kills_95this_95waveObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95kills_95this_95waveObjects2[i].setPosition((( gdjs.GameSceneCode.GDhud_95bottom_95panelObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDhud_95bottom_95panelObjects2[0].getPointX("killed")),(( gdjs.GameSceneCode.GDhud_95bottom_95panelObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDhud_95bottom_95panelObjects2[0].getPointY("killed")));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95enemies_95escapedObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95enemies_95escapedObjects2[i].setPosition((( gdjs.GameSceneCode.GDhud_95bottom_95panelObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDhud_95bottom_95panelObjects2[0].getPointX("escaped")),(( gdjs.GameSceneCode.GDhud_95bottom_95panelObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDhud_95bottom_95panelObjects2[0].getPointY("escaped")));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95waveObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95waveObjects2[i].setPosition((( gdjs.GameSceneCode.GDhud_95bottom_95panelObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDhud_95bottom_95panelObjects2[0].getPointX("wave")),(( gdjs.GameSceneCode.GDhud_95bottom_95panelObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDhud_95bottom_95panelObjects2[0].getPointY("wave")));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95coinsObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95coinsObjects2[i].setPosition((( gdjs.GameSceneCode.GDhud_95bottom_95panelObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDhud_95bottom_95panelObjects2[0].getPointX("coins")),(( gdjs.GameSceneCode.GDhud_95bottom_95panelObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDhud_95bottom_95panelObjects2[0].getPointY("coins")));
}
}}

}


};gdjs.GameSceneCode.eventsList65 = function(runtimeScene) {

{

gdjs.GameSceneCode.GDtower_95btnObjects3.length = 0;


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("game_level")) == 1;
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition1IsTrue_0;
gdjs.GameSceneCode.condition0IsTrue_1.val = false;
{
{gdjs.GameSceneCode.conditionTrue_2 = gdjs.GameSceneCode.condition0IsTrue_1;
gdjs.GameSceneCode.GDtower_95btnObjects3_2final.length = 0;gdjs.GameSceneCode.condition0IsTrue_2.val = false;
gdjs.GameSceneCode.condition1IsTrue_2.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("tower_btn"), gdjs.GameSceneCode.GDtower_95btnObjects4);
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtower_95btnObjects4.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtower_95btnObjects4[i].isCurrentAnimationName("wizards") ) {
        gdjs.GameSceneCode.condition0IsTrue_2.val = true;
        gdjs.GameSceneCode.GDtower_95btnObjects4[k] = gdjs.GameSceneCode.GDtower_95btnObjects4[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtower_95btnObjects4.length = k;if( gdjs.GameSceneCode.condition0IsTrue_2.val ) {
    gdjs.GameSceneCode.conditionTrue_2.val = true;
    for(var j = 0, jLen = gdjs.GameSceneCode.GDtower_95btnObjects4.length;j<jLen;++j) {
        if ( gdjs.GameSceneCode.GDtower_95btnObjects3_2final.indexOf(gdjs.GameSceneCode.GDtower_95btnObjects4[j]) === -1 )
            gdjs.GameSceneCode.GDtower_95btnObjects3_2final.push(gdjs.GameSceneCode.GDtower_95btnObjects4[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("tower_btn"), gdjs.GameSceneCode.GDtower_95btnObjects4);
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtower_95btnObjects4.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtower_95btnObjects4[i].isCurrentAnimationName("melee") ) {
        gdjs.GameSceneCode.condition1IsTrue_2.val = true;
        gdjs.GameSceneCode.GDtower_95btnObjects4[k] = gdjs.GameSceneCode.GDtower_95btnObjects4[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtower_95btnObjects4.length = k;if( gdjs.GameSceneCode.condition1IsTrue_2.val ) {
    gdjs.GameSceneCode.conditionTrue_2.val = true;
    for(var j = 0, jLen = gdjs.GameSceneCode.GDtower_95btnObjects4.length;j<jLen;++j) {
        if ( gdjs.GameSceneCode.GDtower_95btnObjects3_2final.indexOf(gdjs.GameSceneCode.GDtower_95btnObjects4[j]) === -1 )
            gdjs.GameSceneCode.GDtower_95btnObjects3_2final.push(gdjs.GameSceneCode.GDtower_95btnObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameSceneCode.GDtower_95btnObjects3_2final, gdjs.GameSceneCode.GDtower_95btnObjects3);
}
}
}gdjs.GameSceneCode.conditionTrue_1.val = true && gdjs.GameSceneCode.condition0IsTrue_1.val;
}
}}
if (gdjs.GameSceneCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDtower_95btnObjects3 */
{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btnObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btnObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("tower_btn"), gdjs.GameSceneCode.GDtower_95btnObjects2);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("game_level")) == 2;
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtower_95btnObjects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtower_95btnObjects2[i].isCurrentAnimationName("melee") ) {
        gdjs.GameSceneCode.condition1IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtower_95btnObjects2[k] = gdjs.GameSceneCode.GDtower_95btnObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtower_95btnObjects2.length = k;}}
if (gdjs.GameSceneCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDtower_95btnObjects2 */
{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btnObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btnObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.GameSceneCode.eventsList66 = function(runtimeScene) {

{


gdjs.GameSceneCode.eventsList64(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList65(runtimeScene);
}


{


{
gdjs.copyArray(runtimeScene.getObjects("base_hp"), gdjs.GameSceneCode.GDbase_95hpObjects1);
{for(var i = 0, len = gdjs.GameSceneCode.GDbase_95hpObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDbase_95hpObjects1[i].setAnimationFrame(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)));
}
}}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_9595btnObjects3Objects = Hashtable.newFrom({"tower_btn": gdjs.GameSceneCode.GDtower_95btnObjects3});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtowerObjects3Objects = Hashtable.newFrom({"tower": gdjs.GameSceneCode.GDtowerObjects3});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95951_9595topObjects5Objects = Hashtable.newFrom({"tower_1_top": gdjs.GameSceneCode.GDtower_951_95topObjects5});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95952_9595topObjects5Objects = Hashtable.newFrom({"tower_2_top": gdjs.GameSceneCode.GDtower_952_95topObjects5});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95953_9595topObjects4Objects = Hashtable.newFrom({"tower_3_top": gdjs.GameSceneCode.GDtower_953_95topObjects4});gdjs.GameSceneCode.eventsList67 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameSceneCode.GDtowerObjects4, gdjs.GameSceneCode.GDtowerObjects5);

gdjs.copyArray(gdjs.GameSceneCode.GDtower_95btnObjects3, gdjs.GameSceneCode.GDtower_95btnObjects5);


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtower_95btnObjects5.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtower_95btnObjects5[i].isCurrentAnimationName("archers") ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtower_95btnObjects5[k] = gdjs.GameSceneCode.GDtower_95btnObjects5[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtower_95btnObjects5.length = k;}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtowerObjects5.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtowerObjects5[i].getVariableString(gdjs.GameSceneCode.GDtowerObjects5[i].getVariables().getFromIndex(7)) == "archers" ) {
        gdjs.GameSceneCode.condition1IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtowerObjects5[k] = gdjs.GameSceneCode.GDtowerObjects5[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtowerObjects5.length = k;}}
if (gdjs.GameSceneCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDtowerObjects5 */
/* Reuse gdjs.GameSceneCode.GDtower_95btnObjects5 */
gdjs.GameSceneCode.GDtower_951_95topObjects5.length = 0;

{for(var i = 0, len = gdjs.GameSceneCode.GDtowerObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtowerObjects5[i].setVariableBoolean(gdjs.GameSceneCode.GDtowerObjects5[i].getVariables().getFromIndex(0), true);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtowerObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtowerObjects5[i].returnVariable(gdjs.GameSceneCode.GDtowerObjects5[i].getVariables().getFromIndex(1)).setNumber((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtower_95btnObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtower_95btnObjects5[0].getVariables()).getFromIndex(1))));
}
}{runtimeScene.getVariables().getFromIndex(0).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtowerObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtowerObjects5[0].getVariables()).getFromIndex(4))));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95951_9595topObjects5Objects, (( gdjs.GameSceneCode.GDtowerObjects5.length === 0 ) ? 0 :gdjs.GameSceneCode.GDtowerObjects5[0].getPointX("top")), (( gdjs.GameSceneCode.GDtowerObjects5.length === 0 ) ? 0 :gdjs.GameSceneCode.GDtowerObjects5[0].getPointY("top")), "");
}{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.GameSceneCode.GDtower_951_95topObjects5.length !== 0 ? gdjs.GameSceneCode.GDtower_951_95topObjects5[0] : null), (gdjs.GameSceneCode.GDtowerObjects5.length !== 0 ? gdjs.GameSceneCode.GDtowerObjects5[0] : null));
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_951_95topObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_951_95topObjects5[i].setZOrder(12);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_951_95topObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_951_95topObjects5[i].returnVariable(gdjs.GameSceneCode.GDtower_951_95topObjects5[i].getVariables().getFromIndex(1)).setNumber((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtowerObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtowerObjects5[0].getVariables()).getFromIndex(3))));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_951_95topObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_951_95topObjects5[i].returnVariable(gdjs.GameSceneCode.GDtower_951_95topObjects5[i].getVariables().getFromIndex(0)).setNumber((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtowerObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtowerObjects5[0].getVariables()).getFromIndex(1))));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtowerObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtowerObjects5[i].setAnimationName("tower_1_grade_" + (gdjs.RuntimeObject.getVariableString(gdjs.GameSceneCode.GDtowerObjects5[i].getVariables().getFromIndex(1))));
}
}}

}


{

gdjs.copyArray(gdjs.GameSceneCode.GDtowerObjects4, gdjs.GameSceneCode.GDtowerObjects5);

gdjs.copyArray(gdjs.GameSceneCode.GDtower_95btnObjects3, gdjs.GameSceneCode.GDtower_95btnObjects5);


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtower_95btnObjects5.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtower_95btnObjects5[i].isCurrentAnimationName("wizards") ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtower_95btnObjects5[k] = gdjs.GameSceneCode.GDtower_95btnObjects5[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtower_95btnObjects5.length = k;}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtowerObjects5.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtowerObjects5[i].getVariableString(gdjs.GameSceneCode.GDtowerObjects5[i].getVariables().getFromIndex(7)) == "wizards" ) {
        gdjs.GameSceneCode.condition1IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtowerObjects5[k] = gdjs.GameSceneCode.GDtowerObjects5[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtowerObjects5.length = k;}}
if (gdjs.GameSceneCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDtowerObjects5 */
/* Reuse gdjs.GameSceneCode.GDtower_95btnObjects5 */
gdjs.GameSceneCode.GDtower_952_95topObjects5.length = 0;

{for(var i = 0, len = gdjs.GameSceneCode.GDtowerObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtowerObjects5[i].setVariableBoolean(gdjs.GameSceneCode.GDtowerObjects5[i].getVariables().getFromIndex(0), true);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtowerObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtowerObjects5[i].returnVariable(gdjs.GameSceneCode.GDtowerObjects5[i].getVariables().getFromIndex(1)).setNumber((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtower_95btnObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtower_95btnObjects5[0].getVariables()).getFromIndex(1))));
}
}{runtimeScene.getVariables().getFromIndex(0).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtowerObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtowerObjects5[0].getVariables()).getFromIndex(4))));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95952_9595topObjects5Objects, (( gdjs.GameSceneCode.GDtowerObjects5.length === 0 ) ? 0 :gdjs.GameSceneCode.GDtowerObjects5[0].getPointX("")) + 4, (( gdjs.GameSceneCode.GDtowerObjects5.length === 0 ) ? 0 :gdjs.GameSceneCode.GDtowerObjects5[0].getPointY("")) - 16, "");
}{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.GameSceneCode.GDtower_952_95topObjects5.length !== 0 ? gdjs.GameSceneCode.GDtower_952_95topObjects5[0] : null), (gdjs.GameSceneCode.GDtowerObjects5.length !== 0 ? gdjs.GameSceneCode.GDtowerObjects5[0] : null));
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_952_95topObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_952_95topObjects5[i].setZOrder(12);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_952_95topObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_952_95topObjects5[i].returnVariable(gdjs.GameSceneCode.GDtower_952_95topObjects5[i].getVariables().getFromIndex(1)).setNumber((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtowerObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtowerObjects5[0].getVariables()).getFromIndex(3))));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_952_95topObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_952_95topObjects5[i].returnVariable(gdjs.GameSceneCode.GDtower_952_95topObjects5[i].getVariables().getFromIndex(0)).setNumber((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtowerObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtowerObjects5[0].getVariables()).getFromIndex(1))));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtowerObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtowerObjects5[i].setAnimationName("tower_2_grade_" + (gdjs.RuntimeObject.getVariableString(gdjs.GameSceneCode.GDtowerObjects5[i].getVariables().getFromIndex(1))));
}
}}

}


{

/* Reuse gdjs.GameSceneCode.GDtowerObjects4 */
gdjs.copyArray(gdjs.GameSceneCode.GDtower_95btnObjects3, gdjs.GameSceneCode.GDtower_95btnObjects4);


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtower_95btnObjects4.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtower_95btnObjects4[i].isCurrentAnimationName("melee") ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtower_95btnObjects4[k] = gdjs.GameSceneCode.GDtower_95btnObjects4[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtower_95btnObjects4.length = k;}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtowerObjects4.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtowerObjects4[i].getVariableString(gdjs.GameSceneCode.GDtowerObjects4[i].getVariables().getFromIndex(7)) == "melee" ) {
        gdjs.GameSceneCode.condition1IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtowerObjects4[k] = gdjs.GameSceneCode.GDtowerObjects4[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtowerObjects4.length = k;}}
if (gdjs.GameSceneCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDtowerObjects4 */
/* Reuse gdjs.GameSceneCode.GDtower_95btnObjects4 */
gdjs.GameSceneCode.GDtower_953_95topObjects4.length = 0;

{for(var i = 0, len = gdjs.GameSceneCode.GDtowerObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtowerObjects4[i].setVariableBoolean(gdjs.GameSceneCode.GDtowerObjects4[i].getVariables().getFromIndex(0), true);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtowerObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtowerObjects4[i].returnVariable(gdjs.GameSceneCode.GDtowerObjects4[i].getVariables().getFromIndex(1)).setNumber((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtower_95btnObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtower_95btnObjects4[0].getVariables()).getFromIndex(1))));
}
}{runtimeScene.getVariables().getFromIndex(0).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtowerObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtowerObjects4[0].getVariables()).getFromIndex(4))));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95953_9595topObjects4Objects, (( gdjs.GameSceneCode.GDtowerObjects4.length === 0 ) ? 0 :gdjs.GameSceneCode.GDtowerObjects4[0].getPointX("top")), (( gdjs.GameSceneCode.GDtowerObjects4.length === 0 ) ? 0 :gdjs.GameSceneCode.GDtowerObjects4[0].getPointY("top")), "");
}{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.GameSceneCode.GDtower_953_95topObjects4.length !== 0 ? gdjs.GameSceneCode.GDtower_953_95topObjects4[0] : null), (gdjs.GameSceneCode.GDtowerObjects4.length !== 0 ? gdjs.GameSceneCode.GDtowerObjects4[0] : null));
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_953_95topObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_953_95topObjects4[i].setZOrder(12);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_953_95topObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_953_95topObjects4[i].returnVariable(gdjs.GameSceneCode.GDtower_953_95topObjects4[i].getVariables().getFromIndex(1)).setNumber((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtowerObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtowerObjects4[0].getVariables()).getFromIndex(3))));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_953_95topObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_953_95topObjects4[i].returnVariable(gdjs.GameSceneCode.GDtower_953_95topObjects4[i].getVariables().getFromIndex(0)).setNumber((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtowerObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtowerObjects4[0].getVariables()).getFromIndex(1))));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtowerObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtowerObjects4[i].setAnimationName("tower_3_grade_" + (gdjs.RuntimeObject.getVariableString(gdjs.GameSceneCode.GDtowerObjects4[i].getVariables().getFromIndex(1))));
}
}}

}


};gdjs.GameSceneCode.eventsList68 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameSceneCode.GDtowerObjects3, gdjs.GameSceneCode.GDtowerObjects4);


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) >= (gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtowerObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtowerObjects4[0].getVariables()).getFromIndex(4)));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList67(runtimeScene);} //End of subevents
}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 10));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\03-tower-placed.wav", 10, false, 100, 1);
}}

}


};gdjs.GameSceneCode.eventsList69 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameSceneCode.GDtower_95btnObjects2, gdjs.GameSceneCode.GDtower_95btnObjects3);


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
gdjs.GameSceneCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtower_95btnObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtower_95btnObjects3[i].isCurrentAnimationName("archers") ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtower_95btnObjects3[k] = gdjs.GameSceneCode.GDtower_95btnObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtower_95btnObjects3.length = k;}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtower_95btnObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtower_95btnObjects3[i].getX() != 12 ) {
        gdjs.GameSceneCode.condition1IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtower_95btnObjects3[k] = gdjs.GameSceneCode.GDtower_95btnObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtower_95btnObjects3.length = k;}if ( gdjs.GameSceneCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtower_95btnObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtower_95btnObjects3[i].getY() != 320 ) {
        gdjs.GameSceneCode.condition2IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtower_95btnObjects3[k] = gdjs.GameSceneCode.GDtower_95btnObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtower_95btnObjects3.length = k;}}
}
if (gdjs.GameSceneCode.condition2IsTrue_0.val) {
}

}


{

gdjs.copyArray(gdjs.GameSceneCode.GDtower_95btnObjects2, gdjs.GameSceneCode.GDtower_95btnObjects3);


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
gdjs.GameSceneCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtower_95btnObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtower_95btnObjects3[i].isCurrentAnimationName("wizards") ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtower_95btnObjects3[k] = gdjs.GameSceneCode.GDtower_95btnObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtower_95btnObjects3.length = k;}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtower_95btnObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtower_95btnObjects3[i].getX() != 76 ) {
        gdjs.GameSceneCode.condition1IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtower_95btnObjects3[k] = gdjs.GameSceneCode.GDtower_95btnObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtower_95btnObjects3.length = k;}if ( gdjs.GameSceneCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtower_95btnObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtower_95btnObjects3[i].getY() != 320 ) {
        gdjs.GameSceneCode.condition2IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtower_95btnObjects3[k] = gdjs.GameSceneCode.GDtower_95btnObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtower_95btnObjects3.length = k;}}
}
if (gdjs.GameSceneCode.condition2IsTrue_0.val) {
}

}


{

gdjs.copyArray(gdjs.GameSceneCode.GDtower_95btnObjects2, gdjs.GameSceneCode.GDtower_95btnObjects3);


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
gdjs.GameSceneCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtower_95btnObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtower_95btnObjects3[i].isCurrentAnimationName("melee") ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtower_95btnObjects3[k] = gdjs.GameSceneCode.GDtower_95btnObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtower_95btnObjects3.length = k;}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtower_95btnObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtower_95btnObjects3[i].getX() != 140 ) {
        gdjs.GameSceneCode.condition1IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtower_95btnObjects3[k] = gdjs.GameSceneCode.GDtower_95btnObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtower_95btnObjects3.length = k;}if ( gdjs.GameSceneCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtower_95btnObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtower_95btnObjects3[i].getY() != 320 ) {
        gdjs.GameSceneCode.condition2IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtower_95btnObjects3[k] = gdjs.GameSceneCode.GDtower_95btnObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtower_95btnObjects3.length = k;}}
}
if (gdjs.GameSceneCode.condition2IsTrue_0.val) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("tower"), gdjs.GameSceneCode.GDtowerObjects3);
gdjs.copyArray(gdjs.GameSceneCode.GDtower_95btnObjects2, gdjs.GameSceneCode.GDtower_95btnObjects3);


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
gdjs.GameSceneCode.condition2IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_9595btnObjects3Objects, gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtowerObjects3Objects, false, runtimeScene, false);
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtowerObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtowerObjects3[i].getVariableBoolean(gdjs.GameSceneCode.GDtowerObjects3[i].getVariables().getFromIndex(0), false) ) {
        gdjs.GameSceneCode.condition1IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtowerObjects3[k] = gdjs.GameSceneCode.GDtowerObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtowerObjects3.length = k;}if ( gdjs.GameSceneCode.condition1IsTrue_0.val ) {
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition2IsTrue_0;
gdjs.GameSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11785988);
}
}}
}
if (gdjs.GameSceneCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList68(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.GameSceneCode.GDtower_95btnObjects2, gdjs.GameSceneCode.GDtower_95btnObjects3);


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtower_95btnObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtower_95btnObjects3[i].isCurrentAnimationName("archers") ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtower_95btnObjects3[k] = gdjs.GameSceneCode.GDtower_95btnObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtower_95btnObjects3.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDtower_95btnObjects3 */
{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btnObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btnObjects3[i].setPosition(12,320);
}
}}

}


{

gdjs.copyArray(gdjs.GameSceneCode.GDtower_95btnObjects2, gdjs.GameSceneCode.GDtower_95btnObjects3);


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtower_95btnObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtower_95btnObjects3[i].isCurrentAnimationName("wizards") ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtower_95btnObjects3[k] = gdjs.GameSceneCode.GDtower_95btnObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtower_95btnObjects3.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDtower_95btnObjects3 */
{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btnObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btnObjects3[i].setPosition(76,320);
}
}}

}


{

/* Reuse gdjs.GameSceneCode.GDtower_95btnObjects2 */

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtower_95btnObjects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtower_95btnObjects2[i].isCurrentAnimationName("melee") ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtower_95btnObjects2[k] = gdjs.GameSceneCode.GDtower_95btnObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtower_95btnObjects2.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDtower_95btnObjects2 */
{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btnObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btnObjects2[i].setPosition(140,320);
}
}}

}


};gdjs.GameSceneCode.eventsList70 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("tower_btn"), gdjs.GameSceneCode.GDtower_95btnObjects3);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtower_95btnObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtower_95btnObjects3[i].getBehavior("Draggable").isDragged() ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtower_95btnObjects3[k] = gdjs.GameSceneCode.GDtower_95btnObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtower_95btnObjects3.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("cursor"), gdjs.GameSceneCode.GDcursorObjects3);
/* Reuse gdjs.GameSceneCode.GDtower_95btnObjects3 */
{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btnObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btnObjects3[i].setScale(1.2);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDcursorObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDcursorObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btnObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btnObjects3[i].setZOrder(50);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("tower_btn"), gdjs.GameSceneCode.GDtower_95btnObjects3);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtower_95btnObjects3.length;i<l;++i) {
    if ( !(gdjs.GameSceneCode.GDtower_95btnObjects3[i].getBehavior("Draggable").isDragged()) ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtower_95btnObjects3[k] = gdjs.GameSceneCode.GDtower_95btnObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtower_95btnObjects3.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("cursor"), gdjs.GameSceneCode.GDcursorObjects3);
/* Reuse gdjs.GameSceneCode.GDtower_95btnObjects3 */
{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btnObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btnObjects3[i].setScale(1);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDcursorObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDcursorObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btnObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btnObjects3[i].setZOrder(10);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("tower_btn"), gdjs.GameSceneCode.GDtower_95btnObjects2);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtower_95btnObjects2.length;i<l;++i) {
    if ( !(gdjs.GameSceneCode.GDtower_95btnObjects2[i].getBehavior("Draggable").isDragged()) ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtower_95btnObjects2[k] = gdjs.GameSceneCode.GDtower_95btnObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtower_95btnObjects2.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDtower_95btnObjects2 */
{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btnObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btnObjects2[i].setScale(1);
}
}
{ //Subevents
gdjs.GameSceneCode.eventsList69(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDcursorObjects3Objects = Hashtable.newFrom({"cursor": gdjs.GameSceneCode.GDcursorObjects3});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtowerObjects3Objects = Hashtable.newFrom({"tower": gdjs.GameSceneCode.GDtowerObjects3});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDcursorObjects2Objects = Hashtable.newFrom({"cursor": gdjs.GameSceneCode.GDcursorObjects2});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtowerObjects2Objects = Hashtable.newFrom({"tower": gdjs.GameSceneCode.GDtowerObjects2});gdjs.GameSceneCode.eventsList71 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameSceneCode.GDtowerObjects4, gdjs.GameSceneCode.GDtowerObjects5);


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtowerObjects5.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtowerObjects5[i].getVariableNumber(gdjs.GameSceneCode.GDtowerObjects5[i].getVariables().getFromIndex(1)) < 3 ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtowerObjects5[k] = gdjs.GameSceneCode.GDtowerObjects5[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtowerObjects5.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects3, gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects5);

gdjs.copyArray(gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3, gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects5);

{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects5[i].hide();
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects5[i].setAnimationName("archers_idle");
}
}}

}


{

/* Reuse gdjs.GameSceneCode.GDtowerObjects4 */

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtowerObjects4.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtowerObjects4[i].getVariableNumber(gdjs.GameSceneCode.GDtowerObjects4[i].getVariables().getFromIndex(1)) >= 3 ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtowerObjects4[k] = gdjs.GameSceneCode.GDtowerObjects4[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtowerObjects4.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects3, gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects4);

gdjs.copyArray(gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3, gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects4);

{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects4[i].setAnimationName("archers_disabled");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects4[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects4[i].setAnimationName("arrows_upgrade");
}
}}

}


};gdjs.GameSceneCode.eventsList72 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameSceneCode.GDtowerObjects4, gdjs.GameSceneCode.GDtowerObjects5);


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtowerObjects5.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtowerObjects5[i].getVariableNumber(gdjs.GameSceneCode.GDtowerObjects5[i].getVariables().getFromIndex(1)) < 3 ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtowerObjects5[k] = gdjs.GameSceneCode.GDtowerObjects5[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtowerObjects5.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects3, gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects5);

gdjs.copyArray(gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3, gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects5);

{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects5[i].hide();
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects5[i].setAnimationName("wizards_idle");
}
}}

}


{

/* Reuse gdjs.GameSceneCode.GDtowerObjects4 */

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtowerObjects4.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtowerObjects4[i].getVariableNumber(gdjs.GameSceneCode.GDtowerObjects4[i].getVariables().getFromIndex(1)) >= 3 ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtowerObjects4[k] = gdjs.GameSceneCode.GDtowerObjects4[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtowerObjects4.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects3, gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects4);

gdjs.copyArray(gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3, gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects4);

{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects4[i].setAnimationName("wizards_disabled");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects4[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects4[i].setAnimationName("fire_upgrade");
}
}}

}


};gdjs.GameSceneCode.eventsList73 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameSceneCode.GDtowerObjects3, gdjs.GameSceneCode.GDtowerObjects4);


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtowerObjects4.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtowerObjects4[i].getVariableNumber(gdjs.GameSceneCode.GDtowerObjects4[i].getVariables().getFromIndex(1)) < 3 ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtowerObjects4[k] = gdjs.GameSceneCode.GDtowerObjects4[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtowerObjects4.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects3, gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects4);

gdjs.copyArray(gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3, gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects4);

{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects4[i].hide();
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects4[i].setAnimationName("melee_idle");
}
}}

}


{

/* Reuse gdjs.GameSceneCode.GDtowerObjects3 */

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtowerObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtowerObjects3[i].getVariableNumber(gdjs.GameSceneCode.GDtowerObjects3[i].getVariables().getFromIndex(1)) >= 3 ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtowerObjects3[k] = gdjs.GameSceneCode.GDtowerObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtowerObjects3.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects3 */
/* Reuse gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3 */
{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3[i].setAnimationName("melee_disabled");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects3[i].setAnimationName("sword_upgrade");
}
}}

}


};gdjs.GameSceneCode.eventsList74 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameSceneCode.GDtowerObjects3, gdjs.GameSceneCode.GDtowerObjects4);


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtowerObjects4.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtowerObjects4[i].getVariableString(gdjs.GameSceneCode.GDtowerObjects4[i].getVariables().getFromIndex(7)) == "archers" ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtowerObjects4[k] = gdjs.GameSceneCode.GDtowerObjects4[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtowerObjects4.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.GameSceneCode.GDtower_95btn_95sellObjects3, gdjs.GameSceneCode.GDtower_95btn_95sellObjects4);

{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95sellObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95sellObjects4[i].setAnimationName("archers_sell");
}
}
{ //Subevents
gdjs.GameSceneCode.eventsList71(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.GameSceneCode.GDtowerObjects3, gdjs.GameSceneCode.GDtowerObjects4);


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtowerObjects4.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtowerObjects4[i].getVariableString(gdjs.GameSceneCode.GDtowerObjects4[i].getVariables().getFromIndex(7)) == "wizards" ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtowerObjects4[k] = gdjs.GameSceneCode.GDtowerObjects4[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtowerObjects4.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.GameSceneCode.GDtower_95btn_95sellObjects3, gdjs.GameSceneCode.GDtower_95btn_95sellObjects4);

{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95sellObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95sellObjects4[i].setAnimationName("wizards_sell");
}
}
{ //Subevents
gdjs.GameSceneCode.eventsList72(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.GameSceneCode.GDtowerObjects3 */

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtowerObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtowerObjects3[i].getVariableString(gdjs.GameSceneCode.GDtowerObjects3[i].getVariables().getFromIndex(7)) == "melee" ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtowerObjects3[k] = gdjs.GameSceneCode.GDtowerObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtowerObjects3.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDtower_95btn_95sellObjects3 */
{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95sellObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95sellObjects3[i].setAnimationName("melee_sell");
}
}
{ //Subevents
gdjs.GameSceneCode.eventsList73(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList75 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameSceneCode.GDcursorObjects2, gdjs.GameSceneCode.GDcursorObjects3);

gdjs.copyArray(gdjs.GameSceneCode.GDtowerObjects2, gdjs.GameSceneCode.GDtowerObjects3);


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtowerObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtowerObjects3[i].getVariableBoolean(gdjs.GameSceneCode.GDtowerObjects3[i].getVariables().getFromIndex(2), true) ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtowerObjects3[k] = gdjs.GameSceneCode.GDtowerObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtowerObjects3.length = k;}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDcursorObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDcursorObjects3[i].getVariableNumber(gdjs.GameSceneCode.GDcursorObjects3[i].getVariables().getFromIndex(0)) == (gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtowerObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtowerObjects3[0].getVariables()).getFromIndex(3))) ) {
        gdjs.GameSceneCode.condition1IsTrue_0.val = true;
        gdjs.GameSceneCode.GDcursorObjects3[k] = gdjs.GameSceneCode.GDcursorObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDcursorObjects3.length = k;}}
if (gdjs.GameSceneCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDtowerObjects3 */
gdjs.copyArray(runtimeScene.getObjects("tower_btn_bullets"), gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects3);
gdjs.copyArray(runtimeScene.getObjects("tower_btn_sell"), gdjs.GameSceneCode.GDtower_95btn_95sellObjects3);
gdjs.copyArray(runtimeScene.getObjects("tower_btn_upgrade"), gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3);
gdjs.copyArray(runtimeScene.getObjects("tower_panel"), gdjs.GameSceneCode.GDtower_95panelObjects3);
gdjs.copyArray(runtimeScene.getObjects("tower_selected"), gdjs.GameSceneCode.GDtower_95selectedObjects3);
{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3[i].returnVariable(gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3[i].getVariables().getFromIndex(0)).setNumber((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtowerObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtowerObjects3[0].getVariables()).getFromIndex(3))));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95sellObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95sellObjects3[i].returnVariable(gdjs.GameSceneCode.GDtower_95btn_95sellObjects3[i].getVariables().getFromIndex(0)).setNumber((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtowerObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtowerObjects3[0].getVariables()).getFromIndex(3))));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects3[i].returnVariable(gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects3[i].getVariables().getFromIndex(0)).setNumber((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtowerObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtowerObjects3[0].getVariables()).getFromIndex(3))));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95selectedObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95selectedObjects3[i].setPosition((( gdjs.GameSceneCode.GDtowerObjects3.length === 0 ) ? 0 :gdjs.GameSceneCode.GDtowerObjects3[0].getPointX("")),(( gdjs.GameSceneCode.GDtowerObjects3.length === 0 ) ? 0 :gdjs.GameSceneCode.GDtowerObjects3[0].getPointY("")) - 16);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95panelObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95panelObjects3[i].setPosition((( gdjs.GameSceneCode.GDtowerObjects3.length === 0 ) ? 0 :gdjs.GameSceneCode.GDtowerObjects3[0].getPointX("panel")),(( gdjs.GameSceneCode.GDtowerObjects3.length === 0 ) ? 0 :gdjs.GameSceneCode.GDtowerObjects3[0].getPointY("panel")));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95selectedObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95selectedObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95panelObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95panelObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95sellObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95sellObjects3[i].hide(false);
}
}
{ //Subevents
gdjs.GameSceneCode.eventsList74(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.GameSceneCode.GDtowerObjects2, gdjs.GameSceneCode.GDtowerObjects3);


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtowerObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtowerObjects3[i].getVariableBoolean(gdjs.GameSceneCode.GDtowerObjects3[i].getVariables().getFromIndex(2), false) ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtowerObjects3[k] = gdjs.GameSceneCode.GDtowerObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtowerObjects3.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("tower_btn_bullets"), gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects3);
gdjs.copyArray(runtimeScene.getObjects("tower_btn_sell"), gdjs.GameSceneCode.GDtower_95btn_95sellObjects3);
gdjs.copyArray(runtimeScene.getObjects("tower_btn_upgrade"), gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3);
gdjs.copyArray(runtimeScene.getObjects("tower_panel"), gdjs.GameSceneCode.GDtower_95panelObjects3);
{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95panelObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95panelObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3[i].returnVariable(gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3[i].getVariables().getFromIndex(0)).setNumber(0);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95sellObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95sellObjects3[i].returnVariable(gdjs.GameSceneCode.GDtower_95btn_95sellObjects3[i].getVariables().getFromIndex(0)).setNumber(0);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects3[i].returnVariable(gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects3[i].getVariables().getFromIndex(0)).setNumber(0);
}
}}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 2));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\191756__leszek-szary__button-9.wav", 2, false, 100, 1);
}}

}


};gdjs.GameSceneCode.eventsList76 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("cursor"), gdjs.GameSceneCode.GDcursorObjects3);
gdjs.copyArray(runtimeScene.getObjects("tower"), gdjs.GameSceneCode.GDtowerObjects3);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDcursorObjects3Objects, gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtowerObjects3Objects, false, runtimeScene, false);
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDcursorObjects3 */
/* Reuse gdjs.GameSceneCode.GDtowerObjects3 */
{for(var i = 0, len = gdjs.GameSceneCode.GDcursorObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDcursorObjects3[i].returnVariable(gdjs.GameSceneCode.GDcursorObjects3[i].getVariables().getFromIndex(0)).setNumber((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtowerObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtowerObjects3[0].getVariables()).getFromIndex(3))));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("cursor"), gdjs.GameSceneCode.GDcursorObjects2);
gdjs.copyArray(runtimeScene.getObjects("tower"), gdjs.GameSceneCode.GDtowerObjects2);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
gdjs.GameSceneCode.condition2IsTrue_0.val = false;
gdjs.GameSceneCode.condition3IsTrue_0.val = false;
gdjs.GameSceneCode.condition4IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Right");
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDcursorObjects2Objects, gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtowerObjects2Objects, false, runtimeScene, false);
}if ( gdjs.GameSceneCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtowerObjects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtowerObjects2[i].getVariableBoolean(gdjs.GameSceneCode.GDtowerObjects2[i].getVariables().getFromIndex(0), true) ) {
        gdjs.GameSceneCode.condition2IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtowerObjects2[k] = gdjs.GameSceneCode.GDtowerObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtowerObjects2.length = k;}if ( gdjs.GameSceneCode.condition2IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtowerObjects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtowerObjects2[i].getVariableBoolean(gdjs.GameSceneCode.GDtowerObjects2[i].getVariables().getFromIndex(5), false) ) {
        gdjs.GameSceneCode.condition3IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtowerObjects2[k] = gdjs.GameSceneCode.GDtowerObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtowerObjects2.length = k;}if ( gdjs.GameSceneCode.condition3IsTrue_0.val ) {
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition4IsTrue_0;
gdjs.GameSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11800460);
}
}}
}
}
}
if (gdjs.GameSceneCode.condition4IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDcursorObjects2 */
/* Reuse gdjs.GameSceneCode.GDtowerObjects2 */
{for(var i = 0, len = gdjs.GameSceneCode.GDtowerObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtowerObjects2[i].toggleVariableBoolean(gdjs.GameSceneCode.GDtowerObjects2[i].getVariables().getFromIndex(2));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDcursorObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDcursorObjects2[i].returnVariable(gdjs.GameSceneCode.GDcursorObjects2[i].getVariables().getFromIndex(0)).setNumber((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtowerObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtowerObjects2[0].getVariables()).getFromIndex(3))));
}
}
{ //Subevents
gdjs.GameSceneCode.eventsList75(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_9595btn_9595upgradeObjects2Objects = Hashtable.newFrom({"tower_btn_upgrade": gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects2});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDupgrade_9595barObjects5Objects = Hashtable.newFrom({"upgrade_bar": gdjs.GameSceneCode.GDupgrade_95barObjects5});gdjs.GameSceneCode.eventsList77 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameSceneCode.GDtowerObjects4, gdjs.GameSceneCode.GDtowerObjects5);

gdjs.copyArray(gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects2, gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects5);


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects5.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects5[i].getVariableNumber(gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects5[i].getVariables().getFromIndex(0)) == (gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtowerObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtowerObjects5[0].getVariables()).getFromIndex(3))) ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects5[k] = gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects5[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects5.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDtowerObjects5 */
/* Reuse gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects5 */
gdjs.copyArray(runtimeScene.getObjects("tower_panel"), gdjs.GameSceneCode.GDtower_95panelObjects5);
gdjs.GameSceneCode.GDupgrade_95barObjects5.length = 0;

{runtimeScene.getVariables().getFromIndex(0).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtowerObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtowerObjects5[0].getVariables()).getFromIndex(4))));
}{for(var i = 0, len = gdjs.GameSceneCode.GDtowerObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtowerObjects5[i].setVariableBoolean(gdjs.GameSceneCode.GDtowerObjects5[i].getVariables().getFromIndex(5), true);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtowerObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtowerObjects5[i].resetTimer("upgrading");
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDupgrade_9595barObjects5Objects, (( gdjs.GameSceneCode.GDtowerObjects5.length === 0 ) ? 0 :gdjs.GameSceneCode.GDtowerObjects5[0].getPointX("")) - (( gdjs.GameSceneCode.GDtowerObjects5.length === 0 ) ? 0 :gdjs.GameSceneCode.GDtowerObjects5[0].getWidth()) / 3, (( gdjs.GameSceneCode.GDtowerObjects5.length === 0 ) ? 0 :gdjs.GameSceneCode.GDtowerObjects5[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.GameSceneCode.GDupgrade_95barObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDupgrade_95barObjects5[i].returnVariable(gdjs.GameSceneCode.GDupgrade_95barObjects5[i].getVariables().getFromIndex(0)).setNumber((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtowerObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtowerObjects5[0].getVariables()).getFromIndex(3))));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects5[i].returnVariable(gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects5[i].getVariables().getFromIndex(0)).setNumber(0);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95panelObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95panelObjects5[i].hide();
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtowerObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtowerObjects5[i].setVariableBoolean(gdjs.GameSceneCode.GDtowerObjects5[i].getVariables().getFromIndex(2), false);
}
}}

}


};gdjs.GameSceneCode.eventsList78 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 2));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\191756__leszek-szary__button-9.wav", 2, false, 100, 1);
}}

}


{

gdjs.copyArray(gdjs.GameSceneCode.GDtowerObjects2, gdjs.GameSceneCode.GDtowerObjects3);


for(gdjs.GameSceneCode.forEachIndex4 = 0;gdjs.GameSceneCode.forEachIndex4 < gdjs.GameSceneCode.GDtowerObjects3.length;++gdjs.GameSceneCode.forEachIndex4) {
gdjs.GameSceneCode.GDtowerObjects4.length = 0;


gdjs.GameSceneCode.forEachTemporary4 = gdjs.GameSceneCode.GDtowerObjects3[gdjs.GameSceneCode.forEachIndex4];
gdjs.GameSceneCode.GDtowerObjects4.push(gdjs.GameSceneCode.forEachTemporary4);
if (true) {

{ //Subevents: 
gdjs.GameSceneCode.eventsList77(runtimeScene);} //Subevents end.
}
}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 100));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\upgrade-started-male-6.wav", 100, false, 100, 1);
}}

}


};gdjs.GameSceneCode.eventsList79 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition0IsTrue_0;
gdjs.GameSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11818932);
}
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList78(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList80 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("tower"), gdjs.GameSceneCode.GDtowerObjects2);
gdjs.copyArray(runtimeScene.getObjects("tower_btn_upgrade"), gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects2);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
gdjs.GameSceneCode.condition2IsTrue_0.val = false;
gdjs.GameSceneCode.condition3IsTrue_0.val = false;
gdjs.GameSceneCode.condition4IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_9595btn_9595upgradeObjects2Objects, runtimeScene, true, false);
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.GameSceneCode.condition1IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition2IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) >= (gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtowerObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtowerObjects2[0].getVariables()).getFromIndex(4)));
}if ( gdjs.GameSceneCode.condition2IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtowerObjects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtowerObjects2[i].getVariableBoolean(gdjs.GameSceneCode.GDtowerObjects2[i].getVariables().getFromIndex(5), false) ) {
        gdjs.GameSceneCode.condition3IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtowerObjects2[k] = gdjs.GameSceneCode.GDtowerObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtowerObjects2.length = k;}if ( gdjs.GameSceneCode.condition3IsTrue_0.val ) {
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition4IsTrue_0;
gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects2_1final.length = 0;gdjs.GameSceneCode.condition0IsTrue_1.val = false;
gdjs.GameSceneCode.condition1IsTrue_1.val = false;
gdjs.GameSceneCode.condition2IsTrue_1.val = false;
{
gdjs.copyArray(gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects2, gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3);

for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3[i].isCurrentAnimationName("archers_idle") ) {
        gdjs.GameSceneCode.condition0IsTrue_1.val = true;
        gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3[k] = gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3.length = k;if( gdjs.GameSceneCode.condition0IsTrue_1.val ) {
    gdjs.GameSceneCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3.length;j<jLen;++j) {
        if ( gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects2_1final.indexOf(gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3[j]) === -1 )
            gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects2_1final.push(gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects2, gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3);

for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3[i].isCurrentAnimationName("wizards_idle") ) {
        gdjs.GameSceneCode.condition1IsTrue_1.val = true;
        gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3[k] = gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3.length = k;if( gdjs.GameSceneCode.condition1IsTrue_1.val ) {
    gdjs.GameSceneCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3.length;j<jLen;++j) {
        if ( gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects2_1final.indexOf(gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3[j]) === -1 )
            gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects2_1final.push(gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects2, gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3);

for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3[i].isCurrentAnimationName("melee_idle") ) {
        gdjs.GameSceneCode.condition2IsTrue_1.val = true;
        gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3[k] = gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3.length = k;if( gdjs.GameSceneCode.condition2IsTrue_1.val ) {
    gdjs.GameSceneCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3.length;j<jLen;++j) {
        if ( gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects2_1final.indexOf(gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3[j]) === -1 )
            gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects2_1final.push(gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects2_1final, gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects2);
}
}
}}
}
}
}
if (gdjs.GameSceneCode.condition4IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList79(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_9595btn_9595bulletsObjects2Objects = Hashtable.newFrom({"tower_btn_bullets": gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects2});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95951_9595topObjects6Objects = Hashtable.newFrom({"tower_1_top": gdjs.GameSceneCode.GDtower_951_95topObjects6});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95952_9595topObjects6Objects = Hashtable.newFrom({"tower_2_top": gdjs.GameSceneCode.GDtower_952_95topObjects6});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95953_9595topObjects5Objects = Hashtable.newFrom({"tower_3_top": gdjs.GameSceneCode.GDtower_953_95topObjects5});gdjs.GameSceneCode.eventsList81 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameSceneCode.GDtowerObjects5, gdjs.GameSceneCode.GDtowerObjects6);

gdjs.copyArray(runtimeScene.getObjects("tower_1_top"), gdjs.GameSceneCode.GDtower_951_95topObjects6);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95951_9595topObjects6Objects, (gdjs.GameSceneCode.GDtowerObjects6.length !== 0 ? gdjs.GameSceneCode.GDtowerObjects6[0] : null));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDtower_951_95topObjects6 */
{for(var i = 0, len = gdjs.GameSceneCode.GDtower_951_95topObjects6.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_951_95topObjects6[i].returnVariable(gdjs.GameSceneCode.GDtower_951_95topObjects6[i].getVariables().getFromIndex(2)).add(1);
}
}}

}


{

gdjs.copyArray(gdjs.GameSceneCode.GDtowerObjects5, gdjs.GameSceneCode.GDtowerObjects6);

gdjs.copyArray(runtimeScene.getObjects("tower_2_top"), gdjs.GameSceneCode.GDtower_952_95topObjects6);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95952_9595topObjects6Objects, (gdjs.GameSceneCode.GDtowerObjects6.length !== 0 ? gdjs.GameSceneCode.GDtowerObjects6[0] : null));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDtower_952_95topObjects6 */
{for(var i = 0, len = gdjs.GameSceneCode.GDtower_952_95topObjects6.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_952_95topObjects6[i].returnVariable(gdjs.GameSceneCode.GDtower_952_95topObjects6[i].getVariables().getFromIndex(2)).add(1);
}
}}

}


{

/* Reuse gdjs.GameSceneCode.GDtowerObjects5 */
gdjs.copyArray(runtimeScene.getObjects("tower_3_top"), gdjs.GameSceneCode.GDtower_953_95topObjects5);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95953_9595topObjects5Objects, (gdjs.GameSceneCode.GDtowerObjects5.length !== 0 ? gdjs.GameSceneCode.GDtowerObjects5[0] : null));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDtower_953_95topObjects5 */
{for(var i = 0, len = gdjs.GameSceneCode.GDtower_953_95topObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_953_95topObjects5[i].returnVariable(gdjs.GameSceneCode.GDtower_953_95topObjects5[i].getVariables().getFromIndex(4)).add(1);
}
}}

}


};gdjs.GameSceneCode.eventsList82 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameSceneCode.GDtowerObjects4, gdjs.GameSceneCode.GDtowerObjects5);

gdjs.copyArray(gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects2, gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects5);


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects5.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects5[i].getVariableNumber(gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects5[i].getVariables().getFromIndex(0)) == (gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtowerObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtowerObjects5[0].getVariables()).getFromIndex(3))) ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects5[k] = gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects5[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects5.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDtowerObjects5 */
/* Reuse gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects5 */
gdjs.copyArray(runtimeScene.getObjects("tower_panel"), gdjs.GameSceneCode.GDtower_95panelObjects5);
{runtimeScene.getVariables().getFromIndex(0).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtowerObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtowerObjects5[0].getVariables()).get("arrows_price"))));
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects5[i].returnVariable(gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects5[i].getVariables().getFromIndex(0)).setNumber(0);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95panelObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95panelObjects5[i].hide();
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtowerObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtowerObjects5[i].setVariableBoolean(gdjs.GameSceneCode.GDtowerObjects5[i].getVariables().getFromIndex(2), false);
}
}
{ //Subevents
gdjs.GameSceneCode.eventsList81(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList83 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 2));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\191756__leszek-szary__button-9.wav", 2, false, 100, 1);
}}

}


{

gdjs.copyArray(gdjs.GameSceneCode.GDtowerObjects2, gdjs.GameSceneCode.GDtowerObjects3);


for(gdjs.GameSceneCode.forEachIndex4 = 0;gdjs.GameSceneCode.forEachIndex4 < gdjs.GameSceneCode.GDtowerObjects3.length;++gdjs.GameSceneCode.forEachIndex4) {
gdjs.GameSceneCode.GDtowerObjects4.length = 0;


gdjs.GameSceneCode.forEachTemporary4 = gdjs.GameSceneCode.GDtowerObjects3[gdjs.GameSceneCode.forEachIndex4];
gdjs.GameSceneCode.GDtowerObjects4.push(gdjs.GameSceneCode.forEachTemporary4);
if (true) {

{ //Subevents: 
gdjs.GameSceneCode.eventsList82(runtimeScene);} //Subevents end.
}
}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 102));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\upgraded-male-6.wav", 102, false, 100, 1);
}}

}


};gdjs.GameSceneCode.eventsList84 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition0IsTrue_0;
gdjs.GameSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11825412);
}
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList83(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList85 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("tower"), gdjs.GameSceneCode.GDtowerObjects2);
gdjs.copyArray(runtimeScene.getObjects("tower_btn_bullets"), gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects2);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
gdjs.GameSceneCode.condition2IsTrue_0.val = false;
gdjs.GameSceneCode.condition3IsTrue_0.val = false;
gdjs.GameSceneCode.condition4IsTrue_0.val = false;
gdjs.GameSceneCode.condition5IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_9595btn_9595bulletsObjects2Objects, runtimeScene, true, false);
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.GameSceneCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects2[i].isVisible() ) {
        gdjs.GameSceneCode.condition2IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects2[k] = gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects2.length = k;}if ( gdjs.GameSceneCode.condition2IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition3IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) >= (gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtowerObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtowerObjects2[0].getVariables()).get("arrows_price")));
}if ( gdjs.GameSceneCode.condition3IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtowerObjects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtowerObjects2[i].getVariableBoolean(gdjs.GameSceneCode.GDtowerObjects2[i].getVariables().getFromIndex(5), false) ) {
        gdjs.GameSceneCode.condition4IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtowerObjects2[k] = gdjs.GameSceneCode.GDtowerObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtowerObjects2.length = k;}if ( gdjs.GameSceneCode.condition4IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtowerObjects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtowerObjects2[i].getVariableNumber(gdjs.GameSceneCode.GDtowerObjects2[i].getVariables().getFromIndex(1)) == 3 ) {
        gdjs.GameSceneCode.condition5IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtowerObjects2[k] = gdjs.GameSceneCode.GDtowerObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtowerObjects2.length = k;}}
}
}
}
}
if (gdjs.GameSceneCode.condition5IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList84(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_9595btn_9595sellObjects2Objects = Hashtable.newFrom({"tower_btn_sell": gdjs.GameSceneCode.GDtower_95btn_95sellObjects2});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95951_9595topObjects5Objects = Hashtable.newFrom({"tower_1_top": gdjs.GameSceneCode.GDtower_951_95topObjects5});gdjs.GameSceneCode.eventsList86 = function(runtimeScene) {

{

/* Reuse gdjs.GameSceneCode.GDtowerObjects5 */
gdjs.copyArray(runtimeScene.getObjects("tower_1_top"), gdjs.GameSceneCode.GDtower_951_95topObjects5);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95951_9595topObjects5Objects, (gdjs.GameSceneCode.GDtowerObjects5.length !== 0 ? gdjs.GameSceneCode.GDtowerObjects5[0] : null));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDtower_951_95topObjects5 */
{for(var i = 0, len = gdjs.GameSceneCode.GDtower_951_95topObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_951_95topObjects5[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95952_9595topObjects5Objects = Hashtable.newFrom({"tower_2_top": gdjs.GameSceneCode.GDtower_952_95topObjects5});gdjs.GameSceneCode.eventsList87 = function(runtimeScene) {

{

/* Reuse gdjs.GameSceneCode.GDtowerObjects5 */
gdjs.copyArray(runtimeScene.getObjects("tower_2_top"), gdjs.GameSceneCode.GDtower_952_95topObjects5);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95952_9595topObjects5Objects, (gdjs.GameSceneCode.GDtowerObjects5.length !== 0 ? gdjs.GameSceneCode.GDtowerObjects5[0] : null));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDtower_952_95topObjects5 */
{for(var i = 0, len = gdjs.GameSceneCode.GDtower_952_95topObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_952_95topObjects5[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95953_9595topObjects5Objects = Hashtable.newFrom({"tower_3_top": gdjs.GameSceneCode.GDtower_953_95topObjects5});gdjs.GameSceneCode.eventsList88 = function(runtimeScene) {

{

/* Reuse gdjs.GameSceneCode.GDtowerObjects5 */
gdjs.copyArray(runtimeScene.getObjects("tower_3_top"), gdjs.GameSceneCode.GDtower_953_95topObjects5);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95953_9595topObjects5Objects, (gdjs.GameSceneCode.GDtowerObjects5.length !== 0 ? gdjs.GameSceneCode.GDtowerObjects5[0] : null));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDtower_953_95topObjects5 */
{for(var i = 0, len = gdjs.GameSceneCode.GDtower_953_95topObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_953_95topObjects5[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.GameSceneCode.eventsList89 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameSceneCode.GDtowerObjects4, gdjs.GameSceneCode.GDtowerObjects5);


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtowerObjects5.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtowerObjects5[i].getVariableString(gdjs.GameSceneCode.GDtowerObjects5[i].getVariables().getFromIndex(7)) == "archers" ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtowerObjects5[k] = gdjs.GameSceneCode.GDtowerObjects5[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtowerObjects5.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDtowerObjects5 */
{for(var i = 0, len = gdjs.GameSceneCode.GDtowerObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtowerObjects5[i].setAnimationName("archers");
}
}
{ //Subevents
gdjs.GameSceneCode.eventsList86(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.GameSceneCode.GDtowerObjects4, gdjs.GameSceneCode.GDtowerObjects5);


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtowerObjects5.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtowerObjects5[i].getVariableString(gdjs.GameSceneCode.GDtowerObjects5[i].getVariables().getFromIndex(7)) == "wizards" ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtowerObjects5[k] = gdjs.GameSceneCode.GDtowerObjects5[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtowerObjects5.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDtowerObjects5 */
{for(var i = 0, len = gdjs.GameSceneCode.GDtowerObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtowerObjects5[i].setAnimationName("wizards");
}
}
{ //Subevents
gdjs.GameSceneCode.eventsList87(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.GameSceneCode.GDtowerObjects4, gdjs.GameSceneCode.GDtowerObjects5);


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtowerObjects5.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtowerObjects5[i].getVariableString(gdjs.GameSceneCode.GDtowerObjects5[i].getVariables().getFromIndex(7)) == "melee" ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtowerObjects5[k] = gdjs.GameSceneCode.GDtowerObjects5[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtowerObjects5.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDtowerObjects5 */
{for(var i = 0, len = gdjs.GameSceneCode.GDtowerObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtowerObjects5[i].setAnimationName("melee");
}
}
{ //Subevents
gdjs.GameSceneCode.eventsList88(runtimeScene);} //End of subevents
}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 10));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\184438__capslok__cash-register-fake.wav", 10, false, 100, 1);
}}

}


};gdjs.GameSceneCode.eventsList90 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameSceneCode.GDtowerObjects3, gdjs.GameSceneCode.GDtowerObjects4);

gdjs.copyArray(gdjs.GameSceneCode.GDtower_95btn_95sellObjects2, gdjs.GameSceneCode.GDtower_95btn_95sellObjects4);


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtower_95btn_95sellObjects4.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtower_95btn_95sellObjects4[i].getVariableNumber(gdjs.GameSceneCode.GDtower_95btn_95sellObjects4[i].getVariables().getFromIndex(0)) == (gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtowerObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtowerObjects4[0].getVariables()).getFromIndex(3))) ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtower_95btn_95sellObjects4[k] = gdjs.GameSceneCode.GDtower_95btn_95sellObjects4[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtower_95btn_95sellObjects4.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDtowerObjects4 */
gdjs.copyArray(runtimeScene.getObjects("tower_btn_bullets"), gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects4);
/* Reuse gdjs.GameSceneCode.GDtower_95btn_95sellObjects4 */
gdjs.copyArray(runtimeScene.getObjects("tower_btn_upgrade"), gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects4);
gdjs.copyArray(runtimeScene.getObjects("tower_panel"), gdjs.GameSceneCode.GDtower_95panelObjects4);
gdjs.copyArray(runtimeScene.getObjects("tower_selected"), gdjs.GameSceneCode.GDtower_95selectedObjects4);
{runtimeScene.getVariables().getFromIndex(0).add((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtowerObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtowerObjects4[0].getVariables()).getFromIndex(4))) / 2);
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects4[i].hide();
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects4[i].hide();
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95btn_95sellObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95btn_95sellObjects4[i].hide();
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95selectedObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95selectedObjects4[i].hide();
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_95panelObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_95panelObjects4[i].hide();
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtowerObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtowerObjects4[i].setVariableBoolean(gdjs.GameSceneCode.GDtowerObjects4[i].getVariables().getFromIndex(0), false);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtowerObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtowerObjects4[i].returnVariable(gdjs.GameSceneCode.GDtowerObjects4[i].getVariables().getFromIndex(1)).setNumber(1);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtowerObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtowerObjects4[i].setVariableBoolean(gdjs.GameSceneCode.GDtowerObjects4[i].getVariables().getFromIndex(2), false);
}
}
{ //Subevents
gdjs.GameSceneCode.eventsList89(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList91 = function(runtimeScene) {

{

/* Reuse gdjs.GameSceneCode.GDtowerObjects2 */

for(gdjs.GameSceneCode.forEachIndex3 = 0;gdjs.GameSceneCode.forEachIndex3 < gdjs.GameSceneCode.GDtowerObjects2.length;++gdjs.GameSceneCode.forEachIndex3) {
gdjs.GameSceneCode.GDtowerObjects3.length = 0;


gdjs.GameSceneCode.forEachTemporary3 = gdjs.GameSceneCode.GDtowerObjects2[gdjs.GameSceneCode.forEachIndex3];
gdjs.GameSceneCode.GDtowerObjects3.push(gdjs.GameSceneCode.forEachTemporary3);
if (true) {

{ //Subevents: 
gdjs.GameSceneCode.eventsList90(runtimeScene);} //Subevents end.
}
}

}


};gdjs.GameSceneCode.eventsList92 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition0IsTrue_0;
gdjs.GameSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11832804);
}
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList91(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList93 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("tower"), gdjs.GameSceneCode.GDtowerObjects2);
gdjs.copyArray(runtimeScene.getObjects("tower_btn_sell"), gdjs.GameSceneCode.GDtower_95btn_95sellObjects2);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
gdjs.GameSceneCode.condition2IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_9595btn_9595sellObjects2Objects, runtimeScene, true, false);
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.GameSceneCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtowerObjects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtowerObjects2[i].getVariableBoolean(gdjs.GameSceneCode.GDtowerObjects2[i].getVariables().getFromIndex(5), false) ) {
        gdjs.GameSceneCode.condition2IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtowerObjects2[k] = gdjs.GameSceneCode.GDtowerObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtowerObjects2.length = k;}}
}
if (gdjs.GameSceneCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList92(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95951_9595topObjects5Objects = Hashtable.newFrom({"tower_1_top": gdjs.GameSceneCode.GDtower_951_95topObjects5});gdjs.GameSceneCode.eventsList94 = function(runtimeScene) {

{

/* Reuse gdjs.GameSceneCode.GDtowerObjects5 */
gdjs.copyArray(runtimeScene.getObjects("tower_1_top"), gdjs.GameSceneCode.GDtower_951_95topObjects5);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95951_9595topObjects5Objects, (gdjs.GameSceneCode.GDtowerObjects5.length !== 0 ? gdjs.GameSceneCode.GDtowerObjects5[0] : null));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDtower_951_95topObjects5 */
{for(var i = 0, len = gdjs.GameSceneCode.GDtower_951_95topObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_951_95topObjects5[i].returnVariable(gdjs.GameSceneCode.GDtower_951_95topObjects5[i].getVariables().getFromIndex(0)).add(1);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_951_95topObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_951_95topObjects5[i].returnVariable(gdjs.GameSceneCode.GDtower_951_95topObjects5[i].getVariables().getFromIndex(2)).add(1);
}
}}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95952_9595topObjects5Objects = Hashtable.newFrom({"tower_2_top": gdjs.GameSceneCode.GDtower_952_95topObjects5});gdjs.GameSceneCode.eventsList95 = function(runtimeScene) {

{

/* Reuse gdjs.GameSceneCode.GDtowerObjects5 */
gdjs.copyArray(runtimeScene.getObjects("tower_2_top"), gdjs.GameSceneCode.GDtower_952_95topObjects5);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95952_9595topObjects5Objects, (gdjs.GameSceneCode.GDtowerObjects5.length !== 0 ? gdjs.GameSceneCode.GDtowerObjects5[0] : null));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDtower_952_95topObjects5 */
{for(var i = 0, len = gdjs.GameSceneCode.GDtower_952_95topObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_952_95topObjects5[i].returnVariable(gdjs.GameSceneCode.GDtower_952_95topObjects5[i].getVariables().getFromIndex(0)).add(1);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_952_95topObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_952_95topObjects5[i].returnVariable(gdjs.GameSceneCode.GDtower_952_95topObjects5[i].getVariables().getFromIndex(2)).add(1);
}
}}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95953_9595topObjects5Objects = Hashtable.newFrom({"tower_3_top": gdjs.GameSceneCode.GDtower_953_95topObjects5});gdjs.GameSceneCode.eventsList96 = function(runtimeScene) {

{

/* Reuse gdjs.GameSceneCode.GDtowerObjects5 */
gdjs.copyArray(runtimeScene.getObjects("tower_3_top"), gdjs.GameSceneCode.GDtower_953_95topObjects5);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95953_9595topObjects5Objects, (gdjs.GameSceneCode.GDtowerObjects5.length !== 0 ? gdjs.GameSceneCode.GDtowerObjects5[0] : null));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDtower_953_95topObjects5 */
{for(var i = 0, len = gdjs.GameSceneCode.GDtower_953_95topObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_953_95topObjects5[i].returnVariable(gdjs.GameSceneCode.GDtower_953_95topObjects5[i].getVariables().getFromIndex(0)).add(1);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_953_95topObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_953_95topObjects5[i].returnVariable(gdjs.GameSceneCode.GDtower_953_95topObjects5[i].getVariables().getFromIndex(4)).add(1);
}
}}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDlevelupObjects4Objects = Hashtable.newFrom({"levelup": gdjs.GameSceneCode.GDlevelupObjects4});gdjs.GameSceneCode.eventsList97 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameSceneCode.GDtowerObjects4, gdjs.GameSceneCode.GDtowerObjects5);


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtowerObjects5.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtowerObjects5[i].getVariableString(gdjs.GameSceneCode.GDtowerObjects5[i].getVariables().getFromIndex(7)) == "archers" ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtowerObjects5[k] = gdjs.GameSceneCode.GDtowerObjects5[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtowerObjects5.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDtowerObjects5 */
{for(var i = 0, len = gdjs.GameSceneCode.GDtowerObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtowerObjects5[i].setAnimationName("tower_1_grade_" + (gdjs.RuntimeObject.getVariableString(gdjs.GameSceneCode.GDtowerObjects5[i].getVariables().getFromIndex(1))));
}
}
{ //Subevents
gdjs.GameSceneCode.eventsList94(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.GameSceneCode.GDtowerObjects4, gdjs.GameSceneCode.GDtowerObjects5);


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtowerObjects5.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtowerObjects5[i].getVariableString(gdjs.GameSceneCode.GDtowerObjects5[i].getVariables().getFromIndex(7)) == "wizards" ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtowerObjects5[k] = gdjs.GameSceneCode.GDtowerObjects5[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtowerObjects5.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDtowerObjects5 */
{for(var i = 0, len = gdjs.GameSceneCode.GDtowerObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtowerObjects5[i].setAnimationName("tower_2_grade_" + (gdjs.RuntimeObject.getVariableString(gdjs.GameSceneCode.GDtowerObjects5[i].getVariables().getFromIndex(1))));
}
}
{ //Subevents
gdjs.GameSceneCode.eventsList95(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.GameSceneCode.GDtowerObjects4, gdjs.GameSceneCode.GDtowerObjects5);


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtowerObjects5.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtowerObjects5[i].getVariableString(gdjs.GameSceneCode.GDtowerObjects5[i].getVariables().getFromIndex(7)) == "melee" ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtowerObjects5[k] = gdjs.GameSceneCode.GDtowerObjects5[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtowerObjects5.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDtowerObjects5 */
{for(var i = 0, len = gdjs.GameSceneCode.GDtowerObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtowerObjects5[i].setAnimationName("tower_3_grade_" + (gdjs.RuntimeObject.getVariableString(gdjs.GameSceneCode.GDtowerObjects5[i].getVariables().getFromIndex(1))));
}
}
{ //Subevents
gdjs.GameSceneCode.eventsList96(runtimeScene);} //End of subevents
}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 4));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\475889_level_up.wav", 4, false, 100, 1);
}}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 111));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\upgrade-completed-male-6.wav", 111, false, 100, 1);
}}

}


{


{
/* Reuse gdjs.GameSceneCode.GDtowerObjects4 */
gdjs.GameSceneCode.GDlevelupObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDlevelupObjects4Objects, (( gdjs.GameSceneCode.GDtowerObjects4.length === 0 ) ? 0 :gdjs.GameSceneCode.GDtowerObjects4[0].getPointX("")), (( gdjs.GameSceneCode.GDtowerObjects4.length === 0 ) ? 0 :gdjs.GameSceneCode.GDtowerObjects4[0].getPointY("")), "");
}}

}


};gdjs.GameSceneCode.eventsList98 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameSceneCode.GDtowerObjects3, gdjs.GameSceneCode.GDtowerObjects4);

gdjs.copyArray(runtimeScene.getObjects("upgrade_bar"), gdjs.GameSceneCode.GDupgrade_95barObjects4);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
gdjs.GameSceneCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtowerObjects4.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtowerObjects4[i].getVariableBoolean(gdjs.GameSceneCode.GDtowerObjects4[i].getVariables().getFromIndex(5), true) ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtowerObjects4[k] = gdjs.GameSceneCode.GDtowerObjects4[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtowerObjects4.length = k;}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDupgrade_95barObjects4.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDupgrade_95barObjects4[i].getVariableNumber(gdjs.GameSceneCode.GDupgrade_95barObjects4[i].getVariables().getFromIndex(0)) == (gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtowerObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtowerObjects4[0].getVariables()).getFromIndex(3))) ) {
        gdjs.GameSceneCode.condition1IsTrue_0.val = true;
        gdjs.GameSceneCode.GDupgrade_95barObjects4[k] = gdjs.GameSceneCode.GDupgrade_95barObjects4[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDupgrade_95barObjects4.length = k;}if ( gdjs.GameSceneCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtowerObjects4.length;i<l;++i) {
    if ( !(gdjs.GameSceneCode.GDtowerObjects4[i].timerElapsedTime("upgrading", 10)) ) {
        gdjs.GameSceneCode.condition2IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtowerObjects4[k] = gdjs.GameSceneCode.GDtowerObjects4[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtowerObjects4.length = k;}}
}
if (gdjs.GameSceneCode.condition2IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDupgrade_95barObjects4 */
{for(var i = 0, len = gdjs.GameSceneCode.GDupgrade_95barObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDupgrade_95barObjects4[i].setWidth(gdjs.GameSceneCode.GDupgrade_95barObjects4[i].getWidth() + (1 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}}

}


{

gdjs.copyArray(gdjs.GameSceneCode.GDtowerObjects3, gdjs.GameSceneCode.GDtowerObjects4);

gdjs.copyArray(runtimeScene.getObjects("upgrade_bar"), gdjs.GameSceneCode.GDupgrade_95barObjects4);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
gdjs.GameSceneCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtowerObjects4.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtowerObjects4[i].getVariableBoolean(gdjs.GameSceneCode.GDtowerObjects4[i].getVariables().getFromIndex(5), true) ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtowerObjects4[k] = gdjs.GameSceneCode.GDtowerObjects4[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtowerObjects4.length = k;}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDupgrade_95barObjects4.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDupgrade_95barObjects4[i].getVariableNumber(gdjs.GameSceneCode.GDupgrade_95barObjects4[i].getVariables().getFromIndex(0)) == (gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtowerObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtowerObjects4[0].getVariables()).getFromIndex(3))) ) {
        gdjs.GameSceneCode.condition1IsTrue_0.val = true;
        gdjs.GameSceneCode.GDupgrade_95barObjects4[k] = gdjs.GameSceneCode.GDupgrade_95barObjects4[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDupgrade_95barObjects4.length = k;}if ( gdjs.GameSceneCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtowerObjects4.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtowerObjects4[i].timerElapsedTime("upgrading", 10) ) {
        gdjs.GameSceneCode.condition2IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtowerObjects4[k] = gdjs.GameSceneCode.GDtowerObjects4[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtowerObjects4.length = k;}}
}
if (gdjs.GameSceneCode.condition2IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDtowerObjects4 */
/* Reuse gdjs.GameSceneCode.GDupgrade_95barObjects4 */
{for(var i = 0, len = gdjs.GameSceneCode.GDtowerObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtowerObjects4[i].setVariableBoolean(gdjs.GameSceneCode.GDtowerObjects4[i].getVariables().getFromIndex(5), false);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtowerObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtowerObjects4[i].removeTimer("upgrading");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDupgrade_95barObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDupgrade_95barObjects4[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtowerObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtowerObjects4[i].returnVariable(gdjs.GameSceneCode.GDtowerObjects4[i].getVariables().getFromIndex(1)).add(1);
}
}
{ //Subevents
gdjs.GameSceneCode.eventsList97(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList99 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("tower"), gdjs.GameSceneCode.GDtowerObjects2);

for(gdjs.GameSceneCode.forEachIndex3 = 0;gdjs.GameSceneCode.forEachIndex3 < gdjs.GameSceneCode.GDtowerObjects2.length;++gdjs.GameSceneCode.forEachIndex3) {
gdjs.GameSceneCode.GDtowerObjects3.length = 0;


gdjs.GameSceneCode.forEachTemporary3 = gdjs.GameSceneCode.GDtowerObjects2[gdjs.GameSceneCode.forEachIndex3];
gdjs.GameSceneCode.GDtowerObjects3.push(gdjs.GameSceneCode.forEachTemporary3);
if (true) {

{ //Subevents: 
gdjs.GameSceneCode.eventsList98(runtimeScene);} //Subevents end.
}
}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDenemy_95950Objects4ObjectsGDgdjs_46GameSceneCode_46GDenemy_95951Objects4ObjectsGDgdjs_46GameSceneCode_46GDenemy_95952Objects4Objects = Hashtable.newFrom({"enemy_0": gdjs.GameSceneCode.GDenemy_950Objects4, "enemy_1": gdjs.GameSceneCode.GDenemy_951Objects4, "enemy_2": gdjs.GameSceneCode.GDenemy_952Objects4});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95951_9595topObjects4Objects = Hashtable.newFrom({"tower_1_top": gdjs.GameSceneCode.GDtower_951_95topObjects4});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDenemy_95950Objects4ObjectsGDgdjs_46GameSceneCode_46GDenemy_95951Objects4ObjectsGDgdjs_46GameSceneCode_46GDenemy_95952Objects4Objects = Hashtable.newFrom({"enemy_0": gdjs.GameSceneCode.GDenemy_950Objects4, "enemy_1": gdjs.GameSceneCode.GDenemy_951Objects4, "enemy_2": gdjs.GameSceneCode.GDenemy_952Objects4});gdjs.GameSceneCode.eventsList100 = function(runtimeScene) {

};gdjs.GameSceneCode.eventsList101 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("tower_1_top"), gdjs.GameSceneCode.GDtower_951_95topObjects3);

for(gdjs.GameSceneCode.forEachIndex4 = 0;gdjs.GameSceneCode.forEachIndex4 < gdjs.GameSceneCode.GDtower_951_95topObjects3.length;++gdjs.GameSceneCode.forEachIndex4) {
gdjs.copyArray(runtimeScene.getObjects("enemy_0"), gdjs.GameSceneCode.GDenemy_950Objects4);
gdjs.copyArray(runtimeScene.getObjects("enemy_1"), gdjs.GameSceneCode.GDenemy_951Objects4);
gdjs.copyArray(runtimeScene.getObjects("enemy_2"), gdjs.GameSceneCode.GDenemy_952Objects4);
gdjs.GameSceneCode.GDtower_951_95topObjects4.length = 0;


gdjs.GameSceneCode.forEachTemporary4 = gdjs.GameSceneCode.GDtower_951_95topObjects3[gdjs.GameSceneCode.forEachIndex4];
gdjs.GameSceneCode.GDtower_951_95topObjects4.push(gdjs.GameSceneCode.forEachTemporary4);
gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.distanceTest(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDenemy_95950Objects4ObjectsGDgdjs_46GameSceneCode_46GDenemy_95951Objects4ObjectsGDgdjs_46GameSceneCode_46GDenemy_95952Objects4Objects, gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95951_9595topObjects4Objects, 100, false);
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition1IsTrue_0.val = gdjs.evtTools.object.pickNearestObject(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDenemy_95950Objects4ObjectsGDgdjs_46GameSceneCode_46GDenemy_95951Objects4ObjectsGDgdjs_46GameSceneCode_46GDenemy_95952Objects4Objects, (( gdjs.GameSceneCode.GDtower_951_95topObjects4.length === 0 ) ? 0 :gdjs.GameSceneCode.GDtower_951_95topObjects4[0].getPointX("")), (( gdjs.GameSceneCode.GDtower_951_95topObjects4.length === 0 ) ? 0 :gdjs.GameSceneCode.GDtower_951_95topObjects4[0].getPointY("")), false);
}}
if (gdjs.GameSceneCode.condition1IsTrue_0.val) {
{for(var i = 0, len = gdjs.GameSceneCode.GDtower_951_95topObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_951_95topObjects4[i].returnVariable(gdjs.GameSceneCode.GDtower_951_95topObjects4[i].getVariables().getFromIndex(3)).setNumber((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDenemy_952Objects4.length === 0 ) ? ((gdjs.GameSceneCode.GDenemy_951Objects4.length === 0 ) ? ((gdjs.GameSceneCode.GDenemy_950Objects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDenemy_950Objects4[0].getVariables()) : gdjs.GameSceneCode.GDenemy_951Objects4[0].getVariables()) : gdjs.GameSceneCode.GDenemy_952Objects4[0].getVariables()).get("id"))));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_951_95topObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_951_95topObjects4[i].setAngle((gdjs.GameSceneCode.GDtower_951_95topObjects4[i].getAngleToPosition((( gdjs.GameSceneCode.GDenemy_952Objects4.length === 0 ) ? (( gdjs.GameSceneCode.GDenemy_951Objects4.length === 0 ) ? (( gdjs.GameSceneCode.GDenemy_950Objects4.length === 0 ) ? 0 :gdjs.GameSceneCode.GDenemy_950Objects4[0].getPointX("")) :gdjs.GameSceneCode.GDenemy_951Objects4[0].getPointX("")) :gdjs.GameSceneCode.GDenemy_952Objects4[0].getPointX("")), (( gdjs.GameSceneCode.GDenemy_952Objects4.length === 0 ) ? (( gdjs.GameSceneCode.GDenemy_951Objects4.length === 0 ) ? (( gdjs.GameSceneCode.GDenemy_950Objects4.length === 0 ) ? 0 :gdjs.GameSceneCode.GDenemy_950Objects4[0].getPointY("")) :gdjs.GameSceneCode.GDenemy_951Objects4[0].getPointY("")) :gdjs.GameSceneCode.GDenemy_952Objects4[0].getPointY("")))));
}
}}
}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDenemy_95950Objects4ObjectsGDgdjs_46GameSceneCode_46GDenemy_95951Objects4ObjectsGDgdjs_46GameSceneCode_46GDenemy_95952Objects4Objects = Hashtable.newFrom({"enemy_0": gdjs.GameSceneCode.GDenemy_950Objects4, "enemy_1": gdjs.GameSceneCode.GDenemy_951Objects4, "enemy_2": gdjs.GameSceneCode.GDenemy_952Objects4});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95951_9595topObjects4Objects = Hashtable.newFrom({"tower_1_top": gdjs.GameSceneCode.GDtower_951_95topObjects4});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95951_9595bulletObjects5Objects = Hashtable.newFrom({"tower_1_bullet": gdjs.GameSceneCode.GDtower_951_95bulletObjects5});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95951_9595bullet_9595trailObjects5Objects = Hashtable.newFrom({"tower_1_bullet_trail": gdjs.GameSceneCode.GDtower_951_95bullet_95trailObjects5});gdjs.GameSceneCode.eventsList102 = function(runtimeScene) {

{


{
gdjs.copyArray(gdjs.GameSceneCode.GDenemy_950Objects4, gdjs.GameSceneCode.GDenemy_950Objects5);

gdjs.copyArray(gdjs.GameSceneCode.GDenemy_951Objects4, gdjs.GameSceneCode.GDenemy_951Objects5);

gdjs.copyArray(gdjs.GameSceneCode.GDenemy_952Objects4, gdjs.GameSceneCode.GDenemy_952Objects5);

gdjs.copyArray(runtimeScene.getObjects("tower_1_bullet"), gdjs.GameSceneCode.GDtower_951_95bulletObjects5);
gdjs.copyArray(gdjs.GameSceneCode.GDtower_951_95topObjects4, gdjs.GameSceneCode.GDtower_951_95topObjects5);

gdjs.GameSceneCode.GDtower_951_95bullet_95trailObjects5.length = 0;

{for(var i = 0, len = gdjs.GameSceneCode.GDtower_951_95topObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_951_95topObjects5[i].rotateTowardPosition((( gdjs.GameSceneCode.GDenemy_952Objects5.length === 0 ) ? (( gdjs.GameSceneCode.GDenemy_951Objects5.length === 0 ) ? (( gdjs.GameSceneCode.GDenemy_950Objects5.length === 0 ) ? 0 :gdjs.GameSceneCode.GDenemy_950Objects5[0].getPointX("")) :gdjs.GameSceneCode.GDenemy_951Objects5[0].getPointX("")) :gdjs.GameSceneCode.GDenemy_952Objects5[0].getPointX("")), (( gdjs.GameSceneCode.GDenemy_952Objects5.length === 0 ) ? (( gdjs.GameSceneCode.GDenemy_951Objects5.length === 0 ) ? (( gdjs.GameSceneCode.GDenemy_950Objects5.length === 0 ) ? 0 :gdjs.GameSceneCode.GDenemy_950Objects5[0].getPointY("")) :gdjs.GameSceneCode.GDenemy_951Objects5[0].getPointY("")) :gdjs.GameSceneCode.GDenemy_952Objects5[0].getPointY("")), 360, runtimeScene);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_951_95topObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_951_95topObjects5[i].getBehavior("FireBullet").Fire((gdjs.GameSceneCode.GDtower_951_95topObjects5[i].getPointX("bullet")), (gdjs.GameSceneCode.GDtower_951_95topObjects5[i].getPointY("bullet")), gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95951_9595bulletObjects5Objects, (gdjs.GameSceneCode.GDtower_951_95topObjects5[i].getAngle()), 150, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_951_95bulletObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_951_95bulletObjects5[i].setAnimationName("bullet_" + (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDtower_951_95topObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtower_951_95topObjects5[0].getVariables()).getFromIndex(0))));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_951_95bulletObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_951_95bulletObjects5[i].returnVariable(gdjs.GameSceneCode.GDtower_951_95bulletObjects5[i].getVariables().getFromIndex(0)).setNumber((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtower_951_95topObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtower_951_95topObjects5[0].getVariables()).getFromIndex(2))));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_951_95bulletObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_951_95bulletObjects5[i].setZOrder(1000);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95951_9595bullet_9595trailObjects5Objects, (( gdjs.GameSceneCode.GDtower_951_95bulletObjects5.length === 0 ) ? 0 :gdjs.GameSceneCode.GDtower_951_95bulletObjects5[0].getPointX("")), (( gdjs.GameSceneCode.GDtower_951_95bulletObjects5.length === 0 ) ? 0 :gdjs.GameSceneCode.GDtower_951_95bulletObjects5[0].getPointY("")), "");
}{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.GameSceneCode.GDtower_951_95bullet_95trailObjects5.length !== 0 ? gdjs.GameSceneCode.GDtower_951_95bullet_95trailObjects5[0] : null), (gdjs.GameSceneCode.GDtower_951_95bulletObjects5.length !== 0 ? gdjs.GameSceneCode.GDtower_951_95bulletObjects5[0] : null));
}}

}


{

gdjs.copyArray(gdjs.GameSceneCode.GDtower_951_95topObjects4, gdjs.GameSceneCode.GDtower_951_95topObjects5);


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, (gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtower_951_95topObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtower_951_95topObjects5[0].getVariables()).getFromIndex(1)))));
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtower_951_95topObjects5.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtower_951_95topObjects5[i].getBehavior("FireBullet").HasJustFired((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.GameSceneCode.condition1IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtower_951_95topObjects5[k] = gdjs.GameSceneCode.GDtower_951_95topObjects5[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtower_951_95topObjects5.length = k;}}
if (gdjs.GameSceneCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDtower_951_95topObjects5 */
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\bow_shoot.wav", (gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtower_951_95topObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtower_951_95topObjects5[0].getVariables()).getFromIndex(1))), false, 60, 1);
}}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95951_9595bullet_9595trailObjects3Objects = Hashtable.newFrom({"tower_1_bullet_trail": gdjs.GameSceneCode.GDtower_951_95bullet_95trailObjects3});gdjs.GameSceneCode.eventsList103 = function(runtimeScene) {

};gdjs.GameSceneCode.eventsList104 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtsExt__RepeatEveryXSeconds__Repeat.func(runtimeScene, "turret_shoot", 0.25, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList101(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("tower_1_top"), gdjs.GameSceneCode.GDtower_951_95topObjects3);

for(gdjs.GameSceneCode.forEachIndex4 = 0;gdjs.GameSceneCode.forEachIndex4 < gdjs.GameSceneCode.GDtower_951_95topObjects3.length;++gdjs.GameSceneCode.forEachIndex4) {
gdjs.copyArray(runtimeScene.getObjects("enemy_0"), gdjs.GameSceneCode.GDenemy_950Objects4);
gdjs.copyArray(runtimeScene.getObjects("enemy_1"), gdjs.GameSceneCode.GDenemy_951Objects4);
gdjs.copyArray(runtimeScene.getObjects("enemy_2"), gdjs.GameSceneCode.GDenemy_952Objects4);
gdjs.GameSceneCode.GDtower_951_95topObjects4.length = 0;


gdjs.GameSceneCode.forEachTemporary4 = gdjs.GameSceneCode.GDtower_951_95topObjects3[gdjs.GameSceneCode.forEachIndex4];
gdjs.GameSceneCode.GDtower_951_95topObjects4.push(gdjs.GameSceneCode.forEachTemporary4);
gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDenemy_950Objects4.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDenemy_950Objects4[i].getVariableNumber(gdjs.GameSceneCode.GDenemy_950Objects4[i].getVariables().get("id")) == (gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtower_951_95topObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtower_951_95topObjects4[0].getVariables()).getFromIndex(3))) ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDenemy_950Objects4[k] = gdjs.GameSceneCode.GDenemy_950Objects4[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDenemy_950Objects4.length = k;for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDenemy_951Objects4.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDenemy_951Objects4[i].getVariableNumber(gdjs.GameSceneCode.GDenemy_951Objects4[i].getVariables().get("id")) == (gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtower_951_95topObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtower_951_95topObjects4[0].getVariables()).getFromIndex(3))) ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDenemy_951Objects4[k] = gdjs.GameSceneCode.GDenemy_951Objects4[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDenemy_951Objects4.length = k;for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDenemy_952Objects4.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDenemy_952Objects4[i].getVariableNumber(gdjs.GameSceneCode.GDenemy_952Objects4[i].getVariables().get("id")) == (gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtower_951_95topObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtower_951_95topObjects4[0].getVariables()).getFromIndex(3))) ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDenemy_952Objects4[k] = gdjs.GameSceneCode.GDenemy_952Objects4[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDenemy_952Objects4.length = k;}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition1IsTrue_0.val = gdjs.evtTools.object.distanceTest(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDenemy_95950Objects4ObjectsGDgdjs_46GameSceneCode_46GDenemy_95951Objects4ObjectsGDgdjs_46GameSceneCode_46GDenemy_95952Objects4Objects, gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95951_9595topObjects4Objects, 100, false);
}}
if (gdjs.GameSceneCode.condition1IsTrue_0.val) {

{ //Subevents: 
gdjs.GameSceneCode.eventsList102(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("tower_1_bullet"), gdjs.GameSceneCode.GDtower_951_95bulletObjects2);

for(gdjs.GameSceneCode.forEachIndex3 = 0;gdjs.GameSceneCode.forEachIndex3 < gdjs.GameSceneCode.GDtower_951_95bulletObjects2.length;++gdjs.GameSceneCode.forEachIndex3) {
gdjs.copyArray(runtimeScene.getObjects("tower_1_bullet_trail"), gdjs.GameSceneCode.GDtower_951_95bullet_95trailObjects3);
gdjs.GameSceneCode.GDtower_951_95bulletObjects3.length = 0;


gdjs.GameSceneCode.forEachTemporary3 = gdjs.GameSceneCode.GDtower_951_95bulletObjects2[gdjs.GameSceneCode.forEachIndex3];
gdjs.GameSceneCode.GDtower_951_95bulletObjects3.push(gdjs.GameSceneCode.forEachTemporary3);
gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95951_9595bullet_9595trailObjects3Objects, (gdjs.GameSceneCode.GDtower_951_95bulletObjects3.length !== 0 ? gdjs.GameSceneCode.GDtower_951_95bulletObjects3[0] : null));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.GameSceneCode.GDtower_951_95bullet_95trailObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_951_95bullet_95trailObjects3[i].setPosition((( gdjs.GameSceneCode.GDtower_951_95bulletObjects3.length === 0 ) ? 0 :gdjs.GameSceneCode.GDtower_951_95bulletObjects3[0].getPointX("")),(( gdjs.GameSceneCode.GDtower_951_95bulletObjects3.length === 0 ) ? 0 :gdjs.GameSceneCode.GDtower_951_95bulletObjects3[0].getPointY("")));
}
}}
}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDenemy_95950Objects4ObjectsGDgdjs_46GameSceneCode_46GDenemy_95951Objects4ObjectsGDgdjs_46GameSceneCode_46GDenemy_95952Objects4Objects = Hashtable.newFrom({"enemy_0": gdjs.GameSceneCode.GDenemy_950Objects4, "enemy_1": gdjs.GameSceneCode.GDenemy_951Objects4, "enemy_2": gdjs.GameSceneCode.GDenemy_952Objects4});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95952_9595topObjects4Objects = Hashtable.newFrom({"tower_2_top": gdjs.GameSceneCode.GDtower_952_95topObjects4});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDenemy_95950Objects4ObjectsGDgdjs_46GameSceneCode_46GDenemy_95951Objects4ObjectsGDgdjs_46GameSceneCode_46GDenemy_95952Objects4Objects = Hashtable.newFrom({"enemy_0": gdjs.GameSceneCode.GDenemy_950Objects4, "enemy_1": gdjs.GameSceneCode.GDenemy_951Objects4, "enemy_2": gdjs.GameSceneCode.GDenemy_952Objects4});gdjs.GameSceneCode.eventsList105 = function(runtimeScene) {

};gdjs.GameSceneCode.eventsList106 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("tower_2_top"), gdjs.GameSceneCode.GDtower_952_95topObjects3);

for(gdjs.GameSceneCode.forEachIndex4 = 0;gdjs.GameSceneCode.forEachIndex4 < gdjs.GameSceneCode.GDtower_952_95topObjects3.length;++gdjs.GameSceneCode.forEachIndex4) {
gdjs.copyArray(runtimeScene.getObjects("enemy_0"), gdjs.GameSceneCode.GDenemy_950Objects4);
gdjs.copyArray(runtimeScene.getObjects("enemy_1"), gdjs.GameSceneCode.GDenemy_951Objects4);
gdjs.copyArray(runtimeScene.getObjects("enemy_2"), gdjs.GameSceneCode.GDenemy_952Objects4);
gdjs.GameSceneCode.GDtower_952_95topObjects4.length = 0;


gdjs.GameSceneCode.forEachTemporary4 = gdjs.GameSceneCode.GDtower_952_95topObjects3[gdjs.GameSceneCode.forEachIndex4];
gdjs.GameSceneCode.GDtower_952_95topObjects4.push(gdjs.GameSceneCode.forEachTemporary4);
gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.distanceTest(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDenemy_95950Objects4ObjectsGDgdjs_46GameSceneCode_46GDenemy_95951Objects4ObjectsGDgdjs_46GameSceneCode_46GDenemy_95952Objects4Objects, gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95952_9595topObjects4Objects, 100, false);
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition1IsTrue_0.val = gdjs.evtTools.object.pickNearestObject(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDenemy_95950Objects4ObjectsGDgdjs_46GameSceneCode_46GDenemy_95951Objects4ObjectsGDgdjs_46GameSceneCode_46GDenemy_95952Objects4Objects, (( gdjs.GameSceneCode.GDtower_952_95topObjects4.length === 0 ) ? 0 :gdjs.GameSceneCode.GDtower_952_95topObjects4[0].getPointX("")), (( gdjs.GameSceneCode.GDtower_952_95topObjects4.length === 0 ) ? 0 :gdjs.GameSceneCode.GDtower_952_95topObjects4[0].getPointY("")), false);
}}
if (gdjs.GameSceneCode.condition1IsTrue_0.val) {
{for(var i = 0, len = gdjs.GameSceneCode.GDtower_952_95topObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_952_95topObjects4[i].returnVariable(gdjs.GameSceneCode.GDtower_952_95topObjects4[i].getVariables().getFromIndex(3)).setNumber((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDenemy_952Objects4.length === 0 ) ? ((gdjs.GameSceneCode.GDenemy_951Objects4.length === 0 ) ? ((gdjs.GameSceneCode.GDenemy_950Objects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDenemy_950Objects4[0].getVariables()) : gdjs.GameSceneCode.GDenemy_951Objects4[0].getVariables()) : gdjs.GameSceneCode.GDenemy_952Objects4[0].getVariables()).get("id"))));
}
}}
}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDenemy_95950Objects4ObjectsGDgdjs_46GameSceneCode_46GDenemy_95951Objects4ObjectsGDgdjs_46GameSceneCode_46GDenemy_95952Objects4Objects = Hashtable.newFrom({"enemy_0": gdjs.GameSceneCode.GDenemy_950Objects4, "enemy_1": gdjs.GameSceneCode.GDenemy_951Objects4, "enemy_2": gdjs.GameSceneCode.GDenemy_952Objects4});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95952_9595topObjects4Objects = Hashtable.newFrom({"tower_2_top": gdjs.GameSceneCode.GDtower_952_95topObjects4});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95952_9595bulletObjects5Objects = Hashtable.newFrom({"tower_2_bullet": gdjs.GameSceneCode.GDtower_952_95bulletObjects5});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95952_9595bullet_9595trailObjects5Objects = Hashtable.newFrom({"tower_2_bullet_trail": gdjs.GameSceneCode.GDtower_952_95bullet_95trailObjects5});gdjs.GameSceneCode.eventsList107 = function(runtimeScene) {

{


{
gdjs.copyArray(gdjs.GameSceneCode.GDenemy_950Objects4, gdjs.GameSceneCode.GDenemy_950Objects5);

gdjs.copyArray(gdjs.GameSceneCode.GDenemy_951Objects4, gdjs.GameSceneCode.GDenemy_951Objects5);

gdjs.copyArray(gdjs.GameSceneCode.GDenemy_952Objects4, gdjs.GameSceneCode.GDenemy_952Objects5);

gdjs.copyArray(runtimeScene.getObjects("tower_2_bullet"), gdjs.GameSceneCode.GDtower_952_95bulletObjects5);
gdjs.copyArray(gdjs.GameSceneCode.GDtower_952_95topObjects4, gdjs.GameSceneCode.GDtower_952_95topObjects5);

gdjs.GameSceneCode.GDtower_952_95bullet_95trailObjects5.length = 0;

{for(var i = 0, len = gdjs.GameSceneCode.GDtower_952_95topObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_952_95topObjects5[i].getBehavior("FireBullet").Fire((gdjs.GameSceneCode.GDtower_952_95topObjects5[i].getPointX("bullet")), (gdjs.GameSceneCode.GDtower_952_95topObjects5[i].getPointY("bullet")), gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95952_9595bulletObjects5Objects, (gdjs.GameSceneCode.GDtower_952_95topObjects5[i].getAngleToPosition((( gdjs.GameSceneCode.GDenemy_952Objects5.length === 0 ) ? (( gdjs.GameSceneCode.GDenemy_951Objects5.length === 0 ) ? (( gdjs.GameSceneCode.GDenemy_950Objects5.length === 0 ) ? 0 :gdjs.GameSceneCode.GDenemy_950Objects5[0].getPointX("")) :gdjs.GameSceneCode.GDenemy_951Objects5[0].getPointX("")) :gdjs.GameSceneCode.GDenemy_952Objects5[0].getPointX("")), (( gdjs.GameSceneCode.GDenemy_952Objects5.length === 0 ) ? (( gdjs.GameSceneCode.GDenemy_951Objects5.length === 0 ) ? (( gdjs.GameSceneCode.GDenemy_950Objects5.length === 0 ) ? 0 :gdjs.GameSceneCode.GDenemy_950Objects5[0].getPointY("")) :gdjs.GameSceneCode.GDenemy_951Objects5[0].getPointY("")) :gdjs.GameSceneCode.GDenemy_952Objects5[0].getPointY("")))), 100, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_952_95bulletObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_952_95bulletObjects5[i].setAnimationName("bullet_" + (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDtower_952_95topObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtower_952_95topObjects5[0].getVariables()).getFromIndex(0))));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_952_95bulletObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_952_95bulletObjects5[i].returnVariable(gdjs.GameSceneCode.GDtower_952_95bulletObjects5[i].getVariables().getFromIndex(0)).setNumber((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtower_952_95topObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtower_952_95topObjects5[0].getVariables()).getFromIndex(2))));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtower_952_95bulletObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_952_95bulletObjects5[i].setZOrder(1000);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95952_9595bullet_9595trailObjects5Objects, (( gdjs.GameSceneCode.GDtower_952_95bulletObjects5.length === 0 ) ? 0 :gdjs.GameSceneCode.GDtower_952_95bulletObjects5[0].getPointX("")), (( gdjs.GameSceneCode.GDtower_952_95bulletObjects5.length === 0 ) ? 0 :gdjs.GameSceneCode.GDtower_952_95bulletObjects5[0].getPointY("")), "");
}{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.GameSceneCode.GDtower_952_95bullet_95trailObjects5.length !== 0 ? gdjs.GameSceneCode.GDtower_952_95bullet_95trailObjects5[0] : null), (gdjs.GameSceneCode.GDtower_952_95bulletObjects5.length !== 0 ? gdjs.GameSceneCode.GDtower_952_95bulletObjects5[0] : null));
}}

}


{

gdjs.copyArray(gdjs.GameSceneCode.GDtower_952_95topObjects4, gdjs.GameSceneCode.GDtower_952_95topObjects5);


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, (gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtower_952_95topObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtower_952_95topObjects5[0].getVariables()).getFromIndex(1)))));
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtower_952_95topObjects5.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtower_952_95topObjects5[i].getBehavior("FireBullet").HasJustFired((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.GameSceneCode.condition1IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtower_952_95topObjects5[k] = gdjs.GameSceneCode.GDtower_952_95topObjects5[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtower_952_95topObjects5.length = k;}}
if (gdjs.GameSceneCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDtower_952_95topObjects5 */
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\06-fireball.wav", (gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtower_952_95topObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtower_952_95topObjects5[0].getVariables()).getFromIndex(1))), false, 60, 1);
}}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95952_9595bullet_9595trailObjects3Objects = Hashtable.newFrom({"tower_2_bullet_trail": gdjs.GameSceneCode.GDtower_952_95bullet_95trailObjects3});gdjs.GameSceneCode.eventsList108 = function(runtimeScene) {

};gdjs.GameSceneCode.eventsList109 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtsExt__RepeatEveryXSeconds__Repeat.func(runtimeScene, "turret_2_shoot", 0.5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList106(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("tower_2_top"), gdjs.GameSceneCode.GDtower_952_95topObjects3);

for(gdjs.GameSceneCode.forEachIndex4 = 0;gdjs.GameSceneCode.forEachIndex4 < gdjs.GameSceneCode.GDtower_952_95topObjects3.length;++gdjs.GameSceneCode.forEachIndex4) {
gdjs.copyArray(runtimeScene.getObjects("enemy_0"), gdjs.GameSceneCode.GDenemy_950Objects4);
gdjs.copyArray(runtimeScene.getObjects("enemy_1"), gdjs.GameSceneCode.GDenemy_951Objects4);
gdjs.copyArray(runtimeScene.getObjects("enemy_2"), gdjs.GameSceneCode.GDenemy_952Objects4);
gdjs.GameSceneCode.GDtower_952_95topObjects4.length = 0;


gdjs.GameSceneCode.forEachTemporary4 = gdjs.GameSceneCode.GDtower_952_95topObjects3[gdjs.GameSceneCode.forEachIndex4];
gdjs.GameSceneCode.GDtower_952_95topObjects4.push(gdjs.GameSceneCode.forEachTemporary4);
gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDenemy_950Objects4.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDenemy_950Objects4[i].getVariableNumber(gdjs.GameSceneCode.GDenemy_950Objects4[i].getVariables().get("id")) == (gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtower_952_95topObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtower_952_95topObjects4[0].getVariables()).getFromIndex(3))) ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDenemy_950Objects4[k] = gdjs.GameSceneCode.GDenemy_950Objects4[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDenemy_950Objects4.length = k;for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDenemy_951Objects4.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDenemy_951Objects4[i].getVariableNumber(gdjs.GameSceneCode.GDenemy_951Objects4[i].getVariables().get("id")) == (gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtower_952_95topObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtower_952_95topObjects4[0].getVariables()).getFromIndex(3))) ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDenemy_951Objects4[k] = gdjs.GameSceneCode.GDenemy_951Objects4[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDenemy_951Objects4.length = k;for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDenemy_952Objects4.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDenemy_952Objects4[i].getVariableNumber(gdjs.GameSceneCode.GDenemy_952Objects4[i].getVariables().get("id")) == (gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtower_952_95topObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtower_952_95topObjects4[0].getVariables()).getFromIndex(3))) ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDenemy_952Objects4[k] = gdjs.GameSceneCode.GDenemy_952Objects4[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDenemy_952Objects4.length = k;}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition1IsTrue_0.val = gdjs.evtTools.object.distanceTest(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDenemy_95950Objects4ObjectsGDgdjs_46GameSceneCode_46GDenemy_95951Objects4ObjectsGDgdjs_46GameSceneCode_46GDenemy_95952Objects4Objects, gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95952_9595topObjects4Objects, 100, false);
}}
if (gdjs.GameSceneCode.condition1IsTrue_0.val) {

{ //Subevents: 
gdjs.GameSceneCode.eventsList107(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("tower_2_bullet"), gdjs.GameSceneCode.GDtower_952_95bulletObjects2);

for(gdjs.GameSceneCode.forEachIndex3 = 0;gdjs.GameSceneCode.forEachIndex3 < gdjs.GameSceneCode.GDtower_952_95bulletObjects2.length;++gdjs.GameSceneCode.forEachIndex3) {
gdjs.copyArray(runtimeScene.getObjects("tower_2_bullet_trail"), gdjs.GameSceneCode.GDtower_952_95bullet_95trailObjects3);
gdjs.GameSceneCode.GDtower_952_95bulletObjects3.length = 0;


gdjs.GameSceneCode.forEachTemporary3 = gdjs.GameSceneCode.GDtower_952_95bulletObjects2[gdjs.GameSceneCode.forEachIndex3];
gdjs.GameSceneCode.GDtower_952_95bulletObjects3.push(gdjs.GameSceneCode.forEachTemporary3);
gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95952_9595bullet_9595trailObjects3Objects, (gdjs.GameSceneCode.GDtower_952_95bulletObjects3.length !== 0 ? gdjs.GameSceneCode.GDtower_952_95bulletObjects3[0] : null));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.GameSceneCode.GDtower_952_95bullet_95trailObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_952_95bullet_95trailObjects3[i].setPosition((( gdjs.GameSceneCode.GDtower_952_95bulletObjects3.length === 0 ) ? 0 :gdjs.GameSceneCode.GDtower_952_95bulletObjects3[0].getPointX("")),(( gdjs.GameSceneCode.GDtower_952_95bulletObjects3.length === 0 ) ? 0 :gdjs.GameSceneCode.GDtower_952_95bulletObjects3[0].getPointY("")));
}
}}
}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95953_9595topObjects5Objects = Hashtable.newFrom({"tower_3_top": gdjs.GameSceneCode.GDtower_953_95topObjects5});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDenemy_95950Objects5ObjectsGDgdjs_46GameSceneCode_46GDenemy_95951Objects5ObjectsGDgdjs_46GameSceneCode_46GDenemy_95952Objects5Objects = Hashtable.newFrom({"enemy_0": gdjs.GameSceneCode.GDenemy_950Objects5, "enemy_1": gdjs.GameSceneCode.GDenemy_951Objects5, "enemy_2": gdjs.GameSceneCode.GDenemy_952Objects5});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtxt_9595enemies_9595damageObjects6Objects = Hashtable.newFrom({"txt_enemies_damage": gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects6});gdjs.GameSceneCode.eventsList110 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition0IsTrue_0;
gdjs.GameSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11869620);
}
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.GameSceneCode.GDenemy_950Objects5, gdjs.GameSceneCode.GDenemy_950Objects6);

gdjs.copyArray(gdjs.GameSceneCode.GDenemy_951Objects5, gdjs.GameSceneCode.GDenemy_951Objects6);

gdjs.copyArray(gdjs.GameSceneCode.GDenemy_952Objects5, gdjs.GameSceneCode.GDenemy_952Objects6);

gdjs.copyArray(gdjs.GameSceneCode.GDtower_953_95topObjects5, gdjs.GameSceneCode.GDtower_953_95topObjects6);

gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtxt_9595enemies_9595damageObjects6Objects, (( gdjs.GameSceneCode.GDenemy_952Objects6.length === 0 ) ? (( gdjs.GameSceneCode.GDenemy_951Objects6.length === 0 ) ? (( gdjs.GameSceneCode.GDenemy_950Objects6.length === 0 ) ? 0 :gdjs.GameSceneCode.GDenemy_950Objects6[0].getPointX("")) :gdjs.GameSceneCode.GDenemy_951Objects6[0].getPointX("")) :gdjs.GameSceneCode.GDenemy_952Objects6[0].getPointX("")), (( gdjs.GameSceneCode.GDenemy_952Objects6.length === 0 ) ? (( gdjs.GameSceneCode.GDenemy_951Objects6.length === 0 ) ? (( gdjs.GameSceneCode.GDenemy_950Objects6.length === 0 ) ? 0 :gdjs.GameSceneCode.GDenemy_950Objects6[0].getPointY("")) :gdjs.GameSceneCode.GDenemy_951Objects6[0].getPointY("")) :gdjs.GameSceneCode.GDenemy_952Objects6[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects6.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects6[i].setString((gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDtower_953_95topObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtower_953_95topObjects6[0].getVariables()).getFromIndex(4))));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects6.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects6[i].setCharacterSize(40);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects6.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects6[i].setGradient("LINEAR_VERTICAL", "241;196;196", "236;122;122", "182;40;40", "128;24;24");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects6.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects6[i].setOutline("74;74;74", 4);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects6.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects6[i].setScale(0.2);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDenemy_950Objects6.length ;i < len;++i) {
    gdjs.GameSceneCode.GDenemy_950Objects6[i].returnVariable(gdjs.GameSceneCode.GDenemy_950Objects6[i].getVariables().get("hp")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtower_953_95topObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtower_953_95topObjects6[0].getVariables()).getFromIndex(4))));
}
for(var i = 0, len = gdjs.GameSceneCode.GDenemy_951Objects6.length ;i < len;++i) {
    gdjs.GameSceneCode.GDenemy_951Objects6[i].returnVariable(gdjs.GameSceneCode.GDenemy_951Objects6[i].getVariables().get("hp")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtower_953_95topObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtower_953_95topObjects6[0].getVariables()).getFromIndex(4))));
}
for(var i = 0, len = gdjs.GameSceneCode.GDenemy_952Objects6.length ;i < len;++i) {
    gdjs.GameSceneCode.GDenemy_952Objects6[i].returnVariable(gdjs.GameSceneCode.GDenemy_952Objects6[i].getVariables().get("hp")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtower_953_95topObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtower_953_95topObjects6[0].getVariables()).getFromIndex(4))));
}
}}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 21));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\08-melee-slash.wav", 21, false, 100, 1);
}}

}


};gdjs.GameSceneCode.eventsList111 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtsExt__RepeatEveryXSeconds__Repeat.func(runtimeScene, "melee_attack", 0.5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDtower_953_95topObjects5 */
{for(var i = 0, len = gdjs.GameSceneCode.GDtower_953_95topObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_953_95topObjects5[i].setAnimationName("attack_melee_grade_" + (gdjs.RuntimeObject.getVariableString(gdjs.GameSceneCode.GDtower_953_95topObjects5[i].getVariables().getFromIndex(0))));
}
}
{ //Subevents
gdjs.GameSceneCode.eventsList110(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList112 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameSceneCode.GDenemy_950Objects4, gdjs.GameSceneCode.GDenemy_950Objects5);

gdjs.copyArray(gdjs.GameSceneCode.GDenemy_951Objects4, gdjs.GameSceneCode.GDenemy_951Objects5);

gdjs.copyArray(gdjs.GameSceneCode.GDenemy_952Objects4, gdjs.GameSceneCode.GDenemy_952Objects5);

gdjs.copyArray(runtimeScene.getObjects("tower_3_top"), gdjs.GameSceneCode.GDtower_953_95topObjects5);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95953_9595topObjects5Objects, gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDenemy_95950Objects5ObjectsGDgdjs_46GameSceneCode_46GDenemy_95951Objects5ObjectsGDgdjs_46GameSceneCode_46GDenemy_95952Objects5Objects, false, runtimeScene, false);
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDenemy_950Objects5 */
/* Reuse gdjs.GameSceneCode.GDenemy_951Objects5 */
/* Reuse gdjs.GameSceneCode.GDenemy_952Objects5 */
{for(var i = 0, len = gdjs.GameSceneCode.GDenemy_950Objects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDenemy_950Objects5[i].getBehavior("Pathfinding").setSpeed(0);
}
for(var i = 0, len = gdjs.GameSceneCode.GDenemy_951Objects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDenemy_951Objects5[i].getBehavior("Pathfinding").setSpeed(0);
}
for(var i = 0, len = gdjs.GameSceneCode.GDenemy_952Objects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDenemy_952Objects5[i].getBehavior("Pathfinding").setSpeed(0);
}
}
{ //Subevents
gdjs.GameSceneCode.eventsList111(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList113 = function(runtimeScene) {

};gdjs.GameSceneCode.eventsList114 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("enemy_0"), gdjs.GameSceneCode.GDenemy_950Objects3);
gdjs.copyArray(runtimeScene.getObjects("enemy_1"), gdjs.GameSceneCode.GDenemy_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("enemy_2"), gdjs.GameSceneCode.GDenemy_952Objects3);

gdjs.GameSceneCode.forEachTotalCount4 = 0;
gdjs.GameSceneCode.forEachObjects4.length = 0;
gdjs.GameSceneCode.forEachCount0_4 = gdjs.GameSceneCode.GDenemy_950Objects3.length;
gdjs.GameSceneCode.forEachTotalCount4 += gdjs.GameSceneCode.forEachCount0_4;
gdjs.GameSceneCode.forEachObjects4.push.apply(gdjs.GameSceneCode.forEachObjects4,gdjs.GameSceneCode.GDenemy_950Objects3);
gdjs.GameSceneCode.forEachCount1_4 = gdjs.GameSceneCode.GDenemy_951Objects3.length;
gdjs.GameSceneCode.forEachTotalCount4 += gdjs.GameSceneCode.forEachCount1_4;
gdjs.GameSceneCode.forEachObjects4.push.apply(gdjs.GameSceneCode.forEachObjects4,gdjs.GameSceneCode.GDenemy_951Objects3);
gdjs.GameSceneCode.forEachCount2_4 = gdjs.GameSceneCode.GDenemy_952Objects3.length;
gdjs.GameSceneCode.forEachTotalCount4 += gdjs.GameSceneCode.forEachCount2_4;
gdjs.GameSceneCode.forEachObjects4.push.apply(gdjs.GameSceneCode.forEachObjects4,gdjs.GameSceneCode.GDenemy_952Objects3);
for(gdjs.GameSceneCode.forEachIndex4 = 0;gdjs.GameSceneCode.forEachIndex4 < gdjs.GameSceneCode.forEachTotalCount4;++gdjs.GameSceneCode.forEachIndex4) {
gdjs.GameSceneCode.GDenemy_950Objects4.length = 0;

gdjs.GameSceneCode.GDenemy_951Objects4.length = 0;

gdjs.GameSceneCode.GDenemy_952Objects4.length = 0;


if (gdjs.GameSceneCode.forEachIndex4 < gdjs.GameSceneCode.forEachCount0_4) {
    gdjs.GameSceneCode.GDenemy_950Objects4.push(gdjs.GameSceneCode.forEachObjects4[gdjs.GameSceneCode.forEachIndex4]);
}
else if (gdjs.GameSceneCode.forEachIndex4 < gdjs.GameSceneCode.forEachCount0_4+gdjs.GameSceneCode.forEachCount1_4) {
    gdjs.GameSceneCode.GDenemy_951Objects4.push(gdjs.GameSceneCode.forEachObjects4[gdjs.GameSceneCode.forEachIndex4]);
}
else if (gdjs.GameSceneCode.forEachIndex4 < gdjs.GameSceneCode.forEachCount0_4+gdjs.GameSceneCode.forEachCount1_4+gdjs.GameSceneCode.forEachCount2_4) {
    gdjs.GameSceneCode.GDenemy_952Objects4.push(gdjs.GameSceneCode.forEachObjects4[gdjs.GameSceneCode.forEachIndex4]);
}
if (true) {

{ //Subevents: 
gdjs.GameSceneCode.eventsList112(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("tower_3_top"), gdjs.GameSceneCode.GDtower_953_95topObjects2);

for(gdjs.GameSceneCode.forEachIndex3 = 0;gdjs.GameSceneCode.forEachIndex3 < gdjs.GameSceneCode.GDtower_953_95topObjects2.length;++gdjs.GameSceneCode.forEachIndex3) {
gdjs.GameSceneCode.GDtower_953_95topObjects3.length = 0;


gdjs.GameSceneCode.forEachTemporary3 = gdjs.GameSceneCode.GDtower_953_95topObjects2[gdjs.GameSceneCode.forEachIndex3];
gdjs.GameSceneCode.GDtower_953_95topObjects3.push(gdjs.GameSceneCode.forEachTemporary3);
gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtower_953_95topObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtower_953_95topObjects3[i].isCurrentAnimationName("attack_melee_grade_" + (gdjs.RuntimeObject.getVariableString(gdjs.GameSceneCode.GDtower_953_95topObjects3[i].getVariables().getFromIndex(0)))) ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtower_953_95topObjects3[k] = gdjs.GameSceneCode.GDtower_953_95topObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtower_953_95topObjects3.length = k;}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtower_953_95topObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtower_953_95topObjects3[i].hasAnimationEnded() ) {
        gdjs.GameSceneCode.condition1IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtower_953_95topObjects3[k] = gdjs.GameSceneCode.GDtower_953_95topObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtower_953_95topObjects3.length = k;}}
if (gdjs.GameSceneCode.condition1IsTrue_0.val) {
{for(var i = 0, len = gdjs.GameSceneCode.GDtower_953_95topObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_953_95topObjects3[i].setAnimationName("idle_melee_grade_" + (gdjs.RuntimeObject.getVariableString(gdjs.GameSceneCode.GDtower_953_95topObjects3[i].getVariables().getFromIndex(0))));
}
}}
}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95951_9595bulletObjects3ObjectsGDgdjs_46GameSceneCode_46GDtower_95952_9595bulletObjects3Objects = Hashtable.newFrom({"tower_1_bullet": gdjs.GameSceneCode.GDtower_951_95bulletObjects3, "tower_2_bullet": gdjs.GameSceneCode.GDtower_952_95bulletObjects3});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDenemy_95950Objects3ObjectsGDgdjs_46GameSceneCode_46GDenemy_95951Objects3ObjectsGDgdjs_46GameSceneCode_46GDenemy_95952Objects3Objects = Hashtable.newFrom({"enemy_0": gdjs.GameSceneCode.GDenemy_950Objects3, "enemy_1": gdjs.GameSceneCode.GDenemy_951Objects3, "enemy_2": gdjs.GameSceneCode.GDenemy_952Objects3});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDarrow_9595explosionObjects4Objects = Hashtable.newFrom({"arrow_explosion": gdjs.GameSceneCode.GDarrow_95explosionObjects4});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtxt_9595enemies_9595damageObjects4Objects = Hashtable.newFrom({"txt_enemies_damage": gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects4});gdjs.GameSceneCode.eventsList115 = function(runtimeScene) {

{


{
gdjs.copyArray(gdjs.GameSceneCode.GDenemy_950Objects3, gdjs.GameSceneCode.GDenemy_950Objects4);

gdjs.copyArray(gdjs.GameSceneCode.GDenemy_951Objects3, gdjs.GameSceneCode.GDenemy_951Objects4);

gdjs.copyArray(gdjs.GameSceneCode.GDenemy_952Objects3, gdjs.GameSceneCode.GDenemy_952Objects4);

gdjs.copyArray(gdjs.GameSceneCode.GDtower_951_95bulletObjects3, gdjs.GameSceneCode.GDtower_951_95bulletObjects4);

gdjs.copyArray(gdjs.GameSceneCode.GDtower_952_95bulletObjects3, gdjs.GameSceneCode.GDtower_952_95bulletObjects4);

gdjs.GameSceneCode.GDarrow_95explosionObjects4.length = 0;

gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDarrow_9595explosionObjects4Objects, (( gdjs.GameSceneCode.GDenemy_952Objects4.length === 0 ) ? (( gdjs.GameSceneCode.GDenemy_951Objects4.length === 0 ) ? (( gdjs.GameSceneCode.GDenemy_950Objects4.length === 0 ) ? 0 :gdjs.GameSceneCode.GDenemy_950Objects4[0].getPointX("")) :gdjs.GameSceneCode.GDenemy_951Objects4[0].getPointX("")) :gdjs.GameSceneCode.GDenemy_952Objects4[0].getPointX("")), (( gdjs.GameSceneCode.GDenemy_952Objects4.length === 0 ) ? (( gdjs.GameSceneCode.GDenemy_951Objects4.length === 0 ) ? (( gdjs.GameSceneCode.GDenemy_950Objects4.length === 0 ) ? 0 :gdjs.GameSceneCode.GDenemy_950Objects4[0].getPointY("")) :gdjs.GameSceneCode.GDenemy_951Objects4[0].getPointY("")) :gdjs.GameSceneCode.GDenemy_952Objects4[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtxt_9595enemies_9595damageObjects4Objects, (( gdjs.GameSceneCode.GDenemy_952Objects4.length === 0 ) ? (( gdjs.GameSceneCode.GDenemy_951Objects4.length === 0 ) ? (( gdjs.GameSceneCode.GDenemy_950Objects4.length === 0 ) ? 0 :gdjs.GameSceneCode.GDenemy_950Objects4[0].getPointX("")) :gdjs.GameSceneCode.GDenemy_951Objects4[0].getPointX("")) :gdjs.GameSceneCode.GDenemy_952Objects4[0].getPointX("")), (( gdjs.GameSceneCode.GDenemy_952Objects4.length === 0 ) ? (( gdjs.GameSceneCode.GDenemy_951Objects4.length === 0 ) ? (( gdjs.GameSceneCode.GDenemy_950Objects4.length === 0 ) ? 0 :gdjs.GameSceneCode.GDenemy_950Objects4[0].getPointY("")) :gdjs.GameSceneCode.GDenemy_951Objects4[0].getPointY("")) :gdjs.GameSceneCode.GDenemy_952Objects4[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects4[i].setString((gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDtower_952_95bulletObjects4.length === 0 ) ? ((gdjs.GameSceneCode.GDtower_951_95bulletObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtower_951_95bulletObjects4[0].getVariables()) : gdjs.GameSceneCode.GDtower_952_95bulletObjects4[0].getVariables()).get("damage"))));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects4[i].setCharacterSize(40);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects4[i].setGradient("LINEAR_VERTICAL", "241;196;196", "236;122;122", "182;40;40", "128;24;24");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects4[i].setOutline("74;74;74", 4);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects4[i].setScale(0.2);
}
}}

}


{


{
gdjs.copyArray(gdjs.GameSceneCode.GDenemy_950Objects3, gdjs.GameSceneCode.GDenemy_950Objects4);

gdjs.copyArray(gdjs.GameSceneCode.GDenemy_951Objects3, gdjs.GameSceneCode.GDenemy_951Objects4);

gdjs.copyArray(gdjs.GameSceneCode.GDenemy_952Objects3, gdjs.GameSceneCode.GDenemy_952Objects4);

gdjs.copyArray(gdjs.GameSceneCode.GDtower_951_95bulletObjects3, gdjs.GameSceneCode.GDtower_951_95bulletObjects4);

gdjs.copyArray(gdjs.GameSceneCode.GDtower_952_95bulletObjects3, gdjs.GameSceneCode.GDtower_952_95bulletObjects4);

{for(var i = 0, len = gdjs.GameSceneCode.GDtower_951_95bulletObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_951_95bulletObjects4[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameSceneCode.GDtower_952_95bulletObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_952_95bulletObjects4[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDenemy_950Objects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDenemy_950Objects4[i].returnVariable(gdjs.GameSceneCode.GDenemy_950Objects4[i].getVariables().get("hp")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtower_952_95bulletObjects4.length === 0 ) ? ((gdjs.GameSceneCode.GDtower_951_95bulletObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtower_951_95bulletObjects4[0].getVariables()) : gdjs.GameSceneCode.GDtower_952_95bulletObjects4[0].getVariables()).get("damage"))));
}
for(var i = 0, len = gdjs.GameSceneCode.GDenemy_951Objects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDenemy_951Objects4[i].returnVariable(gdjs.GameSceneCode.GDenemy_951Objects4[i].getVariables().get("hp")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtower_952_95bulletObjects4.length === 0 ) ? ((gdjs.GameSceneCode.GDtower_951_95bulletObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtower_951_95bulletObjects4[0].getVariables()) : gdjs.GameSceneCode.GDtower_952_95bulletObjects4[0].getVariables()).get("damage"))));
}
for(var i = 0, len = gdjs.GameSceneCode.GDenemy_952Objects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDenemy_952Objects4[i].returnVariable(gdjs.GameSceneCode.GDenemy_952Objects4[i].getVariables().get("hp")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDtower_952_95bulletObjects4.length === 0 ) ? ((gdjs.GameSceneCode.GDtower_951_95bulletObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDtower_951_95bulletObjects4[0].getVariables()) : gdjs.GameSceneCode.GDtower_952_95bulletObjects4[0].getVariables()).get("damage"))));
}
}}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 21));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\507131__daleonfire__punch2.wav", 21, false, 100, 1);
}}

}


};gdjs.GameSceneCode.eventsList116 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("txt_enemies_damage"), gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects3);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects3[i].getOpacity() > 0 ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects3[k] = gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects3.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects3 */
{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects3[i].setOpacity(gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects3[i].getOpacity() - (255 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects3[i].setY(gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects3[i].getY() - (30 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("txt_enemies_damage"), gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects2);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects2[i].getOpacity() == 0 ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects2[k] = gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects2.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects2 */
{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.GameSceneCode.eventsList117 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("enemy_0"), gdjs.GameSceneCode.GDenemy_950Objects3);
gdjs.copyArray(runtimeScene.getObjects("enemy_1"), gdjs.GameSceneCode.GDenemy_951Objects3);
gdjs.copyArray(runtimeScene.getObjects("enemy_2"), gdjs.GameSceneCode.GDenemy_952Objects3);
gdjs.copyArray(runtimeScene.getObjects("tower_1_bullet"), gdjs.GameSceneCode.GDtower_951_95bulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("tower_2_bullet"), gdjs.GameSceneCode.GDtower_952_95bulletObjects3);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtower_95951_9595bulletObjects3ObjectsGDgdjs_46GameSceneCode_46GDtower_95952_9595bulletObjects3Objects, gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDenemy_95950Objects3ObjectsGDgdjs_46GameSceneCode_46GDenemy_95951Objects3ObjectsGDgdjs_46GameSceneCode_46GDenemy_95952Objects3Objects, false, runtimeScene, false);
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition1IsTrue_0;
gdjs.GameSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11874492);
}
}}
if (gdjs.GameSceneCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList115(runtimeScene);} //End of subevents
}

}


{


gdjs.GameSceneCode.eventsList116(runtimeScene);
}


};gdjs.GameSceneCode.eventsList118 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameSceneCode.GDtower_951_95bulletObjects2, gdjs.GameSceneCode.GDtower_951_95bulletObjects3);

gdjs.copyArray(gdjs.GameSceneCode.GDtower_952_95bulletObjects2, gdjs.GameSceneCode.GDtower_952_95bulletObjects3);


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtower_951_95bulletObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtower_951_95bulletObjects3[i].getVariableNumber(gdjs.GameSceneCode.GDtower_951_95bulletObjects3[i].getVariables().get("timer")) > 1 ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtower_951_95bulletObjects3[k] = gdjs.GameSceneCode.GDtower_951_95bulletObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtower_951_95bulletObjects3.length = k;for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDtower_952_95bulletObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDtower_952_95bulletObjects3[i].getVariableNumber(gdjs.GameSceneCode.GDtower_952_95bulletObjects3[i].getVariables().get("timer")) > 1 ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDtower_952_95bulletObjects3[k] = gdjs.GameSceneCode.GDtower_952_95bulletObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDtower_952_95bulletObjects3.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDtower_951_95bulletObjects3 */
/* Reuse gdjs.GameSceneCode.GDtower_952_95bulletObjects3 */
{for(var i = 0, len = gdjs.GameSceneCode.GDtower_951_95bulletObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_951_95bulletObjects3[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameSceneCode.GDtower_952_95bulletObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_952_95bulletObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.GameSceneCode.eventsList119 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("tower_1_bullet"), gdjs.GameSceneCode.GDtower_951_95bulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("tower_2_bullet"), gdjs.GameSceneCode.GDtower_952_95bulletObjects1);

gdjs.GameSceneCode.forEachTotalCount2 = 0;
gdjs.GameSceneCode.forEachObjects2.length = 0;
gdjs.GameSceneCode.forEachCount0_2 = gdjs.GameSceneCode.GDtower_951_95bulletObjects1.length;
gdjs.GameSceneCode.forEachTotalCount2 += gdjs.GameSceneCode.forEachCount0_2;
gdjs.GameSceneCode.forEachObjects2.push.apply(gdjs.GameSceneCode.forEachObjects2,gdjs.GameSceneCode.GDtower_951_95bulletObjects1);
gdjs.GameSceneCode.forEachCount1_2 = gdjs.GameSceneCode.GDtower_952_95bulletObjects1.length;
gdjs.GameSceneCode.forEachTotalCount2 += gdjs.GameSceneCode.forEachCount1_2;
gdjs.GameSceneCode.forEachObjects2.push.apply(gdjs.GameSceneCode.forEachObjects2,gdjs.GameSceneCode.GDtower_952_95bulletObjects1);
for(gdjs.GameSceneCode.forEachIndex2 = 0;gdjs.GameSceneCode.forEachIndex2 < gdjs.GameSceneCode.forEachTotalCount2;++gdjs.GameSceneCode.forEachIndex2) {
gdjs.GameSceneCode.GDtower_951_95bulletObjects2.length = 0;

gdjs.GameSceneCode.GDtower_952_95bulletObjects2.length = 0;


if (gdjs.GameSceneCode.forEachIndex2 < gdjs.GameSceneCode.forEachCount0_2) {
    gdjs.GameSceneCode.GDtower_951_95bulletObjects2.push(gdjs.GameSceneCode.forEachObjects2[gdjs.GameSceneCode.forEachIndex2]);
}
else if (gdjs.GameSceneCode.forEachIndex2 < gdjs.GameSceneCode.forEachCount0_2+gdjs.GameSceneCode.forEachCount1_2) {
    gdjs.GameSceneCode.GDtower_952_95bulletObjects2.push(gdjs.GameSceneCode.forEachObjects2[gdjs.GameSceneCode.forEachIndex2]);
}
if (true) {
{for(var i = 0, len = gdjs.GameSceneCode.GDtower_951_95bulletObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_951_95bulletObjects2[i].returnVariable(gdjs.GameSceneCode.GDtower_951_95bulletObjects2[i].getVariables().get("timer")).add(1 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}
for(var i = 0, len = gdjs.GameSceneCode.GDtower_952_95bulletObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtower_952_95bulletObjects2[i].returnVariable(gdjs.GameSceneCode.GDtower_952_95bulletObjects2[i].getVariables().get("timer")).add(1 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}
}
{ //Subevents: 
gdjs.GameSceneCode.eventsList118(runtimeScene);} //Subevents end.
}
}

}


};gdjs.GameSceneCode.eventsList120 = function(runtimeScene) {

{


gdjs.GameSceneCode.eventsList70(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList76(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList80(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList85(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList93(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList99(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList104(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList109(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList114(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList117(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList119(runtimeScene);
}


};gdjs.GameSceneCode.eventsList121 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableBoolean(runtimeScene.getVariables().getFromIndex(9), false);
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList120(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDobj_9595btn_9595nextObjects1Objects = Hashtable.newFrom({"obj_btn_next": gdjs.GameSceneCode.GDobj_95btn_95nextObjects1});gdjs.GameSceneCode.eventsList122 = function(runtimeScene) {

{



}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition0IsTrue_0;
gdjs.GameSceneCode.condition0IsTrue_1.val = false;
gdjs.GameSceneCode.condition1IsTrue_1.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_1.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("max_level_reached")) == 7;
if( gdjs.GameSceneCode.condition0IsTrue_1.val ) {
    gdjs.GameSceneCode.conditionTrue_1.val = true;
}
}
{
gdjs.GameSceneCode.condition1IsTrue_1.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("game_level")) == 7;
if( gdjs.GameSceneCode.condition1IsTrue_1.val ) {
    gdjs.GameSceneCode.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "EndScene", false);
}}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("game_level")) < 7;
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "GameScene", false);
}}

}


};gdjs.GameSceneCode.eventsList123 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("obj_btn_next"), gdjs.GameSceneCode.GDobj_95btn_95nextObjects1);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
gdjs.GameSceneCode.condition2IsTrue_0.val = false;
gdjs.GameSceneCode.condition3IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDobj_9595btn_9595nextObjects1Objects, runtimeScene, true, false);
}if ( gdjs.GameSceneCode.condition1IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition2IsTrue_0.val = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "WINLOSE");
}if ( gdjs.GameSceneCode.condition2IsTrue_0.val ) {
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition3IsTrue_0;
gdjs.GameSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11884532);
}
}}
}
}
if (gdjs.GameSceneCode.condition3IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList122(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList124 = function(runtimeScene) {

{


gdjs.GameSceneCode.eventsList123(runtimeScene);
}


};gdjs.GameSceneCode.eventsList125 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableBoolean(runtimeScene.getVariables().getFromIndex(9), true);
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList124(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDobj_9595btn_9595levelselectObjects2Objects = Hashtable.newFrom({"obj_btn_levelselect": gdjs.GameSceneCode.GDobj_95btn_95levelselectObjects2});gdjs.GameSceneCode.eventsList126 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition0IsTrue_0;
gdjs.GameSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11889188);
}
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Levelselect", true);
}}

}


};gdjs.GameSceneCode.eventsList127 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("obj_btn_levelselect"), gdjs.GameSceneCode.GDobj_95btn_95levelselectObjects2);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
gdjs.GameSceneCode.condition2IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDobj_9595btn_9595levelselectObjects2Objects, runtimeScene, true, false);
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameSceneCode.condition1IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition2IsTrue_0.val = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "HUD");
}}
}
if (gdjs.GameSceneCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList126(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDobj_9595btn_9595pauseObjects2Objects = Hashtable.newFrom({"obj_btn_pause": gdjs.GameSceneCode.GDobj_95btn_95pauseObjects2});gdjs.GameSceneCode.eventsList128 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableBoolean(runtimeScene.getGame().getVariables().get("paused"), false);
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("cursor"), gdjs.GameSceneCode.GDcursorObjects3);
gdjs.copyArray(runtimeScene.getObjects("txt_paused"), gdjs.GameSceneCode.GDtxt_95pausedObjects3);
{gdjs.evtTools.camera.setLayerTimeScale(runtimeScene, "", 1);
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95pausedObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95pausedObjects3[i].hide();
}
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "BlurMe", false);
}{gdjs.evtTools.camera.showLayer(runtimeScene, "HUD");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "PAUSE");
}{for(var i = 0, len = gdjs.GameSceneCode.GDcursorObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDcursorObjects3[i].setLayer("HUD");
}
}}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableBoolean(runtimeScene.getGame().getVariables().get("paused"), true);
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("cursor"), gdjs.GameSceneCode.GDcursorObjects2);
gdjs.copyArray(runtimeScene.getObjects("txt_paused"), gdjs.GameSceneCode.GDtxt_95pausedObjects2);
{gdjs.evtTools.camera.setLayerTimeScale(runtimeScene, "", 0);
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95pausedObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95pausedObjects2[i].hide(false);
}
}{gdjs.evtTools.camera.enableLayerEffect(runtimeScene, "", "BlurMe", true);
}{gdjs.evtTools.camera.showLayer(runtimeScene, "PAUSE");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "HUD");
}{for(var i = 0, len = gdjs.GameSceneCode.GDcursorObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDcursorObjects2[i].setLayer("PAUSE");
}
}}

}


};gdjs.GameSceneCode.eventsList129 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("obj_btn_pause"), gdjs.GameSceneCode.GDobj_95btn_95pauseObjects2);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
gdjs.GameSceneCode.condition2IsTrue_0.val = false;
gdjs.GameSceneCode.condition3IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDobj_9595btn_9595pauseObjects2Objects, runtimeScene, true, false);
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameSceneCode.condition1IsTrue_0.val ) {
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition2IsTrue_0;
gdjs.GameSceneCode.condition0IsTrue_1.val = false;
{
{gdjs.GameSceneCode.conditionTrue_2 = gdjs.GameSceneCode.condition0IsTrue_1;
gdjs.GameSceneCode.condition0IsTrue_2.val = false;
gdjs.GameSceneCode.condition1IsTrue_2.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_2.val = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "HUD");
if( gdjs.GameSceneCode.condition0IsTrue_2.val ) {
    gdjs.GameSceneCode.conditionTrue_2.val = true;
}
}
{
gdjs.GameSceneCode.condition1IsTrue_2.val = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "PAUSE");
if( gdjs.GameSceneCode.condition1IsTrue_2.val ) {
    gdjs.GameSceneCode.conditionTrue_2.val = true;
}
}
{
}
}
}gdjs.GameSceneCode.conditionTrue_1.val = true && gdjs.GameSceneCode.condition0IsTrue_1.val;
}
}if ( gdjs.GameSceneCode.condition2IsTrue_0.val ) {
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition3IsTrue_0;
gdjs.GameSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11890900);
}
}}
}
}
if (gdjs.GameSceneCode.condition3IsTrue_0.val) {
{gdjs.evtTools.common.toggleVariableBoolean(runtimeScene.getGame().getVariables().get("paused"));
}
{ //Subevents
gdjs.GameSceneCode.eventsList128(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDobj_9595btn_9595ffObjects2Objects = Hashtable.newFrom({"obj_btn_ff": gdjs.GameSceneCode.GDobj_95btn_95ffObjects2});gdjs.GameSceneCode.eventsList130 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableBoolean(runtimeScene.getGame().getVariables().get("speed_up"), false);
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.GameSceneCode.GDobj_95btn_95ffObjects2, gdjs.GameSceneCode.GDobj_95btn_95ffObjects3);

{for(var i = 0, len = gdjs.GameSceneCode.GDobj_95btn_95ffObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDobj_95btn_95ffObjects3[i].setAnimationName("normal");
}
}}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableBoolean(runtimeScene.getGame().getVariables().get("speed_up"), true);
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDobj_95btn_95ffObjects2 */
{for(var i = 0, len = gdjs.GameSceneCode.GDobj_95btn_95ffObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDobj_95btn_95ffObjects2[i].setAnimationName("speedup");
}
}}

}


};gdjs.GameSceneCode.eventsList131 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("obj_btn_ff"), gdjs.GameSceneCode.GDobj_95btn_95ffObjects2);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
gdjs.GameSceneCode.condition2IsTrue_0.val = false;
gdjs.GameSceneCode.condition3IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDobj_9595btn_9595ffObjects2Objects, runtimeScene, true, false);
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameSceneCode.condition1IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition2IsTrue_0.val = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "HUD");
}if ( gdjs.GameSceneCode.condition2IsTrue_0.val ) {
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition3IsTrue_0;
gdjs.GameSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11895356);
}
}}
}
}
if (gdjs.GameSceneCode.condition3IsTrue_0.val) {
{gdjs.evtTools.common.toggleVariableBoolean(runtimeScene.getGame().getVariables().get("speed_up"));
}
{ //Subevents
gdjs.GameSceneCode.eventsList130(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList132 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("obj_btn_ff"), gdjs.GameSceneCode.GDobj_95btn_95ffObjects2);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDobj_95btn_95ffObjects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDobj_95btn_95ffObjects2[i].isCurrentAnimationName("normal") ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDobj_95btn_95ffObjects2[k] = gdjs.GameSceneCode.GDobj_95btn_95ffObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDobj_95btn_95ffObjects2.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.setLayerTimeScale(runtimeScene, "", 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("obj_btn_ff"), gdjs.GameSceneCode.GDobj_95btn_95ffObjects1);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDobj_95btn_95ffObjects1.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDobj_95btn_95ffObjects1[i].isCurrentAnimationName("speedup") ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDobj_95btn_95ffObjects1[k] = gdjs.GameSceneCode.GDobj_95btn_95ffObjects1[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDobj_95btn_95ffObjects1.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.setLayerTimeScale(runtimeScene, "", 2);
}}

}


};gdjs.GameSceneCode.eventsList133 = function(runtimeScene) {

{


gdjs.GameSceneCode.eventsList127(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList129(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList131(runtimeScene);
}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableBoolean(runtimeScene.getGame().getVariables().get("paused"), false);
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList132(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList134 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableBoolean(runtimeScene.getVariables().getFromIndex(9), false);
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList133(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList135 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "SplashScene", true);
}}

}


};gdjs.GameSceneCode.eventsList136 = function(runtimeScene) {

{


{
{gdjs.evtsExt__Fullscreen__Fullscreen.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.GameSceneCode.eventsList137 = function(runtimeScene) {

{


gdjs.GameSceneCode.eventsList16(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList18(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList19(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList25(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList44(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList63(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList66(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList121(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList125(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList134(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList135(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList136(runtimeScene);
}


};

gdjs.GameSceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.GameSceneCode.GDcursorObjects1.length = 0;
gdjs.GameSceneCode.GDcursorObjects2.length = 0;
gdjs.GameSceneCode.GDcursorObjects3.length = 0;
gdjs.GameSceneCode.GDcursorObjects4.length = 0;
gdjs.GameSceneCode.GDcursorObjects5.length = 0;
gdjs.GameSceneCode.GDcursorObjects6.length = 0;
gdjs.GameSceneCode.GDcursorObjects7.length = 0;
gdjs.GameSceneCode.GDlevel_956Objects1.length = 0;
gdjs.GameSceneCode.GDlevel_956Objects2.length = 0;
gdjs.GameSceneCode.GDlevel_956Objects3.length = 0;
gdjs.GameSceneCode.GDlevel_956Objects4.length = 0;
gdjs.GameSceneCode.GDlevel_956Objects5.length = 0;
gdjs.GameSceneCode.GDlevel_956Objects6.length = 0;
gdjs.GameSceneCode.GDlevel_956Objects7.length = 0;
gdjs.GameSceneCode.GDlevel_955Objects1.length = 0;
gdjs.GameSceneCode.GDlevel_955Objects2.length = 0;
gdjs.GameSceneCode.GDlevel_955Objects3.length = 0;
gdjs.GameSceneCode.GDlevel_955Objects4.length = 0;
gdjs.GameSceneCode.GDlevel_955Objects5.length = 0;
gdjs.GameSceneCode.GDlevel_955Objects6.length = 0;
gdjs.GameSceneCode.GDlevel_955Objects7.length = 0;
gdjs.GameSceneCode.GDlevel_954Objects1.length = 0;
gdjs.GameSceneCode.GDlevel_954Objects2.length = 0;
gdjs.GameSceneCode.GDlevel_954Objects3.length = 0;
gdjs.GameSceneCode.GDlevel_954Objects4.length = 0;
gdjs.GameSceneCode.GDlevel_954Objects5.length = 0;
gdjs.GameSceneCode.GDlevel_954Objects6.length = 0;
gdjs.GameSceneCode.GDlevel_954Objects7.length = 0;
gdjs.GameSceneCode.GDlevel_953Objects1.length = 0;
gdjs.GameSceneCode.GDlevel_953Objects2.length = 0;
gdjs.GameSceneCode.GDlevel_953Objects3.length = 0;
gdjs.GameSceneCode.GDlevel_953Objects4.length = 0;
gdjs.GameSceneCode.GDlevel_953Objects5.length = 0;
gdjs.GameSceneCode.GDlevel_953Objects6.length = 0;
gdjs.GameSceneCode.GDlevel_953Objects7.length = 0;
gdjs.GameSceneCode.GDlevel_952Objects1.length = 0;
gdjs.GameSceneCode.GDlevel_952Objects2.length = 0;
gdjs.GameSceneCode.GDlevel_952Objects3.length = 0;
gdjs.GameSceneCode.GDlevel_952Objects4.length = 0;
gdjs.GameSceneCode.GDlevel_952Objects5.length = 0;
gdjs.GameSceneCode.GDlevel_952Objects6.length = 0;
gdjs.GameSceneCode.GDlevel_952Objects7.length = 0;
gdjs.GameSceneCode.GDlevel_951Objects1.length = 0;
gdjs.GameSceneCode.GDlevel_951Objects2.length = 0;
gdjs.GameSceneCode.GDlevel_951Objects3.length = 0;
gdjs.GameSceneCode.GDlevel_951Objects4.length = 0;
gdjs.GameSceneCode.GDlevel_951Objects5.length = 0;
gdjs.GameSceneCode.GDlevel_951Objects6.length = 0;
gdjs.GameSceneCode.GDlevel_951Objects7.length = 0;
gdjs.GameSceneCode.GDtower_953_95topObjects1.length = 0;
gdjs.GameSceneCode.GDtower_953_95topObjects2.length = 0;
gdjs.GameSceneCode.GDtower_953_95topObjects3.length = 0;
gdjs.GameSceneCode.GDtower_953_95topObjects4.length = 0;
gdjs.GameSceneCode.GDtower_953_95topObjects5.length = 0;
gdjs.GameSceneCode.GDtower_953_95topObjects6.length = 0;
gdjs.GameSceneCode.GDtower_953_95topObjects7.length = 0;
gdjs.GameSceneCode.GDtower_952_95topObjects1.length = 0;
gdjs.GameSceneCode.GDtower_952_95topObjects2.length = 0;
gdjs.GameSceneCode.GDtower_952_95topObjects3.length = 0;
gdjs.GameSceneCode.GDtower_952_95topObjects4.length = 0;
gdjs.GameSceneCode.GDtower_952_95topObjects5.length = 0;
gdjs.GameSceneCode.GDtower_952_95topObjects6.length = 0;
gdjs.GameSceneCode.GDtower_952_95topObjects7.length = 0;
gdjs.GameSceneCode.GDtower_952_95bulletObjects1.length = 0;
gdjs.GameSceneCode.GDtower_952_95bulletObjects2.length = 0;
gdjs.GameSceneCode.GDtower_952_95bulletObjects3.length = 0;
gdjs.GameSceneCode.GDtower_952_95bulletObjects4.length = 0;
gdjs.GameSceneCode.GDtower_952_95bulletObjects5.length = 0;
gdjs.GameSceneCode.GDtower_952_95bulletObjects6.length = 0;
gdjs.GameSceneCode.GDtower_952_95bulletObjects7.length = 0;
gdjs.GameSceneCode.GDtower_951_95topObjects1.length = 0;
gdjs.GameSceneCode.GDtower_951_95topObjects2.length = 0;
gdjs.GameSceneCode.GDtower_951_95topObjects3.length = 0;
gdjs.GameSceneCode.GDtower_951_95topObjects4.length = 0;
gdjs.GameSceneCode.GDtower_951_95topObjects5.length = 0;
gdjs.GameSceneCode.GDtower_951_95topObjects6.length = 0;
gdjs.GameSceneCode.GDtower_951_95topObjects7.length = 0;
gdjs.GameSceneCode.GDtower_951_95bulletObjects1.length = 0;
gdjs.GameSceneCode.GDtower_951_95bulletObjects2.length = 0;
gdjs.GameSceneCode.GDtower_951_95bulletObjects3.length = 0;
gdjs.GameSceneCode.GDtower_951_95bulletObjects4.length = 0;
gdjs.GameSceneCode.GDtower_951_95bulletObjects5.length = 0;
gdjs.GameSceneCode.GDtower_951_95bulletObjects6.length = 0;
gdjs.GameSceneCode.GDtower_951_95bulletObjects7.length = 0;
gdjs.GameSceneCode.GDtowerObjects1.length = 0;
gdjs.GameSceneCode.GDtowerObjects2.length = 0;
gdjs.GameSceneCode.GDtowerObjects3.length = 0;
gdjs.GameSceneCode.GDtowerObjects4.length = 0;
gdjs.GameSceneCode.GDtowerObjects5.length = 0;
gdjs.GameSceneCode.GDtowerObjects6.length = 0;
gdjs.GameSceneCode.GDtowerObjects7.length = 0;
gdjs.GameSceneCode.GDtower_95btnObjects1.length = 0;
gdjs.GameSceneCode.GDtower_95btnObjects2.length = 0;
gdjs.GameSceneCode.GDtower_95btnObjects3.length = 0;
gdjs.GameSceneCode.GDtower_95btnObjects4.length = 0;
gdjs.GameSceneCode.GDtower_95btnObjects5.length = 0;
gdjs.GameSceneCode.GDtower_95btnObjects6.length = 0;
gdjs.GameSceneCode.GDtower_95btnObjects7.length = 0;
gdjs.GameSceneCode.GDtower_95selectedObjects1.length = 0;
gdjs.GameSceneCode.GDtower_95selectedObjects2.length = 0;
gdjs.GameSceneCode.GDtower_95selectedObjects3.length = 0;
gdjs.GameSceneCode.GDtower_95selectedObjects4.length = 0;
gdjs.GameSceneCode.GDtower_95selectedObjects5.length = 0;
gdjs.GameSceneCode.GDtower_95selectedObjects6.length = 0;
gdjs.GameSceneCode.GDtower_95selectedObjects7.length = 0;
gdjs.GameSceneCode.GDtower_951_95bullet_95trailObjects1.length = 0;
gdjs.GameSceneCode.GDtower_951_95bullet_95trailObjects2.length = 0;
gdjs.GameSceneCode.GDtower_951_95bullet_95trailObjects3.length = 0;
gdjs.GameSceneCode.GDtower_951_95bullet_95trailObjects4.length = 0;
gdjs.GameSceneCode.GDtower_951_95bullet_95trailObjects5.length = 0;
gdjs.GameSceneCode.GDtower_951_95bullet_95trailObjects6.length = 0;
gdjs.GameSceneCode.GDtower_951_95bullet_95trailObjects7.length = 0;
gdjs.GameSceneCode.GDtower_952_95bullet_95trailObjects1.length = 0;
gdjs.GameSceneCode.GDtower_952_95bullet_95trailObjects2.length = 0;
gdjs.GameSceneCode.GDtower_952_95bullet_95trailObjects3.length = 0;
gdjs.GameSceneCode.GDtower_952_95bullet_95trailObjects4.length = 0;
gdjs.GameSceneCode.GDtower_952_95bullet_95trailObjects5.length = 0;
gdjs.GameSceneCode.GDtower_952_95bullet_95trailObjects6.length = 0;
gdjs.GameSceneCode.GDtower_952_95bullet_95trailObjects7.length = 0;
gdjs.GameSceneCode.GDarrow_95explosionObjects1.length = 0;
gdjs.GameSceneCode.GDarrow_95explosionObjects2.length = 0;
gdjs.GameSceneCode.GDarrow_95explosionObjects3.length = 0;
gdjs.GameSceneCode.GDarrow_95explosionObjects4.length = 0;
gdjs.GameSceneCode.GDarrow_95explosionObjects5.length = 0;
gdjs.GameSceneCode.GDarrow_95explosionObjects6.length = 0;
gdjs.GameSceneCode.GDarrow_95explosionObjects7.length = 0;
gdjs.GameSceneCode.GDupgrade_95barObjects1.length = 0;
gdjs.GameSceneCode.GDupgrade_95barObjects2.length = 0;
gdjs.GameSceneCode.GDupgrade_95barObjects3.length = 0;
gdjs.GameSceneCode.GDupgrade_95barObjects4.length = 0;
gdjs.GameSceneCode.GDupgrade_95barObjects5.length = 0;
gdjs.GameSceneCode.GDupgrade_95barObjects6.length = 0;
gdjs.GameSceneCode.GDupgrade_95barObjects7.length = 0;
gdjs.GameSceneCode.GDenemy_952Objects1.length = 0;
gdjs.GameSceneCode.GDenemy_952Objects2.length = 0;
gdjs.GameSceneCode.GDenemy_952Objects3.length = 0;
gdjs.GameSceneCode.GDenemy_952Objects4.length = 0;
gdjs.GameSceneCode.GDenemy_952Objects5.length = 0;
gdjs.GameSceneCode.GDenemy_952Objects6.length = 0;
gdjs.GameSceneCode.GDenemy_952Objects7.length = 0;
gdjs.GameSceneCode.GDenemy_951Objects1.length = 0;
gdjs.GameSceneCode.GDenemy_951Objects2.length = 0;
gdjs.GameSceneCode.GDenemy_951Objects3.length = 0;
gdjs.GameSceneCode.GDenemy_951Objects4.length = 0;
gdjs.GameSceneCode.GDenemy_951Objects5.length = 0;
gdjs.GameSceneCode.GDenemy_951Objects6.length = 0;
gdjs.GameSceneCode.GDenemy_951Objects7.length = 0;
gdjs.GameSceneCode.GDenemy_950Objects1.length = 0;
gdjs.GameSceneCode.GDenemy_950Objects2.length = 0;
gdjs.GameSceneCode.GDenemy_950Objects3.length = 0;
gdjs.GameSceneCode.GDenemy_950Objects4.length = 0;
gdjs.GameSceneCode.GDenemy_950Objects5.length = 0;
gdjs.GameSceneCode.GDenemy_950Objects6.length = 0;
gdjs.GameSceneCode.GDenemy_950Objects7.length = 0;
gdjs.GameSceneCode.GDend_95pathObjects1.length = 0;
gdjs.GameSceneCode.GDend_95pathObjects2.length = 0;
gdjs.GameSceneCode.GDend_95pathObjects3.length = 0;
gdjs.GameSceneCode.GDend_95pathObjects4.length = 0;
gdjs.GameSceneCode.GDend_95pathObjects5.length = 0;
gdjs.GameSceneCode.GDend_95pathObjects6.length = 0;
gdjs.GameSceneCode.GDend_95pathObjects7.length = 0;
gdjs.GameSceneCode.GDstart_95pathObjects1.length = 0;
gdjs.GameSceneCode.GDstart_95pathObjects2.length = 0;
gdjs.GameSceneCode.GDstart_95pathObjects3.length = 0;
gdjs.GameSceneCode.GDstart_95pathObjects4.length = 0;
gdjs.GameSceneCode.GDstart_95pathObjects5.length = 0;
gdjs.GameSceneCode.GDstart_95pathObjects6.length = 0;
gdjs.GameSceneCode.GDstart_95pathObjects7.length = 0;
gdjs.GameSceneCode.GDobstacleObjects1.length = 0;
gdjs.GameSceneCode.GDobstacleObjects2.length = 0;
gdjs.GameSceneCode.GDobstacleObjects3.length = 0;
gdjs.GameSceneCode.GDobstacleObjects4.length = 0;
gdjs.GameSceneCode.GDobstacleObjects5.length = 0;
gdjs.GameSceneCode.GDobstacleObjects6.length = 0;
gdjs.GameSceneCode.GDobstacleObjects7.length = 0;
gdjs.GameSceneCode.GDtxt_95kills_95this_95waveObjects1.length = 0;
gdjs.GameSceneCode.GDtxt_95kills_95this_95waveObjects2.length = 0;
gdjs.GameSceneCode.GDtxt_95kills_95this_95waveObjects3.length = 0;
gdjs.GameSceneCode.GDtxt_95kills_95this_95waveObjects4.length = 0;
gdjs.GameSceneCode.GDtxt_95kills_95this_95waveObjects5.length = 0;
gdjs.GameSceneCode.GDtxt_95kills_95this_95waveObjects6.length = 0;
gdjs.GameSceneCode.GDtxt_95kills_95this_95waveObjects7.length = 0;
gdjs.GameSceneCode.GDtxt_95enemies_95escapedObjects1.length = 0;
gdjs.GameSceneCode.GDtxt_95enemies_95escapedObjects2.length = 0;
gdjs.GameSceneCode.GDtxt_95enemies_95escapedObjects3.length = 0;
gdjs.GameSceneCode.GDtxt_95enemies_95escapedObjects4.length = 0;
gdjs.GameSceneCode.GDtxt_95enemies_95escapedObjects5.length = 0;
gdjs.GameSceneCode.GDtxt_95enemies_95escapedObjects6.length = 0;
gdjs.GameSceneCode.GDtxt_95enemies_95escapedObjects7.length = 0;
gdjs.GameSceneCode.GDtxt_95waveObjects1.length = 0;
gdjs.GameSceneCode.GDtxt_95waveObjects2.length = 0;
gdjs.GameSceneCode.GDtxt_95waveObjects3.length = 0;
gdjs.GameSceneCode.GDtxt_95waveObjects4.length = 0;
gdjs.GameSceneCode.GDtxt_95waveObjects5.length = 0;
gdjs.GameSceneCode.GDtxt_95waveObjects6.length = 0;
gdjs.GameSceneCode.GDtxt_95waveObjects7.length = 0;
gdjs.GameSceneCode.GDtxt_95coinsObjects1.length = 0;
gdjs.GameSceneCode.GDtxt_95coinsObjects2.length = 0;
gdjs.GameSceneCode.GDtxt_95coinsObjects3.length = 0;
gdjs.GameSceneCode.GDtxt_95coinsObjects4.length = 0;
gdjs.GameSceneCode.GDtxt_95coinsObjects5.length = 0;
gdjs.GameSceneCode.GDtxt_95coinsObjects6.length = 0;
gdjs.GameSceneCode.GDtxt_95coinsObjects7.length = 0;
gdjs.GameSceneCode.GDtower_95panelObjects1.length = 0;
gdjs.GameSceneCode.GDtower_95panelObjects2.length = 0;
gdjs.GameSceneCode.GDtower_95panelObjects3.length = 0;
gdjs.GameSceneCode.GDtower_95panelObjects4.length = 0;
gdjs.GameSceneCode.GDtower_95panelObjects5.length = 0;
gdjs.GameSceneCode.GDtower_95panelObjects6.length = 0;
gdjs.GameSceneCode.GDtower_95panelObjects7.length = 0;
gdjs.GameSceneCode.GDtower_95btn_95sellObjects1.length = 0;
gdjs.GameSceneCode.GDtower_95btn_95sellObjects2.length = 0;
gdjs.GameSceneCode.GDtower_95btn_95sellObjects3.length = 0;
gdjs.GameSceneCode.GDtower_95btn_95sellObjects4.length = 0;
gdjs.GameSceneCode.GDtower_95btn_95sellObjects5.length = 0;
gdjs.GameSceneCode.GDtower_95btn_95sellObjects6.length = 0;
gdjs.GameSceneCode.GDtower_95btn_95sellObjects7.length = 0;
gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects1.length = 0;
gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects2.length = 0;
gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects3.length = 0;
gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects4.length = 0;
gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects5.length = 0;
gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects6.length = 0;
gdjs.GameSceneCode.GDtower_95btn_95upgradeObjects7.length = 0;
gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects1.length = 0;
gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects2.length = 0;
gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects3.length = 0;
gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects4.length = 0;
gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects5.length = 0;
gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects6.length = 0;
gdjs.GameSceneCode.GDtower_95btn_95bulletsObjects7.length = 0;
gdjs.GameSceneCode.GDlevelupObjects1.length = 0;
gdjs.GameSceneCode.GDlevelupObjects2.length = 0;
gdjs.GameSceneCode.GDlevelupObjects3.length = 0;
gdjs.GameSceneCode.GDlevelupObjects4.length = 0;
gdjs.GameSceneCode.GDlevelupObjects5.length = 0;
gdjs.GameSceneCode.GDlevelupObjects6.length = 0;
gdjs.GameSceneCode.GDlevelupObjects7.length = 0;
gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects1.length = 0;
gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects2.length = 0;
gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects3.length = 0;
gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects4.length = 0;
gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects5.length = 0;
gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects6.length = 0;
gdjs.GameSceneCode.GDtxt_95enemies_95damageObjects7.length = 0;
gdjs.GameSceneCode.GDtxt_95pausedObjects1.length = 0;
gdjs.GameSceneCode.GDtxt_95pausedObjects2.length = 0;
gdjs.GameSceneCode.GDtxt_95pausedObjects3.length = 0;
gdjs.GameSceneCode.GDtxt_95pausedObjects4.length = 0;
gdjs.GameSceneCode.GDtxt_95pausedObjects5.length = 0;
gdjs.GameSceneCode.GDtxt_95pausedObjects6.length = 0;
gdjs.GameSceneCode.GDtxt_95pausedObjects7.length = 0;
gdjs.GameSceneCode.GDtxt_95rankingsObjects1.length = 0;
gdjs.GameSceneCode.GDtxt_95rankingsObjects2.length = 0;
gdjs.GameSceneCode.GDtxt_95rankingsObjects3.length = 0;
gdjs.GameSceneCode.GDtxt_95rankingsObjects4.length = 0;
gdjs.GameSceneCode.GDtxt_95rankingsObjects5.length = 0;
gdjs.GameSceneCode.GDtxt_95rankingsObjects6.length = 0;
gdjs.GameSceneCode.GDtxt_95rankingsObjects7.length = 0;
gdjs.GameSceneCode.GDhud_95box2Objects1.length = 0;
gdjs.GameSceneCode.GDhud_95box2Objects2.length = 0;
gdjs.GameSceneCode.GDhud_95box2Objects3.length = 0;
gdjs.GameSceneCode.GDhud_95box2Objects4.length = 0;
gdjs.GameSceneCode.GDhud_95box2Objects5.length = 0;
gdjs.GameSceneCode.GDhud_95box2Objects6.length = 0;
gdjs.GameSceneCode.GDhud_95box2Objects7.length = 0;
gdjs.GameSceneCode.GDhud_95boxObjects1.length = 0;
gdjs.GameSceneCode.GDhud_95boxObjects2.length = 0;
gdjs.GameSceneCode.GDhud_95boxObjects3.length = 0;
gdjs.GameSceneCode.GDhud_95boxObjects4.length = 0;
gdjs.GameSceneCode.GDhud_95boxObjects5.length = 0;
gdjs.GameSceneCode.GDhud_95boxObjects6.length = 0;
gdjs.GameSceneCode.GDhud_95boxObjects7.length = 0;
gdjs.GameSceneCode.GDtxt_95debug_951Objects1.length = 0;
gdjs.GameSceneCode.GDtxt_95debug_951Objects2.length = 0;
gdjs.GameSceneCode.GDtxt_95debug_951Objects3.length = 0;
gdjs.GameSceneCode.GDtxt_95debug_951Objects4.length = 0;
gdjs.GameSceneCode.GDtxt_95debug_951Objects5.length = 0;
gdjs.GameSceneCode.GDtxt_95debug_951Objects6.length = 0;
gdjs.GameSceneCode.GDtxt_95debug_951Objects7.length = 0;
gdjs.GameSceneCode.GDhud_95bottom_95panelObjects1.length = 0;
gdjs.GameSceneCode.GDhud_95bottom_95panelObjects2.length = 0;
gdjs.GameSceneCode.GDhud_95bottom_95panelObjects3.length = 0;
gdjs.GameSceneCode.GDhud_95bottom_95panelObjects4.length = 0;
gdjs.GameSceneCode.GDhud_95bottom_95panelObjects5.length = 0;
gdjs.GameSceneCode.GDhud_95bottom_95panelObjects6.length = 0;
gdjs.GameSceneCode.GDhud_95bottom_95panelObjects7.length = 0;
gdjs.GameSceneCode.GDvictoryObjects1.length = 0;
gdjs.GameSceneCode.GDvictoryObjects2.length = 0;
gdjs.GameSceneCode.GDvictoryObjects3.length = 0;
gdjs.GameSceneCode.GDvictoryObjects4.length = 0;
gdjs.GameSceneCode.GDvictoryObjects5.length = 0;
gdjs.GameSceneCode.GDvictoryObjects6.length = 0;
gdjs.GameSceneCode.GDvictoryObjects7.length = 0;
gdjs.GameSceneCode.GDvictory_95effectObjects1.length = 0;
gdjs.GameSceneCode.GDvictory_95effectObjects2.length = 0;
gdjs.GameSceneCode.GDvictory_95effectObjects3.length = 0;
gdjs.GameSceneCode.GDvictory_95effectObjects4.length = 0;
gdjs.GameSceneCode.GDvictory_95effectObjects5.length = 0;
gdjs.GameSceneCode.GDvictory_95effectObjects6.length = 0;
gdjs.GameSceneCode.GDvictory_95effectObjects7.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95continueObjects1.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95continueObjects2.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95continueObjects3.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95continueObjects4.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95continueObjects5.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95continueObjects6.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95continueObjects7.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95nextObjects1.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95nextObjects2.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95nextObjects3.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95nextObjects4.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95nextObjects5.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95nextObjects6.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95nextObjects7.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95levelselectObjects1.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95levelselectObjects2.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95levelselectObjects3.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95levelselectObjects4.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95levelselectObjects5.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95levelselectObjects6.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95levelselectObjects7.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95pauseObjects1.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95pauseObjects2.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95pauseObjects3.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95pauseObjects4.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95pauseObjects5.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95pauseObjects6.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95pauseObjects7.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95levelObjects1.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95levelObjects2.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95levelObjects3.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95levelObjects4.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95levelObjects5.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95levelObjects6.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95levelObjects7.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95ffObjects1.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95ffObjects2.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95ffObjects3.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95ffObjects4.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95ffObjects5.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95ffObjects6.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95ffObjects7.length = 0;
gdjs.GameSceneCode.GDtxt_95tutorialObjects1.length = 0;
gdjs.GameSceneCode.GDtxt_95tutorialObjects2.length = 0;
gdjs.GameSceneCode.GDtxt_95tutorialObjects3.length = 0;
gdjs.GameSceneCode.GDtxt_95tutorialObjects4.length = 0;
gdjs.GameSceneCode.GDtxt_95tutorialObjects5.length = 0;
gdjs.GameSceneCode.GDtxt_95tutorialObjects6.length = 0;
gdjs.GameSceneCode.GDtxt_95tutorialObjects7.length = 0;
gdjs.GameSceneCode.GDtiledbackgroundObjects1.length = 0;
gdjs.GameSceneCode.GDtiledbackgroundObjects2.length = 0;
gdjs.GameSceneCode.GDtiledbackgroundObjects3.length = 0;
gdjs.GameSceneCode.GDtiledbackgroundObjects4.length = 0;
gdjs.GameSceneCode.GDtiledbackgroundObjects5.length = 0;
gdjs.GameSceneCode.GDtiledbackgroundObjects6.length = 0;
gdjs.GameSceneCode.GDtiledbackgroundObjects7.length = 0;
gdjs.GameSceneCode.GDbase_95hpObjects1.length = 0;
gdjs.GameSceneCode.GDbase_95hpObjects2.length = 0;
gdjs.GameSceneCode.GDbase_95hpObjects3.length = 0;
gdjs.GameSceneCode.GDbase_95hpObjects4.length = 0;
gdjs.GameSceneCode.GDbase_95hpObjects5.length = 0;
gdjs.GameSceneCode.GDbase_95hpObjects6.length = 0;
gdjs.GameSceneCode.GDbase_95hpObjects7.length = 0;

gdjs.GameSceneCode.eventsList137(runtimeScene);
return;

}

gdjs['GameSceneCode'] = gdjs.GameSceneCode;
